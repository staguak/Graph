package com.moyz.adi.common.dto;

import com.moyz.adi.common.vo.AudioConfig;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
public class CharacterEditReq {

    private String title;

    private String remark;

    @Schema(title = "set the system message to ai, ig: you are a lawyer")
    private String aiSystemMessage;

    private Boolean understandContextEnable;

    private List<Long> mcpIds;

    private List<Long> kbIds;

    private Integer answerContentType;

    private Boolean isAutoplayAnswer;

    private Boolean isEnableThinking;

    private Boolean isEnableWebSearch;

    private AudioConfig audioConfig;
}
