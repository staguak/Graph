package com.moyz.adi.common.cosntant;

import dev.langchain4j.model.input.PromptTemplate;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class AdiConstant {
    private AdiConstant() {
    }

    public static final int DEFAULT_PAGE_SIZE = 10;

    /**
     * 验证码id过期时间：1小时
     */
    public static final int AUTH_CAPTCHA_ID_EXPIRE = 1;

    /**
     * 验证码过期时间，5分钟
     */
    public static final int AUTH_CAPTCHA_EXPIRE = 5;

    /**
     * 注册激活码有效时长，8小时
     */
    public static final int AUTH_ACTIVE_CODE_EXPIRE = 8;

    /**
     * token存活时间（8小时）
     */
    public static final int USER_TOKEN_EXPIRE = 8;

    public static final String DEFAULT_PASSWORD = "123456";

    public static final int LOGIN_MAX_FAIL_TIMES = 3;

    public static final String[] WEB_RESOURCES = {
            "/swagger-ui/index.html",
            "/swagger-ui",
            "/swagger-resources",
            "/v3/api-docs",
            "/favicon.ico",
            ".css",
            ".js",
            "/doc.html"
    };

    public static final int SECRET_KEY_TYPE_SYSTEM = 1;
    public static final int SECRET_KEY_TYPE_CUSTOM = 2;

    public static final String OPENAI_MESSAGE_DONE_FLAG = "[DONE]";

    public static final String DEFAULT_MODEL = "gpt-3.5-turbo";

    /**
     * 可能的 extraInfo 如适用转音频的要求： 3. 回答的内容要尽量口语化，以方便将内容转成语音
     */
    public static final PromptTemplate PROMPT_INFO_EXTRA_TEMPLATE = PromptTemplate.from("""
            ## 任务
            根据已知信息及用户的记忆，尽可能准确地回答用户的问题
                        
            ## 要求
            1. 根据对用户的记忆，回答时可以适当调整语气和风格，以更符合用户的偏好
            2. 回答的内容不能让用户感知到已知信息的存在
            {{extraInfo}}
                        
            ## 用户的问题
            {{question}}
                        
            ## 已知信息
            {{information}}
                        
            ## 关于用户的记忆
            {{memory}}
                        
            ## 输出语言
            使用用户提问的语言进行内容输出
            """);

    public static final PromptTemplate PROMPT_INFO_EXTRA_TEMPLATE_EN = PromptTemplate.from("""
            ## Task
            Answer the user's question as accurately as possible based on the known information and the user's memory

            ## Requirements
            1. Based on the user's memory, adjust the tone and style appropriately to better match the user's preferences
            2. The answer should not reveal the existence of the known information to the user
            {{extraInfo}}

            ## User's Question
            {{question}}

            ## Known Information
            {{information}}

            ## About the User's Memory
            {{memory}}

            ## Output Language
            Respond in the language of the user's question
            """);

    public static final String PROMPT_EXTRA_AUDIO = "3. 回答的内容要尽量口语化，以方便将内容转成语音";
    public static final String PROMPT_EXTRA_AUDIO_EN = "3. The response should be as colloquial as possible to facilitate converting the content to speech";

    public static final Double LLM_TEMPERATURE_DEFAULT = 0.7D;
    public static final Double RAG_RETRIEVE_MIN_SCORE_DEFAULT = 0.6D;

    /**
     * 长期记忆提取时，向量检索旧记忆的最低相似度阈值。
     * <p>
     * Minimum similarity threshold for retrieving old memories during long-term memory extraction.
     * 不同 embedding 模型尺度差异大，建议按模型配置化覆盖。
     */
    public static final double LONG_TERM_MEMORY_MIN_SCORE_DEFAULT = 0.7D;

    public static class CharacterConstant {
        private CharacterConstant() {
        }

        public static final String DEFAULT_NAME = "通用智能助手";
        public static final String DEFAULT_NAME_EN = "General AI Assistant";

        public static final int ANSWER_CONTENT_TYPE_AUTO = 1;
        public static final int ANSWER_CONTENT_TYPE_TEXT = 2;
        public static final int ANSWER_CONTENT_TYPE_AUDIO = 3;

        public static final String AUDIO_CONFIG_FIELD_ANSWER_VOICE = "answer_voice";
        public static final String AUDIO_CONFIG_FIELD_VOICE_PLATFORM = "platform";
    }

    public static class GenerateImage {
        private GenerateImage() {
        }

        public static final int INTERACTING_METHOD_GENERATE_IMAGE = 1;
        public static final int INTERACTING_METHOD_EDIT_IMAGE = 2;
        public static final int INTERACTING_METHOD_VARIATION = 3;
        public static final int INTERACTING_METHOD_BACKGROUND_GENERATION = 4;

        public static final int STATUS_DOING = 1;
        public static final int STATUS_FAIL = 2;
        public static final int STATUS_SUCCESS = 3;
    }

    public static class MetadataKey {
        private MetadataKey() {
        }

        public static final String KB_UUID = "kb_uuid";
        public static final String KB_ITEM_UUID = "kb_item_uuid";
        public static final String SEGMENT_ID = "segment_id";
        public static final String ENGINE_NAME = "engine_name";
        public static final String SEARCH_UUID = "search_uuid";
        /**
         * 关联的角色 ID。键值 {@code "conv_id"} 是 conversation→character 重命名时
         * 保留的历史名，所有语义/情景记忆向量库都用它做 metadata 索引；常量名已规范化。
         * <p>
         * Owning character ID. The string literal {@code "conv_id"} is retained from the
         * conversation→character rename for backward compatibility with existing vector
         * store data — the Java constant name is normalized.
         */
        public static final String CHARACTER_ID = "conv_id";

        /**
         * 记忆类型 metadata key（semantic / episodic）。
         * <p>
         * Memory type metadata key. Old records without this field are treated as semantic.
         */
        public static final String MEMORY_TYPE = "memory_type";

        /**
         * 记忆创建时间（episodic 必填，格式 {@code yyyy-MM-dd HH:mm:ss}）。
         * 注意这是写入 jsonb metadata 内部的 key，与表自带列 {@code create_time} 同名
         * 但作用域不同——后者是 PG 列，前者是 metadata JSON 内的字段。
         * <p>
         * Memory created-at timestamp (required for episodic; formatted as
         * {@code yyyy-MM-dd HH:mm:ss}). Same name as the table column {@code create_time}
         * but lives inside the jsonb metadata — distinct scopes.
         */
        public static final String CREATE_TIME = "create_time";

        /**
         * 关联的角色消息 ID（episodic 必填）。键值 {@code "conv_msg_id"} 是
         * conversation→character 重命名时保留的历史名，与 {@link #CHARACTER_ID} 同源；
         * episodic 表与 semantic 表共用此 key 以保持 metadata 命名一致。
         * <p>
         * Character message ID this memory was derived from (required for episodic).
         * The literal {@code "conv_msg_id"} is retained from the conversation→character
         * rename, same as {@link #CHARACTER_ID}; episodic and semantic stores share this
         * key for metadata consistency.
         */
        public static final String CHARACTER_MSG_ID = "conv_msg_id";

        /**
         * 事件类型（episodic 用）。
         * <p>
         * Event type (episodic only).
         */
        public static final String EVENT_TYPE = "event_type";

        /**
         * 重要性 1-5（episodic 用）。
         * <p>
         * Importance 1-5 (episodic only).
         */
        public static final String IMPORTANCE = "importance";

        public static final String TEXT = "text";
    }

    //Max length of metadata value
    public static int MAX_METADATA_VALUE_LENGTH = 500;

    public static class SysConfigKey {
        private SysConfigKey() {
        }

        public static final String DEEPSEEK_SETTING = "deepseek_setting";
        public static final String OPENAI_SETTING = "openai_setting";
        public static final String DASHSCOPE_SETTING = "dashscope_setting";

        public static final String OLLAMA_SETTING = "ollama_setting";
        public static final String SILICONFLOW_SETTING = "siliconflow_setting";
        public static final String GOOGLE_SETTING = "google_setting";
        public static final String REQUEST_TEXT_RATE_LIMIT = "request_text_rate_limit";
        public static final String REQUEST_IMAGE_RATE_LIMIT = "request_image_rate_limit";
        public static final String CHARACTER_MAX_NUM = "character_max_num";
        public static final String QUOTA_BY_TOKEN_DAILY = "quota_by_token_daily";
        public static final String QUOTA_BY_TOKEN_MONTHLY = "quota_by_token_monthly";
        public static final String QUOTA_BY_REQUEST_DAILY = "quota_by_request_daily";
        public static final String QUOTA_BY_REQUEST_MONTHLY = "quota_by_request_monthly";
        public static final String QUOTA_BY_IMAGE_DAILY = "quota_by_image_daily";
        public static final String QUOTA_BY_IMAGE_MONTHLY = "quota_by_image_monthly";
        public static final String QUOTA_BY_QA_ASK_DAILY = "quota_by_qa_ask_daily";
        public static final String STORAGE_LOCATION = "storage_location";
        public static final String STORAGE_LOCATION_ALI_OSS = "storage_location_ali_oss";
        public static final String ASR_SETTING = "asr_setting";
        public static final String TTS_SETTING = "tts_setting";
        public static final String DEFAULT_LOCALE = "default_locale";
    }

    public static final String[] POI_DOC_TYPES = {"doc", "docx", "ppt", "pptx", "xls", "xlsx"};


    public static class ModelPlatform {
        private ModelPlatform() {
        }

        public static final String DEEPSEEK = "deepseek";
        public static final String OPENAI = "openai";
        public static final String DASHSCOPE = "dashscope";

        public static final String OLLAMA = "ollama";
        public static final String SILICONFLOW = "siliconflow";

        // 获取所有公共静态常量（String类型的值）的列表
        public static List<String> getModelConstants() {
            List<String> list = new ArrayList<>();
            Class<ModelPlatform> clazz = ModelPlatform.class;
            for (Field field : clazz.getDeclaredFields()) {
                try {
                    String value = (String) field.get(null);
                    list.add(value);
                } catch (ReflectiveOperationException e) {
                    log.error("error", e);
                }

            }
            return list;
        }
    }

    public static class ModelType {
        private ModelType() {
        }

        public static final String TEXT = "text";
        public static final String IMAGE = "image";
        public static final String VISION = "vision";
        public static final String EMBEDDING = "embedding";
        public static final String RERANK = "rerank";
        public static final String ASR = "asr";
        public static final String TTS = "tts";

        public static List<String> getModelType() {
            List<String> list = new ArrayList<>();
            Class<ModelType> clazz = ModelType.class;
            for (Field field : clazz.getDeclaredFields()) {
                try {
                    String value = (String) field.get(null);
                    list.add(value);
                } catch (ReflectiveOperationException e) {
                    log.error("error", e);
                }

            }
            return list;
        }
    }

    public static class SearchEngineName {
        private SearchEngineName() {
        }

        public static final String GOOGLE = "google";

        public static final String[] GOOGLE_COUNTRIES = {"cn", "af", "al", "dz", "as", "ad", "ao", "ai", "aq", "ag", "ar", "am", "aw", "au", "at", "az", "bs", "bh", "bd", "bb", "by", "be", "bz", "bj", "bm", "bt", "bo", "ba", "bw", "bv", "br", "io", "bn", "bg", "bf", "bi", "kh", "cm", "ca", "cv", "ky", "cf", "td", "cl", "cx", "cc", "co", "km", "cg", "cd", "ck", "cr", "ci", "hr", "cu", "cy", "cz", "dk", "dj", "dm", "do", "ec", "eg", "sv", "gq", "er", "ee", "et", "fk", "fo", "fj", "fi", "fr", "gf", "pf", "tf", "ga", "gm", "ge", "de", "gh", "gi", "gr", "gl", "gd", "gp", "gu", "gt", "gn", "gw", "gy", "ht", "hm", "va", "hn", "hk", "hu", "is", "in", "id", "ir", "iq", "ie", "il", "it", "jm", "jp", "jo", "kz", "ke", "ki", "kp", "kr", "kw", "kg", "la", "lv", "lb", "ls", "lr", "ly", "li", "lt", "lu", "mo", "mk", "mg", "mw", "my", "mv", "ml", "mt", "mh", "mq", "mr", "mu", "yt", "mx", "fm", "md", "mc", "mn", "ms", "ma", "mz", "mm", "na", "nr", "np", "nl", "an", "nc", "nz", "ni", "ne", "ng", "nu", "nf", "mp", "no", "om", "pk", "pw", "ps", "pa", "pg", "py", "pe", "ph", "pn", "pl", "pt", "pr", "qa", "re", "ro", "ru", "rw", "sh", "kn", "lc", "pm", "vc", "ws", "sm", "st", "sa", "sn", "rs", "sc", "sl", "sg", "sk", "si", "sb", "so", "za", "gs", "es", "lk", "sd", "sr", "sj", "sz", "se", "ch", "sy", "tw", "tj", "tz", "th", "tl", "tg", "tk", "to", "tt", "tn", "tr", "tm", "tc", "tv", "ug", "ua", "ae", "uk", "gb", "us", "um", "uy", "uz", "vu", "ve", "vn", "vg", "vi", "wf", "eh", "ye", "zm", "zw"};
        public static final String[] GOOGLE_LANGUAGES = {"zh-cn", "zh-tw", "af", "ak", "sq", "ws", "am", "ar", "hy", "az", "eu", "be", "bem", "bn", "bh", "xx-bork", "bs", "br", "bg", "bt", "km", "ca", "chr", "ny", "co", "hr", "cs", "da", "nl", "xx-elmer", "en", "eo", "et", "ee", "fo", "tl", "fi", "fr", "fy", "gaa", "gl", "ka", "de", "el", "kl", "gn", "gu", "xx-hacker", "ht", "ha", "haw", "iw", "hi", "hu", "is", "ig", "id", "ia", "ga", "it", "ja", "jw", "kn", "kk", "rw", "rn", "xx-klingon", "kg", "ko", "kri", "ku", "ckb", "ky", "lo", "la", "lv", "ln", "lt", "loz", "lg", "ach", "mk", "mg", "ms", "ml", "mt", "mv", "mi", "mr", "mfe", "mo", "mn", "sr-me", "my", "ne", "pcm", "nso", "no", "nn", "oc", "or", "om", "ps", "fa", "xx-pirate", "pl", "pt", "pt-br", "pt-pt", "pa", "qu", "ro", "rm", "nyn", "ru", "gd", "sr", "sh", "st", "tn", "crs", "sn", "sd", "si", "sk", "sl", "so", "es", "es-419", "su", "sw", "sv", "tg", "ta", "tt", "te", "th", "ti", "to", "lua", "tum", "tr", "tk", "tw", "ug", "uk", "ur", "uz", "vu", "vi", "cy", "wo", "xh", "yi", "yo", "zu"};
    }

    public static final long SSE_TIMEOUT = 5 * 60 * 1000L; // 5分钟

    public static class SSEEventName {
        private SSEEventName() {
        }

        public static final String START = "[START]";
        public static final String DONE = "[DONE]";
        public static final String ERROR = "[ERROR]";
        public static final String META = "[META]";
        public static final String AUDIO = "[AUDIO]";
        public static final String THINKING = "[THINKING]";
        public static final String AI_SEARCH_SOURCE_LINKS = "[SOURCE_LINKS]";
        public static final String WF_NODE_CHUNK = "[WF_NODE_CHUNK]";
        public static final String WF_NODE_OUTPUT = "[WF_NODE_OUTPUT]";
        public static final String STATE_CHANGED = "[STATE_CHANGED]";
        public static final String TOOL_CALL = "[TOOL_CALL]";
        /**
         * Runtime-level aggregated metrics snapshot pushed at terminal status (success / fail /
         * waiting_input). Frontend looks for this exact tag in RunDetail.vue.
         */
        public static final String RUNTIME_METRICS = "[RUNTIME_METRICS]";
        /**
         * Per-node metrics event prefix; the full event name is {@code NODE_METRICS_PREFIX + nodeUuid + "]"}.
         */
        public static final String NODE_METRICS_PREFIX = "[NODE_METRICS_";
    }

    public static class SSEEventData {

        /**
         * 状态：问题分析中
         * 如敏感词校验等
         * remark uses i18n code, frontend maps code to locale-specific text
         */
        public static final String STATE_QUESTION_ANALYSING = """
                {"state":"question_analysing","remark":"state.question_analysing"}
                """;

        public static final String STATE_KNOWLEDGE_SEARCHING = """
                {"state":"knowledge_searching","remark":"state.knowledge_searching"}
                """;
        //使用 THINKING 事件代替
        public static final String STATE_THINKING = """
                {"state":"thinking","remark":"state.thinking"}
                """;
        public static final String STATE_RESPONDING = """
                {"state":"responding","remark":"state.responding"}
                """;
    }

    public static final int RAG_TYPE_KB = 1;
    public static final int RAG_TYPE_SEARCH = 2;

    /**
     * 每块文档长度（按token算）
     */
    public static final int RAG_MAX_SEGMENT_SIZE_IN_TOKENS = 1000;

    public static final class SplitStrategy {
        public static final String RECURSIVE = "recursive";
        public static final String PARAGRAPH = "paragraph";
        public static final String LINE = "line";
        public static final String SENTENCE = "sentence";
        public static final String CUSTOM = "custom";
    }

    /**
     * Parent-child mode child chunk size bounds in tokens
     */
    public static final class ChildChunkSize {
        public static final int MIN = 50;
        public static final int MAX = 4000;
        public static final int DEFAULT = 200;
    }

    /**
     * 分段来源（adi_document_segment.source）。
     * doc: 文档入库切分产生；manual: 页面手动创建；annotation: 预留给后续的聊天标注功能
     * （标注 = source=annotation 的 QA 段，复用问答模式结构与检索展开逻辑）。
     */
    public static final class SegmentSource {
        public static final String DOC = "doc";
        public static final String MANUAL = "manual";
        public static final String ANNOTATION = "annotation";
    }

    /**
     * 文档召回默认数量
     */
    public static final int RAG_RETRIEVE_NUMBER_DEFAULT = 3;

    /**
     * 文档召回最大数量
     */
    public static final int RAG_RETRIEVE_NUMBER_MAX = 5;

    /**
     * 向量搜索时命中所需的最低分数
     */
    public static final double RAG_MIN_SCORE = 0.6;

    /**
     * <p>Default fallback used only when a model has no explicit maxInputTokens configured.</p>
     */
    public static final int LLM_MAX_INPUT_TOKENS_DEFAULT = 32768;

    public static final String LLM_INPUT_TYPE_TEXT = "text";
    public static final String LLM_INPUT_TYPE_IMAGE = "image";
    public static final String LLM_INPUT_TYPE_AUDIO = "audio";
    public static final String LLM_INPUT_TYPE_VIDEO = "video";

    public static final String[] GRAPH_ENTITY_EXTRACTION_ENTITY_TYPES = {"ORGANIZATION", "PERSON", "GEO", "EVENT"};
    public static final String GRAPH_TUPLE_DELIMITER = "<|>";
    public static final String GRAPH_RECORD_DELIMITER = "##";
    public static final String GRAPH_COMPLETION_DELIMITER = "<|COMPLETE|>";

    public static final List<String> GRAPH_STORE_MAIN_FIELDS = List.of("name", "label", "text_segment_id", "description");

    /**
     * 唯一标识字段，如果该字段有指定，则根据该配置判断Vertex或Edge是否唯一，如知识库中根据 name、metadata->>kb_uuid 来做判断
     */
    public static final String GRAPH_METADATA_IDENTIFY_COLUMNS = "graph_metadata_identify_columns";

    /**
     * 内容追加字段
     * 更新数据时，如遇到该标识中的字段，追加内容而不是替换
     */
    public static final String GRAPH_METADATA_APPEND_COLUMNS = "graph_metadata_append_columns_if_exist";

    public static final int AI_IMAGE_TYPE_REGULAR = 1;
    public static final int AI_IMAGE_TYPE_THUMBNAIL = 2;
    public static final int AI_IMAGE_TYPE_REGULAR_MARK = 3;
    public static final int AI_IMAGE_TYPE_THUMBNAIL_MARK = 4;

    public static final String DOC_INDEX_TYPE_EMBEDDING = "embedding";
    public static final String DOC_INDEX_TYPE_GRAPHICAL = "graphical";

    public static final String DRAW_TYPE_PUBLIC = "public";
    public static final String DRAW_TYPE_STARRED = "starred";
    public static final String DRAW_TYPE_MINE = "mine";

    public static final String MP_LIMIT_1 = "limit 1";

    /**
     * 文件存储在本地
     */
    public static final int STORAGE_LOCATION_VALUE_LOCAL = 1;

    /**
     * 文件存储到阿里云OSS
     */
    public static final int STORAGE_LOCATION_VALUE_ALI_OSS = 2;

    public static final String URL_PREFIX_FILE = "/file/";
    public static final String URL_PREFIX_IMAGE = "/image/";
    public static final String URL_PREFIX_MY_IMAGE = "/my-image/";
    public static final String URL_PREFIX_MY_THUMBNAIL = "/my-thumbnail/";

    public static final List<String> IMAGE_EXTENSIONS = List.of("jpg", "jpeg", "png", "gif", "bmp", "webp");

    public static final String W_FAILED = "FAILED";

    public static final String COLUMN_NAME_IS_DELETE = "is_deleted";
    public static final String COLUMN_NAME_USER_ID = "user_id";
    public static final String COLUMN_NAME_ID = "id";
    public static final String COLUMN_NAME_UUID = "uuid";

    public static final String FORM_DATA_BOUNDARY_PRE = "----WebKitFormBoundary";

    public static final String RESPONSE_FORMAT_TYPE_TEXT = "text";

    public static final String RESPONSE_FORMAT_TYPE_JSON_OBJECT = "json_object";

    public static class WorkflowConstant {
        public static final String DEFAULT_INPUT_PARAM_NAME = "input";
        public static final String DEFAULT_OUTPUT_PARAM_NAME = "output";
        public static final String DEFAULT_ERROR_OUTPUT_PARAM_NAME = "error_msg";
        public static final String HUMAN_FEEDBACK_KEY = "human_feedback";
        public static final int NODE_PROCESS_STATUS_READY = 1;
        public static final int NODE_PROCESS_STATUS_DOING = 2;
        public static final int NODE_PROCESS_STATUS_SUCCESS = 3;
        public static final int NODE_PROCESS_STATUS_FAIL = 4;

        public static final int WORKFLOW_PROCESS_STATUS_READY = 1;
        public static final int WORKFLOW_PROCESS_STATUS_DOING = 2;
        public static final int WORKFLOW_PROCESS_STATUS_SUCCESS = 3;
        public static final int WORKFLOW_PROCESS_STATUS_FAIL = 4;
        public static final int WORKFLOW_PROCESS_STATUS_WAITING_INPUT = 5;

        public static final int WORKFLOW_NODE_PROCESS_TYPE_NORMAL = 1;
        public static final int WORKFLOW_NODE_PROCESS_TYPE_CONDITIONAL = 2;
        public static final int WORKFLOW_NODE_PROCESS_TYPE_PARALLEL = 3;

        public static final int MAIL_SENDER_TYPE_SYS = 1;
        public static final int MAIL_SENDER_TYPE_CUSTOM = 2;
    }

    public static class TokenEstimator {
        public static String OPENAI = "openai";
        public static String HUGGING_FACE = "huggingface";
        public static String QWEN = "qwen";

        public static List<String> ALL = List.of(OPENAI, HUGGING_FACE, QWEN);
    }

    public static class EmbeddingModel {
        public static String ALL_MINILM_L6 = "local:all-minilm-l6-v2";
        public static String BGE_SMALL_ZH_V15 = "local:bge-small-zh-v1.5";
        public static int BGE_SMALL_ZH_V15_DIMENSION = 512;
        public static List<String> LOCAL_MODELS = List.of(ALL_MINILM_L6, BGE_SMALL_ZH_V15);
    }

    public static class McpConstant {
        public static final String TRANSPORT_TYPE_SSE = "sse";
        public static final String TRANSPORT_TYPE_STDIO = "stdio";
        public static final String TRANSPORT_TYPE_STREAMABLE_HTTP = "streamable_http";
        public static final String INSTALL_TYPE_REMOTE = "remote";
        public static final String INSTALL_TYPE_WASM = "wasm";
        public static final String INSTALL_TYPE_LOCAL = "local";
        public static final String INSTALL_TYPE_DOCKER = "docker";
    }

    public static class TtsConstant {

        /**
         * 语音合成器位置-客户端
         */
        public static final String SYNTHESIZER_CLIENT = "client";
        /**
         * 语音合成器位置-服务端
         */
        public static final String SYNTHESIZER_SERVER = "server";

        /**
         * 通义默认语音音色-龙小淳(知性积极女)
         */
        public static final String DASHSCOPE_DEFAULT_VOICE = "longxiaochun_v3";
        public static final String SILICONFLOW_DEFAULT_VOICE = "FunAudioLLM/CosyVoice2-0.5B:alex";
        public static final String OPENAI_DEFAULT_VOICE = "alloy";
    }

    public static class CustomChatRequestParameterKeys {
        private CustomChatRequestParameterKeys() {
        }

        /**
         * 是否开启思考模式，默认不开启
         */
        public static final String ENABLE_THINKING = "enable_thinking";
        /**
         * 是否启用联网搜索功能
         */
        public static final String ENABLE_WEB_SEARCH = "enable_web_search";
    }

    public static class MemoryEvent {
        private MemoryEvent() {
        }

        public static final String NONE = "NONE";
        public static final String ADD = "ADD";
        public static final String UPDATE = "UPDATE";
        public static final String DELETE = "DELETE";
    }

    /**
     * 情景事件重要性默认值（1-5）。
     * <p>
     * Default importance for episodic events.
     */
    public static final int EPISODIC_IMPORTANCE_DEFAULT = 3;

    /**
     * 召回数据的来源：knowledge_base character_memory web
     */
    public static class RetrieveContentFrom {
        private RetrieveContentFrom() {
        }

        public static final String KNOWLEDGE_BASE = "knowledge_base";
        public static final String CHARACTER_MEMORY = "character_memory";
        /**
         * 情景记忆召回通道，使用独立的向量库（与 CHARACTER_MEMORY 物理隔离）。
         * <p>
         * Episodic memory retrieval channel. Uses its own physically isolated vector store
         * (separate from CHARACTER_MEMORY) so the two channels never compete for top-K.
         */
        public static final String CHARACTER_MEMORY_EPISODIC = "character_memory_episodic";
        public static final String WEB = "web";
    }

}
