package com.moyz.adi.chat.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.moyz.adi.common.base.ThreadContext;
import com.moyz.adi.common.dto.KbEditReq;
import com.moyz.adi.common.dto.KbInfoResp;
import com.moyz.adi.common.dto.KbDocumentIndexBatchReq;
import com.moyz.adi.common.dto.KbSearchReq;
import com.moyz.adi.common.entity.AdiFile;
import com.moyz.adi.common.entity.KnowledgeBase;
import com.moyz.adi.common.enums.SegmentModeEnum;
import com.moyz.adi.common.service.KnowledgeBaseService;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/knowledge-base")
@Validated
public class KnowledgeBaseController {

    @Resource
    private KnowledgeBaseService knowledgeBaseService;

    @PostMapping("/saveOrUpdate")
    public KnowledgeBase saveOrUpdate(@RequestBody @Valid KbEditReq kbEditReq) {
        return knowledgeBaseService.saveOrUpdate(kbEditReq);
    }

    @PostMapping(path = "/uploadDocs/{uuid}", headers = "content-type=multipart/form-data", produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean uploadDocs(@PathVariable String uuid,
                              @RequestParam(value = "indexAfterUpload", defaultValue = "true") Boolean indexAfterUpload,
                              @RequestParam(defaultValue = "") String indexTypes,
                              @RequestParam("files") MultipartFile[] docs) {
        List<String> indexTypeList = Arrays.stream(indexTypes.split(",")).map(String::trim).filter(s -> !s.isEmpty()).collect(Collectors.toList());
        knowledgeBaseService.uploadDocs(uuid, indexAfterUpload, docs, indexTypeList);
        return true;
    }

    /**
* Upload, parse and index documents
     * 上传、解析并索引文档
*
* @param uuid             知识库uuid / Knowledge base UUID
* @param indexAfterUpload 是否上传完接着索引文档 / Whether to index documents after upload
* @param doc              二进制文件 / Binary file
* @param segmentMode      segment mode (text/qa/parent_child); qa parses the file as Q&A pair data and vectorizes immediately
* @param childMaxChunkSize child chunk max token size, used by parent-child mode only
* @return the uploaded file info
     */
    @PostMapping(path = "/upload/{uuid}", headers = "content-type=multipart/form-data", produces = MediaType.APPLICATION_JSON_VALUE)
    public AdiFile upload(@PathVariable String uuid,
                          @RequestParam(value = "indexAfterUpload", defaultValue = "true") Boolean indexAfterUpload,
                          @RequestParam(defaultValue = "") String indexTypes,
                          @RequestParam(value = "segmentMode", required = false) SegmentModeEnum segmentMode,
                          @RequestParam(value = "childMaxChunkSize", required = false) Integer childMaxChunkSize,
                          @RequestParam("file") MultipartFile doc) {
        List<String> indexTypeList = Arrays.stream(indexTypes.split(",")).map(String::trim).filter(s -> !s.isEmpty()).collect(Collectors.toList());
        return knowledgeBaseService.uploadDoc(uuid, indexAfterUpload, doc, indexTypeList, segmentMode, childMaxChunkSize);
    }

    /**
* Search my knowledge bases
     * 搜索我的知识库
     *
* @param keyword             搜索关键词 / Search keyword
* @param includeOthersPublic 是否包含其他人公开的知识库 / Whether to include other users' public knowledge bases
* @param currentPage         当前页数 / Current page number
* @param pageSize            每页数量 / Page size
     * @return 我的知识库列表
     */
    @GetMapping("/mine/search")
    public Page<KbInfoResp> searchMine(@RequestParam(defaultValue = "") String keyword,
                                       @RequestParam(defaultValue = "false") Boolean includeOthersPublic,
                                       @NotNull @Min(1) Integer currentPage,
                                       @NotNull @Min(1) @Max(100) Integer pageSize) {
        return knowledgeBaseService.searchMine(keyword, includeOthersPublic, currentPage, pageSize);
    }

    /**
* Search public knowledge bases
     * 搜索公开的知识库
     *
* @param keyword     搜索关键词 / Search keyword
* @param currentPage 当前页数 / Current page number
* @param pageSize    每页数量 / Page size
     * @return 知识库列表
     */
    @GetMapping("/public/search")
    public Page<KbInfoResp> searchPublic(@RequestParam(defaultValue = "") String keyword,
                                         @NotNull @Min(1) Integer currentPage,
                                         @NotNull @Min(1) @Max(100) Integer pageSize) {
        return knowledgeBaseService.search(KbSearchReq.builder().isPublic(true).title(keyword).build(), currentPage, pageSize);
    }

    /**
     * Knowledge base details
     * 知识库详情
     *
     * @param uuid 知识库uuid / Knowledge base UUID
     * @return 知识库详情
     */
    @GetMapping("/info/{uuid}")
    public KnowledgeBase info(@PathVariable String uuid) {
        // read privilege like every other KB-scoped endpoint: without it any authenticated
        // user can read a private KB's full entity (owner, prompts, retrieval config)
        knowledgeBaseService.checkReadPrivilege(uuid);
        return knowledgeBaseService.lambdaQuery()
                .eq(KnowledgeBase::getUuid, uuid)
                .eq(KnowledgeBase::getIsDeleted, false)
                .one();
    }

    /**
     * 删除知识库
     *
* @param uuid 知识库uuid / Knowledge base UUID
     * @return 成功或失败
     */
    @PostMapping("/del/{uuid}")
    public boolean softDelete(@PathVariable String uuid) {
        return knowledgeBaseService.softDelete(uuid);
    }

    /**
* Index entire knowledge base
     * 索引整个知识库
     *
* @param uuid 知识库uuid / Knowledge base UUID
     * @return 成功或失败
     */
    @PostMapping("/indexing/{uuid}")
    public boolean indexing(@PathVariable String uuid, @RequestParam(defaultValue = "") String indexTypes) {
        List<String> indexTypeList = Arrays.stream(indexTypes.split(",")).map(String::trim).filter(s -> !s.isEmpty()).collect(Collectors.toList());
        return knowledgeBaseService.indexing(uuid, indexTypeList);
    }

    /**
* Batch index knowledge points
     * 批量索引知识点
     *
* @param req 知识点列表 / Knowledge point list
     * @return 成功或失败
     */
    @PostMapping("/item/indexing-list")
    public boolean indexItems(@RequestBody @Valid KbDocumentIndexBatchReq req) {
        return knowledgeBaseService.indexItems(List.of(req.getUuids()), List.of(req.getIndexTypes()));
    }

    /**
* Check if knowledge base indexing is complete
     * 检查知识库是否已经索引完成
     *
     * @return 成功或失败
     */
    @GetMapping("/indexing/check")
    public boolean checkIndex() {
        return knowledgeBaseService.checkIndexIsFinish();
    }

    /**
* Like/Star
     * 点赞
     *
     * @return true:star;false:unstar
     */
    @PostMapping("/star/toggle")
    public boolean star(@RequestParam @NotBlank String kbUuid) {
        return knowledgeBaseService.toggleStar(ThreadContext.getCurrentUser(), kbUuid);
    }
}
