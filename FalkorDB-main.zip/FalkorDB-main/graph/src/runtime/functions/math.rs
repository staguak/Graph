//! Numeric and general math functions.
//!
//! Standard Cypher math operations plus utility functions like `range()`
//! and `coalesce()`.  All functions propagate `Null` following
//! three-valued logic.
//!
//! ```text
//!  Cypher           Function       Returns
//! ──────────────────────────────────────────────
//!  abs(x)           abs()          Int | Float
//!  ceil(x)          ceil()         Int | Float
//!  e()              e()            Float (Euler's number)
//!  exp(x)           exp()          Float
//!  floor(x)         floor()        Int | Float
//!  log(x)           log()          Float (natural log)
//!  log10(x)         log10()        Float
//!  randomUUID()     random_uuid()  String (v4 UUID)
//!  x ^ y            apply_pow()    Float  (also used by expr eval)
//!  pow(x, y)        pow()          Float  (wraps apply_pow)
//!  rand()           rand()         Float  [0, 1)
//!  round(x)         round()        Int | Float
//!  sign(x)          sign()         Int
//!  sqrt(x)          sqrt()         Float
//!  range(s, e [,step]) range()     [Int]  (Arc-wrapped)
//!  coalesce(...)    coalesce()     first non-Null arg
//! ```
//!
//! `apply_pow` is the only `pub` item (re-exported from `mod.rs`) because
//! the runtime expression evaluator uses it directly for the `^` operator.

#![allow(clippy::unnecessary_wraps)]
#![allow(clippy::cast_sign_loss)]
#![allow(clippy::cast_possible_wrap)]
#![allow(clippy::cast_precision_loss)]

use super::{FnType, Functions, Type};
use crate::runtime::{runtime::Runtime, value::Value};
use rand::RngExt;
use std::sync::Arc;
use thin_vec::thin_vec;

pub fn register(funcs: &mut Functions) {
    cypher_fn!(funcs, "abs",
        args: [Type::union([Type::Int, Type::Float, Type::Null])],
        ret: Type::union([Type::Int, Type::Float, Type::Null]),
        fn abs(_, args) {
            match &args[0] {
                Value::Int(n) => n
                    .checked_abs()
                    .map(Value::Int)
                    .ok_or_else(|| String::from("ArgumentError: integer overflow in abs()")),
                Value::Float(f) => Ok(Value::Float(f.abs())),
                Value::Null => Ok(Value::Null),

                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "ceil",
        args: [Type::union([Type::Int, Type::Float, Type::Null])],
        ret: Type::union([Type::Int, Type::Float, Type::Null]),
        fn ceil(_, args) {
            match &args[0] {
                Value::Int(n) => Ok(Value::Int(*n)),
                Value::Float(f) => Ok(Value::Float(f.ceil())),
                Value::Null => Ok(Value::Null),

                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "e",
        args: [],
        ret: Type::Float,
        fn e(_, args) {
            debug_assert!(args.is_empty());
            Ok(Value::Float(std::f64::consts::E))
        }
    );

    cypher_fn!(funcs, "exp",
        args: [Type::union([Type::Int, Type::Float, Type::Null])],
        ret: Type::union([Type::Float, Type::Null]),
        fn exp(_, args) {
            match &args[0] {
                Value::Int(n) => Ok(Value::Float((*n as f64).exp())),
                Value::Float(f) => Ok(Value::Float(f.exp())),
                Value::Null => Ok(Value::Null),

                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "floor",
        args: [Type::union([Type::Int, Type::Float, Type::Null])],
        ret: Type::union([Type::Int, Type::Float, Type::Null]),
        fn floor(_, args) {
            match &args[0] {
                Value::Int(n) => Ok(Value::Int(*n)),
                Value::Float(f) => Ok(Value::Float(f.floor())),
                Value::Null => Ok(Value::Null),

                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "log",
        args: [Type::union([Type::Int, Type::Float, Type::Null])],
        ret: Type::union([Type::Float, Type::Null]),
        fn log(_, args) {
            match &args[0] {
                Value::Int(n) => Ok(Value::Float((*n as f64).ln())),
                Value::Float(f) => Ok(Value::Float(f.ln())),
                Value::Null => Ok(Value::Null),

                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "log10",
        args: [Type::union([Type::Int, Type::Float, Type::Null])],
        ret: Type::union([Type::Float, Type::Null]),
        fn log10(_, args) {
            match &args[0] {
                Value::Int(n) => Ok(Value::Float((*n as f64).log10())),
                Value::Float(f) => Ok(Value::Float(f.log10())),
                Value::Null => Ok(Value::Null),

                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "randomUUID",
        args: [],
        ret: Type::String,
        non_deterministic,
        fn random_uuid(_, _args) {
            // Generate 16 random bytes (128 bits)
            let mut rng = rand::rng();
            let mut bytes = [0u8; 16];
            rng.fill(&mut bytes);

            // Set version to 4 (random UUID) - set bits 12-15 of byte 6 to 0100
            bytes[6] = (bytes[6] & 0x0F) | 0x40;

            // Set variant to RFC 4122 - set bits 6-7 of byte 8 to 10
            bytes[8] = (bytes[8] & 0x3F) | 0x80;

            // Format as UUID string:  xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx
            let uuid = format!(
                "{:08x}-{:04x}-{:04x}-{:04x}-{:04x}{:08x}",
                u32::from_be_bytes([bytes[0], bytes[1], bytes[2], bytes[3]]),
                u16::from_be_bytes([bytes[4], bytes[5]]),
                u16::from_be_bytes([bytes[6], bytes[7]]),
                u16::from_be_bytes([bytes[8], bytes[9]]),
                u16::from_be_bytes([bytes[10], bytes[11]]),
                u32::from_be_bytes([bytes[12], bytes[13], bytes[14], bytes[15]]),
            );

            Ok(Value::String(Arc::new(uuid)))
        }
    );

    cypher_fn!(funcs, "pow",
        args: [
            Type::union([Type::Int, Type::Float, Type::Null]),
            Type::union([Type::Int, Type::Float, Type::Null]),
        ],
        ret: Type::union([Type::Float, Type::Null]),
        fn pow(_, args) {
            apply_pow(args[0].clone(), args[1].clone())
        }
    );

    cypher_fn!(funcs, "rand",
        args: [],
        ret: Type::Float,
        non_deterministic,
        #[allow(clippy::needless_pass_by_value)]
        fn rand(_, args) {
            debug_assert!(args.is_empty());
            let mut rng = rand::rng();
            Ok(Value::Float(rng.random_range(0.0..1.0)))
        }
    );

    cypher_fn!(funcs, "round",
        args: [Type::union([Type::Int, Type::Float, Type::Null])],
        ret: Type::union([Type::Int, Type::Float, Type::Null]),
        fn round(_, args) {
            match &args[0] {
                Value::Int(n) => Ok(Value::Int(*n)),
                Value::Float(f) => Ok(Value::Float(f.round())),
                Value::Null => Ok(Value::Null),

                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "sign",
        args: [Type::union([Type::Int, Type::Float, Type::Null])],
        ret: Type::union([Type::Int, Type::Null]),
        fn sign(_, args) {
            match &args[0] {
                Value::Int(n) => Ok(Value::Int(n.signum())),
                // Integer result like C and openCypher; ±0.0 and NaN give 0.
                Value::Float(f) => Ok(Value::Int(i64::from(*f > 0.0) - i64::from(*f < 0.0))),
                Value::Null => Ok(Value::Null),

                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "sqrt",
        args: [Type::union([Type::Int, Type::Float, Type::Null])],
        ret: Type::union([Type::Float, Type::Null]),
        fn sqrt(_, args) {
            match &args[0] {
                Value::Int(n) => {
                    if *n < 0 {
                        Ok(Value::Float(f64::NAN))
                    } else {
                        Ok(Value::Float((*n as f64).sqrt()))
                    }
                }
                Value::Float(f) => {
                    if *f >= 0f64 {
                        Ok(Value::Float(f.sqrt()))
                    } else {
                        Ok(Value::Float(f64::NAN))
                    }
                }
                Value::Null => Ok(Value::Null),

                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "range",
        args: [Type::Int, Type::Int, Type::Optional(Box::new(Type::Int))],
        ret: Type::union([Type::List(Box::new(Type::Int)), Type::Null]),
        fn range(_, args) {
            let start = &args[0];
            let end = &args[1];
            let step_owned;
            let step = if args.len() > 2 {
                &args[2]
            } else {
                step_owned = Value::Int(1);
                &step_owned
            };
            match (start, end, step) {
                (Value::Int(start), Value::Int(end), Value::Int(step)) => {
                    let (start, end, step) = (*start, *end, *step);
                    if step == 0 {
                        return Err(String::from(
                            "ArgumentError: step argument to range() can't be 0",
                        ));
                    }
                    if (start > end && step > 0) || (start < end && step < 0) {
                        return Ok(Value::List(Arc::new(thin_vec![])));
                    }

                    // Compute (|end - start| / |step|) + 1 with overflow checks.
                    // We use unsigned absolute differences so that
                    // `range(i64::MIN, i64::MAX)` doesn't overflow the
                    // intermediate subtraction.
                    let span = if end >= start {
                        (end as i128) - (start as i128)
                    } else {
                        (start as i128) - (end as i128)
                    };
                    let abs_step = (step as i128).unsigned_abs();
                    let length = (span.unsigned_abs() / abs_step)
                        .checked_add(1)
                        .ok_or_else(|| String::from("Range too large"))?;
                    if length > u32::MAX as u128 {
                        return Err(String::from("Range too large"));
                    }
                    if step > 0 {
                        return Ok(Value::List(Arc::new(
                            (start..=end)
                                .step_by(step as usize)
                                .map(Value::Int)
                                .collect(),
                        )));
                    }
                    Ok(Value::List(Arc::new(
                        (end..=start)
                            .rev()
                            .step_by(step.unsigned_abs() as usize)
                            .map(Value::Int)
                            .collect(),
                    )))
                }

                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "coalesce",
        var_arg: Type::Any,
        ret: Type::Any,
        fn coalesce(_, args) {
            for arg in args {
                if *arg == Value::Null {
                    continue;
                }
                return Ok(arg.clone());
            }
            Ok(Value::Null)
        }
    );
}

// called from fn pow and expr pow (^)
#[inline]
pub fn apply_pow(
    base: Value,
    exponent: Value,
) -> Result<Value, String> {
    // `pow()` is guarded by its declared argument types, but the `^`
    // operator is not, so reject non-numeric operands here (as C does),
    // even when the other operand is null.
    if let Some(v) = [&base, &exponent]
        .into_iter()
        .find(|v| !matches!(v, Value::Int(_) | Value::Float(_) | Value::Null))
    {
        return Err(format!(
            "Type mismatch: expected Integer, Float, or Null but was {}",
            v.name()
        ));
    }
    if matches!(base, Value::Null) || matches!(exponent, Value::Null) {
        return Ok(Value::Null);
    }
    // Both are numeric: convert to f64 and use powf, as C does:
    // pow(SI_GET_NUMERIC(base), SI_GET_NUMERIC(exp))
    Ok(Value::Float(
        base.get_numeric().powf(exponent.get_numeric()),
    ))
}
