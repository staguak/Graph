//! Graph-entity inspection functions.
//!
//! Functions that inspect nodes, relationships, and paths -- the structural
//! elements of the property graph.
//!
//! ```text
//!  Cypher              Function        Returns
//! ──────────────────────────────────────────────────
//!  labels(n)           labels()        [String]
//!  typeOf(x)           type_of()       String
//!  hasLabels(n, [...]) has_labels()    Bool
//!  id(n)               id()            Int
//!  properties(n)       properties()    Map
//!  startNode(r)        start_node()    Node
//!  endNode(r)          end_node()      Node
//!  length(p)           length()        Int (edges in path)
//!  type(r)             relationship_type() String
//!  keys(n)             keys()          [String]
//!  exists(x)           exists()        Bool
//! ```
//!
//! Every function receives a `ThinVec<Value>` of already-validated
//! arguments and returns `Result<Value, String>`.  A `&Runtime` is
//! provided for graph access (e.g. resolving node labels from the
//! label matrices).

#![allow(clippy::unnecessary_wraps)]

use super::{FnType, Functions, Type};
use crate::graph::graph::NodeId;
use crate::runtime::value::ValueGetType;
use crate::runtime::{runtime::Runtime, value::Value};
use std::sync::Arc;
use thin_vec::ThinVec;

pub fn register(funcs: &mut Functions) {
    cypher_fn!(funcs, "labels",
        args: [Type::union([Type::Node, Type::Null])],
        ret: Type::union([Type::List(Box::new(Type::String)), Type::Null]),
        fn labels(runtime, args) {
            match args.first() {
                Some(&Value::Node(id)) => {
                    let labels = runtime.get_node_labels(id);
                    Ok(Value::List(Arc::new(labels.into_iter().map(Value::String).collect())))
                }
                Some(Value::Null) => Ok(Value::Null),

                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "typeOf",
        args: [Type::Any],
        ret: Type::String,
        fn type_of(_runtime, args) {
            let type_name = args.first().map_or_else(|| unreachable!(), Value::name);
            Ok(Value::String(Arc::new(String::from(type_name))))
        }
    );

    cypher_fn!(funcs, "hasLabels",
        args: [
            Type::union([Type::Node, Type::Null]),
            Type::List(Box::new(Type::Any)),
        ],
        ret: Type::union([Type::Bool, Type::Null]),
        fn has_labels(runtime, args) {
            let mut iter = args.iter();
            match (iter.next(), iter.next()) {
                (Some(&Value::Node(id)), Some(Value::List(required_labels))) => {
                    // One pass: a label is interpreted, and rejected, in exactly
                    // one place. The whole list is still type-checked even once
                    // the answer is settled — `hasLabels(n, ['A', 1])` is an
                    // error, not `false`.
                    let mut has_all = true;
                    for label_value in required_labels.iter() {
                        let name = match label_value {
                            Value::String(name) => name,
                            Value::Int(_) => {
                                return Err("Type mismatch: expected String but was Integer".to_string());
                            }
                            Value::Float(_) => {
                                return Err("Type mismatch: expected String but was Float".to_string());
                            }
                            Value::Bool(_) => {
                                return Err("Type mismatch: expected String but was Boolean".to_string());
                            }
                            _ => {
                                return Err(format!(
                                    "Type mismatch: expected String but was {}",
                                    label_value.name()
                                ));
                            }
                        };
                        // The `n:Label` predicate's hot path, once per row: one
                        // bit of the label matrix instead of the node's whole
                        // label set.
                        has_all = has_all && runtime.node_has_label(id, name);
                    }

                    Ok(Value::Bool(has_all))
                }
                (Some(Value::Null), _) | (_, Some(Value::Null)) => Ok(Value::Null),
                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "id",
        args: [Type::union([
            Type::Node,
            Type::Relationship,
            Type::Null,
        ])],
        ret: Type::union([Type::Int, Type::Null]),
        fn id(_runtime, args) {
            match args.first() {
                Some(&Value::Node(id)) => Ok(Value::Int(u64::from(id) as i64)),
                Some(Value::Relationship(rel)) => Ok(Value::Int(u64::from(*rel) as i64)),
                Some(Value::Null) => Ok(Value::Null),

                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "properties",
        args: [Type::union([
            Type::Map,
            Type::Node,
            Type::Relationship,
            Type::Null,
        ])],
        ret: Type::union([Type::Map, Type::Null]),
        fn properties(runtime, args) {
            match args.first() {
                Some(Value::Map(map)) => Ok(Value::Map(map.clone())),
                Some(&Value::Node(id)) => Ok(Value::Map(Arc::new(runtime.get_node_attrs(id)))),
                Some(Value::Relationship(rel)) => {
                    Ok(Value::Map(Arc::new(runtime.get_relationship_attrs(*rel))))
                }
                Some(Value::Null) => Ok(Value::Null),

                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "startnode",
        args: [Type::union([Type::Relationship, Type::Null])],
        ret: Type::union([Type::Node, Type::Null]),
        fn start_node(runtime, args) {
            match args.first() {
                Some(Value::Relationship(rel)) => {
                    let (src, _dst) = runtime.get_relationship_endpoints(*rel);
                    Ok(Value::Node(src))
                }
                Some(Value::Null) => Ok(Value::Null),

                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "endnode",
        args: [Type::union([Type::Relationship, Type::Null])],
        ret: Type::union([Type::Node, Type::Null]),
        fn end_node(runtime, args) {
            match args.first() {
                Some(Value::Relationship(rel)) => {
                    let (_src, dst) = runtime.get_relationship_endpoints(*rel);
                    Ok(Value::Node(dst))
                }
                Some(Value::Null) => Ok(Value::Null),

                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "length",
        args: [Type::union([Type::Path, Type::Null])],
        ret: Type::union([Type::Int, Type::Null]),
        fn length(_runtime, args) {
            match args.first() {
                Some(Value::Path(path)) => Ok(Value::Int(path.len() as i64 / 2)),
                Some(Value::Null) => Ok(Value::Null),

                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "keys",
        args: [Type::union([
            Type::Map,
            Type::Node,
            Type::Relationship,
            Type::Null,
        ])],
        ret: Type::union([Type::List(Box::new(Type::String)), Type::Null]),
        fn keys(runtime, args) {
            match args.first() {
                Some(Value::Map(map)) => Ok(Value::List(Arc::new(
                    map.keys().cloned().map(Value::String).collect(),
                ))),
                Some(&Value::Node(id)) => Ok(Value::List(Arc::new(
                    runtime
                        .get_node_attrs(id)
                        .into_iter()
                        .map(|(k, _)| Value::String(k))
                        .collect::<ThinVec<_>>(),
                ))),
                Some(Value::Relationship(rel)) => Ok(Value::List(Arc::new(
                    runtime
                        .get_relationship_attrs(*rel)
                        .into_iter()
                        .map(|(k, _)| Value::String(k))
                        .collect::<ThinVec<_>>(),
                ))),
                Some(Value::Null) => Ok(Value::Null),

                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "type",
        args: [Type::union([Type::Relationship, Type::Null])],
        ret: Type::union([Type::String, Type::Null]),
        fn relationship_type(runtime, args) {
            match args.first() {
                Some(Value::Relationship(rel)) => runtime
                    .get_relationship_type(*rel)
                    .map_or_else(|| Ok(Value::Null), |type_name| Ok(Value::String(type_name))),
                Some(Value::Null) => Ok(Value::Null),
                _ => unreachable!(),
            }
        }
    );

    cypher_fn!(funcs, "exists",
        args: [Type::Any],
        ret: Type::union([Type::Bool, Type::Null]),
        fn exists(_, args) {
            match args.first() {
                Some(Value::Null) => Ok(Value::Bool(false)),
                _ => Ok(Value::Bool(true)),
            }
        }
    );

    cypher_fn!(funcs, "indegree",
        var_arg: Type::Any,
        ret: Type::union([Type::Int, Type::Null]),
        fn indegree(runtime, args) {
            let (id, types) = parse_degree_args("indegree", args)?;
            id.map_or_else(|| Ok(Value::Null), |id| {
                    let count = if types.is_empty() {
                        runtime.get_node_indegree(id)
                    } else {
                        runtime.get_node_indegree_by_type(id, &types)
                    };
                    Ok(Value::Int(count as i64))
                })
        }
    );

    cypher_fn!(funcs, "outdegree",
        var_arg: Type::Any,
        ret: Type::union([Type::Int, Type::Null]),
        fn outdegree(runtime, args) {
            let (id, types) = parse_degree_args("outdegree", args)?;
            id.map_or_else(|| Ok(Value::Null), |id| {
                    let count = if types.is_empty() {
                        runtime.get_node_outdegree(id)
                    } else {
                        runtime.get_node_outdegree_by_type(id, &types)
                    };
                    Ok(Value::Int(count as i64))
                })
        }
    );
}

/// Parse arguments for indegree/outdegree functions.
///
/// Accepted call signatures:
///   degree(node)                          → all types
///   degree(node, `type1`, `type2`, ...)   → filter by string varargs
///   degree(node, [`type1`, `type2`])      → filter by list of strings
fn parse_degree_args(
    fn_name: &str,
    args: &[Value],
) -> Result<(Option<NodeId>, Vec<Arc<String>>), String> {
    if args.is_empty() {
        return Err(format!(
            "Received 0 arguments to function '{fn_name}', expected at least 1"
        ));
    }

    let id = match &args[0] {
        Value::Node(id) => Some(*id),
        Value::Null => None,
        other => {
            return Err(format!(
                "Type mismatch: expected Node but was {}",
                other.get_type()
            ));
        }
    };

    let rest = &args[1..];
    if rest.is_empty() {
        return Ok((id, Vec::new()));
    }

    // Single list argument: degree(node, ['type1', 'type2'])
    if rest.len() == 1 {
        if let Value::List(list) = &rest[0] {
            let mut types = Vec::with_capacity(list.len());
            for v in list.iter() {
                match v {
                    Value::String(s) => {
                        if !types.contains(s) {
                            types.push(s.clone());
                        }
                    }
                    other => {
                        return Err(format!(
                            "Type mismatch: expected String but was {}",
                            other.get_type()
                        ));
                    }
                }
            }
            return Ok((id, types));
        }
    } else if matches!(rest[0], Value::List(_)) {
        // List followed by extra args: wrong argument count
        return Err(format!(
            "Received {} arguments to function '{fn_name}', expected at most 2",
            rest.len() + 1
        ));
    }

    // Varargs of strings: degree(node, 'type1', 'type2', ...)
    let mut types = Vec::with_capacity(rest.len());
    for v in rest {
        match v {
            Value::String(s) => {
                if !types.contains(s) {
                    types.push(s.clone());
                }
            }
            other => {
                return Err(format!(
                    "Type mismatch: expected String but was {}",
                    other.get_type()
                ));
            }
        }
    }

    Ok((id, types))
}

#[cfg(test)]
mod tests {
    use super::parse_degree_args;
    use crate::runtime::value::Value;
    use std::sync::Arc;
    use thin_vec::ThinVec;

    fn list(items: Vec<Value>) -> Value {
        let mut v = ThinVec::with_capacity(items.len());
        for item in items {
            v.push(item);
        }
        Value::List(Arc::new(v))
    }

    fn s(v: &str) -> Value {
        Value::String(Arc::new(v.to_string()))
    }

    // `indegree`/`outdegree` are var-len, so `validate_args_type` is a no-op
    // for them and this hand-rolled check is the only one they get. It named
    // the received type with `{:?}` ("Int", "List(List(Any))") instead of the
    // Display vocabulary the framework and C both use ("Integer", "List").
    #[test]
    fn node_argument_mismatch_names_the_received_type() {
        let err = parse_degree_args("indegree", &[Value::Int(1)]).unwrap_err();
        assert_eq!(err, "Type mismatch: expected Node but was Integer");
    }

    #[test]
    fn list_argument_mismatch_names_the_received_type() {
        let err =
            parse_degree_args("outdegree", &[Value::Null, list(vec![Value::Int(1)])]).unwrap_err();
        assert_eq!(err, "Type mismatch: expected String but was Integer");
    }

    #[test]
    fn vararg_mismatch_names_the_received_type() {
        let err = parse_degree_args("outdegree", &[Value::Null, Value::Int(1)]).unwrap_err();
        assert_eq!(err, "Type mismatch: expected String but was Integer");
    }

    #[test]
    fn a_bare_number_after_a_string_still_names_the_type() {
        let err =
            parse_degree_args("outdegree", &[Value::Null, s("R"), Value::Int(1)]).unwrap_err();
        assert_eq!(err, "Type mismatch: expected String but was Integer");
    }

    #[test]
    fn the_arity_message_is_untouched() {
        let err =
            parse_degree_args("outdegree", &[Value::Null, list(vec![s("R")]), s("R")]).unwrap_err();
        assert_eq!(
            err,
            "Received 3 arguments to function 'outdegree', expected at most 2"
        );
    }

    #[test]
    fn the_accepted_shapes_are_untouched() {
        assert_eq!(
            parse_degree_args("indegree", &[Value::Null]).unwrap(),
            (None, Vec::new())
        );
        assert_eq!(
            parse_degree_args("outdegree", &[Value::Null, list(vec![s("R")])]).unwrap(),
            (None, vec![Arc::new("R".to_string())])
        );
    }
}
