//! Batch-mode edge index scan operator — retrieves edges using a secondary index.
//!
//! For each active row in the input batch, evaluates the index query
//! parameters and collects matching edges. Supports equality, range,
//! and conjunctive (AND/OR) index queries.
//!
//! This operator replaces `CondTraverse` when the optimizer detects that
//! a filter on an edge property can be pushed into an edge index.
//!
//! ```text
//!  Input row ──► evaluate index query params
//!                      │
//!             ┌────────▼────────┐
//!             │ IndexQuery::    │
//!             │  Equal          │  key = value
//!             │  Range          │  min <= key <= max
//!             │  And([...])     │  conjunction of the above
//!             └────────┬────────┘
//!                      │
//!            graph.get_indexed_edges()
//!                      │
//!             output rows with edge + endpoint IDs
//! ```

use std::sync::Arc;

use crate::graph::graph::{NodeId, RelationshipId};
use crate::index::indexer::IndexQuery;
use crate::parser::ast::{QueryExpr, QueryRelationship, Variable};
use crate::planner::IR;
use crate::runtime::eval::ExprEval;
use crate::runtime::{
    batch::{Batch, BatchOp, BatchRow},
    row::RowView,
    runtime::Runtime,
    value::Value,
};
// `NodeRef` supplies the `.root()` / `.idx()` methods used below via
// trait import — it appears unused in signatures but removing it
// breaks `value.root().idx()` etc.
use orx_tree::{Dyn, NodeIdx, NodeRef};

use super::batched_result_emitter::{BatchedResultEmitter, EdgeEndpoints, RowIter};

/// Invariant: `relationship.from` is always the bound endpoint of the
/// edge scan.
///
/// `transposed` flips which graph-side endpoint the edge
/// tensor keys on (src vs dst) but the bound endpoint is always read
/// via `rp.from.alias`.
///
/// The planner's `select_scan_node` pass enforces
/// this by swapping the relationship and setting `transposed`
/// accordingly before any rewrite to `EdgeByIndexScan`.
pub struct EdgeByIndexScanOp<'a> {
    pub(crate) runtime: &'a Runtime<'a>,
    pub(crate) child: Box<BatchOp<'a>>,
    relationship_pattern: &'a QueryRelationship<Arc<String>, Arc<String>, Variable>,
    query: &'a IndexQuery<QueryExpr<Variable>>,
    transposed: bool,
    /// Holds the parent batch being expanded and the per-row edge iterators, and
    /// performs the shared pack-and-gather emit. Each pushed iterator yields
    /// `(src, dst, edge)` in graph-tensor order; the emitter's binding maps the
    /// graph sides onto the pattern's from/to endpoints (honoring `transposed`)
    /// and skips the second endpoint for self-loop patterns.
    emitter: BatchedResultEmitter<'a, (NodeId, NodeId, RelationshipId)>,
    /// Lazily-populated cache of all edges of `relationship_pattern.types[0]`
    /// for the non-indexable-runtime-value fallback. Materialized once
    /// on the first fallback and shared across subsequent input rows
    /// so we don't pay O(|E_type|) per row when the index can't serve
    /// the query (e.g. value is a list or date). The cache is
    /// dropped when the op is dropped.
    all_edges_cache: std::cell::RefCell<Option<Arc<Vec<(NodeId, NodeId, RelationshipId)>>>>,
    pub(crate) idx: NodeIdx<Dyn<IR>>,
}

impl<'a> EdgeByIndexScanOp<'a> {
    pub fn new(
        runtime: &'a Runtime<'a>,
        child: Box<BatchOp<'a>>,
        relationship_pattern: &'a QueryRelationship<Arc<String>, Arc<String>, Variable>,
        query: &'a IndexQuery<QueryExpr<Variable>>,
        transposed: bool,
        idx: NodeIdx<Dyn<IR>>,
        // Kept in the signature, unused for now: see the emitter below.
        _record_cap: Option<usize>,
    ) -> Self {
        // Self-loop patterns like `MATCH (n)-[r:T]->(n)` share one alias on both
        // endpoints; bind it once (via `from`) and skip the `to` column so the
        // second insert can't overwrite the first.
        let to = (relationship_pattern.to.alias != relationship_pattern.from.alias)
            .then_some(relationship_pattern.to.alias.id);
        Self {
            runtime,
            child,
            // `None`, for the same reason as `node_by_index_scan`: capping an
            // index scan hangs `tests/flow/test_constraint.py`, and this line
            // does it on its own. See the comment there.
            emitter: BatchedResultEmitter::with_binding(
                EdgeEndpoints {
                    from: relationship_pattern.from.alias.id,
                    to,
                    edge: relationship_pattern.alias.id,
                    transposed,
                },
                None,
            ),
            relationship_pattern,
            query,
            transposed,
            all_edges_cache: std::cell::RefCell::new(None),
            idx,
        }
    }

    fn evaluate_index_query<R: crate::runtime::row::RowView + ?Sized>(
        runtime: &Runtime,
        query: &IndexQuery<QueryExpr<Variable>>,
        vars: &R,
    ) -> Result<IndexQuery<Value>, String> {
        match query {
            IndexQuery::Equal { key, value } => {
                let value = {
                    ExprEval::from_runtime(runtime).eval(
                        value,
                        value.root().idx(),
                        Some(vars),
                        None,
                    )
                }?;
                Ok(IndexQuery::Equal {
                    key: key.clone(),
                    value,
                })
            }
            IndexQuery::Range {
                key,
                min,
                max,
                include_min,
                include_max,
            } => {
                let (min, max) = match (min, max) {
                    (Some(min), Some(max)) => {
                        let min = ExprEval::from_runtime(runtime).eval(
                            min,
                            min.root().idx(),
                            Some(vars),
                            None,
                        )?;
                        let max = ExprEval::from_runtime(runtime).eval(
                            max,
                            max.root().idx(),
                            Some(vars),
                            None,
                        )?;
                        (Some(min), Some(max))
                    }
                    (Some(min), None) => {
                        let min = ExprEval::from_runtime(runtime).eval(
                            min,
                            min.root().idx(),
                            Some(vars),
                            None,
                        )?;
                        (Some(min), None)
                    }
                    (None, Some(max)) => {
                        let max = ExprEval::from_runtime(runtime).eval(
                            max,
                            max.root().idx(),
                            Some(vars),
                            None,
                        )?;
                        (None, Some(max))
                    }
                    (None, None) => (None, None),
                };
                Ok(IndexQuery::Range {
                    key: key.clone(),
                    min,
                    max,
                    include_min: *include_min,
                    include_max: *include_max,
                })
            }
            IndexQuery::Point { key, point, radius } => {
                let point = ExprEval::from_runtime(runtime).eval(
                    point,
                    point.root().idx(),
                    Some(vars),
                    None,
                )?;
                let radius = ExprEval::from_runtime(runtime).eval(
                    radius,
                    radius.root().idx(),
                    Some(vars),
                    None,
                )?;
                Ok(IndexQuery::Point {
                    key: key.clone(),
                    point,
                    radius,
                })
            }
            IndexQuery::And(queries) => {
                let mut evaluated = Vec::with_capacity(queries.len());
                for q in queries {
                    evaluated.push(Self::evaluate_index_query(runtime, q, vars)?);
                }
                Ok(IndexQuery::And(evaluated))
            }
            IndexQuery::Or(queries) => {
                let mut evaluated = Vec::with_capacity(queries.len());
                for q in queries {
                    evaluated.push(Self::evaluate_index_query(runtime, q, vars)?);
                }
                Ok(IndexQuery::Or(evaluated))
            }
            IndexQuery::ArrayContains { key, value } => {
                let value = {
                    ExprEval::from_runtime(runtime).eval(
                        value,
                        value.root().idx(),
                        Some(vars),
                        None,
                    )
                }?;
                Ok(IndexQuery::ArrayContains {
                    key: key.clone(),
                    value,
                })
            }
            IndexQuery::InList { key, list } => {
                let list_val = {
                    ExprEval::from_runtime(runtime).eval(list, list.root().idx(), Some(vars), None)
                }?;
                match list_val {
                    // Kept as one `InList`, as in `NodeByIndexScanOp`: one attribute by
                    // construction, and RediSearch builds the same union from either shape.
                    Value::List(items) => {
                        let keep = |v: &Value| {
                            matches!(
                                v,
                                Value::Int(_) | Value::Float(_) | Value::String(_) | Value::Bool(_)
                            )
                        };
                        let items = if items.iter().all(keep) {
                            items
                        } else {
                            Arc::new(items.iter().filter(|v| keep(v)).cloned().collect())
                        };
                        Ok(IndexQuery::InList {
                            key: key.clone(),
                            list: Value::List(items),
                        })
                    }
                    _ => Err("IN operator requires a list".into()),
                }
            }
        }
    }

    /// Check if an evaluated index query can be satisfied by the index.
    fn can_utilize_index(q: &IndexQuery<Value>) -> bool {
        use crate::index::Index;

        const fn is_indexable(v: &Value) -> bool {
            match v {
                Value::Int(i) => !Index::int_loses_f64_precision(*i),
                Value::Float(_)
                | Value::String(_)
                | Value::Bool(_)
                | Value::Point(_)
                | Value::Null => true,
                _ => false,
            }
        }
        match q {
            IndexQuery::Equal { value, .. } => is_indexable(value),
            IndexQuery::Range { min, max, .. } => {
                min.as_ref().is_none_or(is_indexable) && max.as_ref().is_none_or(is_indexable)
            }
            IndexQuery::And(children) | IndexQuery::Or(children) => {
                // Empty `Or([])` / `And([])` is not a valid index
                // query: the RediSearch backend treats it as
                // match-all, which is unsafe when the optimizer has
                // already pushed an IN-list whose elements were all
                // filtered out at runtime (e.g. `IN [NULL]`). Force
                // the fallback path so the retained post-filter
                // re-establishes correctness.
                !children.is_empty() && children.iter().all(Self::can_utilize_index)
            }
            // The same rule, for an `IN` list: empty once its members were filtered (`IN [NULL]`)
            // falls back, and so does a list with any member the index cannot hold exactly.
            IndexQuery::InList { list, .. } => matches!(
                list,
                Value::List(items) if !items.is_empty() && items.iter().all(is_indexable)
            ),
            IndexQuery::ArrayContains { value, .. } => match value {
                // Match `Equal` / `Range`: reject int64s that lose
                // f64 precision — the index can't represent them
                // exactly so the query must fall back to post-filter.
                Value::Int(i) => !Index::int_loses_f64_precision(*i),
                Value::Float(_) | Value::String(_) | Value::Bool(_) => true,
                _ => false,
            },
            _ => true,
        }
    }
}

impl<'a> Iterator for EdgeByIndexScanOp<'a> {
    type Item = Result<Batch<'a>, String>;

    fn next(&mut self) -> Option<Self::Item> {
        loop {
            // One (endpoint-filtered) edge iterator per active parent row, built
            // lazily one row at a time. When the batch is exhausted (`Ok(None)`),
            // pull and seed the next child batch.
            let label = &self.relationship_pattern.types[0];
            let rp = self.relationship_pattern;
            match self.emitter.emit_lazy(|b, row| {
                let view = BatchRow::new(b, row);
                let q = Self::evaluate_index_query(self.runtime, self.query, &view)?;

                // Stream results instead of collecting: the child
                // batch may have many rows and each row would
                // otherwise materialize the full edge set before any
                // emission. Matches `NodeByIndexScanOp`'s pattern.
                //
                // On the fallback path (non-indexable runtime value),
                // `get_all_edges` is materialized once into the op's
                // cache and shared by all subsequent rows via `Arc`,
                // so we don't rebuild the full-type Vec per row.
                let base: Box<dyn Iterator<Item = (NodeId, NodeId, RelationshipId)>> =
                    if Self::can_utilize_index(&q) {
                        let g = self.runtime.graph();
                        // Edge index: a numeric Equal/Range on a column we own is served
                        // by the CoW B-tree (endpoints recovered from the graph's reverse index);
                        // string/geo/composite or a missing column falls through to RediSearch during
                        // the dark-launch. #51, mirrors `NodeByIndexScanOp`.
                        #[cfg(feature = "index-falkordb")]
                        let it: Box<
                            dyn Iterator<Item = (NodeId, NodeId, RelationshipId)>,
                        > = if let Some(hit) = g.query_index_numeric_edges(label, &q) {
                            Box::new(hit)
                        } else {
                            Box::new(g.get_indexed_edges(label, q))
                        };
                        #[cfg(not(feature = "index-falkordb"))]
                        let it: Box<
                            dyn Iterator<Item = (NodeId, NodeId, RelationshipId)>,
                        > = Box::new(g.get_indexed_edges(label, q));
                        it
                    } else {
                        let cached = {
                            let mut cache = self.all_edges_cache.borrow_mut();
                            if cache.is_none() {
                                *cache = Some(Arc::new(self.runtime.graph().get_all_edges(label)));
                            }
                            Arc::clone(cache.as_ref().unwrap())
                        };
                        let mut idx = 0usize;
                        Box::new(std::iter::from_fn(move || {
                            if idx < cached.len() {
                                let v = cached[idx];
                                idx += 1;
                                Some(v)
                            } else {
                                None
                            }
                        }))
                    };

                // An undirected pattern matches each edge in both
                // orientations (a self-loop once), as `CondTraverse` does;
                // the index yields it once, `src -> dst`.
                let oriented_hits: Box<dyn Iterator<Item = (NodeId, NodeId, RelationshipId)>> =
                    if rp.bidirectional {
                        Box::new(base.flat_map(|(src, dst, edge)| {
                            std::iter::once((src, dst, edge))
                                .chain((src != dst).then_some((dst, src, edge)))
                        }))
                    } else {
                        base
                    };

                // Filter edges by *both* endpoints when the child has
                // already bound them. `transposed` flips which
                // graph-side (src/dst) role the pattern's from/to
                // endpoints play in the tensor, so the binding check
                // swaps correspondingly.
                //
                // Self-loop patterns like `MATCH (n)-[r:T]->(n)` have
                // `rp.from.alias == rp.to.alias`. Without filtering
                // for `from_id == to_id`, non-loop edges leak through
                // and the emitter (which binds the single shared
                // alias once, via `from`) would surface them.
                let bound_from = match view.value_at(rp.from.alias.id) {
                    Some(Value::Node(id)) => Some(id),
                    _ => None,
                };
                let bound_to = match view.value_at(rp.to.alias.id) {
                    Some(Value::Node(id)) => Some(id),
                    _ => None,
                };
                let transposed = self.transposed;
                let same_endpoint_alias = rp.from.alias == rp.to.alias;
                let edges: Box<dyn Iterator<Item = (NodeId, NodeId, RelationshipId)>> =
                    if bound_from.is_some() || bound_to.is_some() || same_endpoint_alias {
                        Box::new(oriented_hits.filter(move |(src, dst, _)| {
                            let (from_id, to_id) = if transposed {
                                (*dst, *src)
                            } else {
                                (*src, *dst)
                            };
                            bound_from.is_none_or(|id| id == from_id)
                                && bound_to.is_none_or(|id| id == to_id)
                                && (!same_endpoint_alias || from_id == to_id)
                        }))
                    } else {
                        oriented_hits
                    };
                Ok(Some(RowIter::many(edges)))
            }) {
                Ok(Some(out)) => return Some(Ok(out)),
                Ok(None) => match self.child.next() {
                    Some(Ok(batch)) => self.emitter.seed(batch),
                    Some(Err(e)) => return Some(Err(e)),
                    None => return None,
                },
                Err(e) => return Some(Err(e)),
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn key() -> Arc<String> {
        Arc::new("v".to_string())
    }

    fn in_list(values: &[Value]) -> IndexQuery<Value> {
        IndexQuery::InList {
            key: key(),
            list: Value::List(Arc::new(values.iter().cloned().collect())),
        }
    }

    /// The same members as an `Or` of `Equal`s — the shape an `IN` list used to reach the index in.
    fn or_of_equals(values: &[Value]) -> IndexQuery<Value> {
        IndexQuery::Or(
            values
                .iter()
                .map(|v| IndexQuery::Equal {
                    key: key(),
                    value: v.clone(),
                })
                .collect(),
        )
    }

    /// An `IN` list reaches the index only when it is non-empty and every member is one the index
    /// holds exactly; otherwise the op scans. That is the rule its members got as an `Or` of
    /// `Equal`s, so which queries fall back is unchanged by handing the list over whole.
    #[test]
    fn in_list_reaches_the_index_on_the_same_terms_as_an_or_of_its_members() {
        let lossy = Value::Int(9_007_199_254_740_993);
        let cases: [(&[Value], bool); 5] = [
            (&[Value::Int(1), Value::Float(2.5), Value::Bool(true)], true),
            (
                &[Value::Int(1), Value::String(Arc::new("a".to_string()))],
                true,
            ),
            (&[], false),
            (&[Value::Int(1), lossy.clone()], false),
            (&[lossy], false),
        ];
        for (values, expected) in cases {
            assert_eq!(
                EdgeByIndexScanOp::can_utilize_index(&in_list(values)),
                expected,
                "IN {values:?}"
            );
            assert_eq!(
                EdgeByIndexScanOp::can_utilize_index(&in_list(values)),
                EdgeByIndexScanOp::can_utilize_index(&or_of_equals(values)),
                "IN {values:?} must decide as its members did as an Or"
            );
        }
        assert!(
            !EdgeByIndexScanOp::can_utilize_index(&IndexQuery::InList {
                key: key(),
                list: Value::Int(1),
            }),
            "an InList that does not hold a list never reaches the index"
        );
    }
}
