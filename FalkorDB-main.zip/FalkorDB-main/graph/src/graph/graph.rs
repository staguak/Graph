//! Core graph data structure and operations.
//!
//! This module contains the main [`Graph`] struct which represents a property graph
//! using sparse matrices for efficient storage and graph operations.
//!
//! ## Graph Model
//!
//! The graph supports:
//! - **Nodes**: Identified by 64-bit IDs, can have multiple labels and properties
//! - **Relationships**: Directed edges with a type, source/destination, and properties
//! - **Properties**: Key-value pairs stored in columnar [`AttributeStore`]s
//! - **Indexes**: Range and full-text indexes on node properties
//!
//! ## Storage Layout
//!
//! ```text
//! ┌──────────────────────────────────────────────────────────────────────┐
//! │                         Graph Structure                             │
//! ├──────────────────────────┬───────────────────────────────────────────┤
//! │ adjacancy_matrix         │ Boolean matrix: src x dst -> bool        │
//! │                          │ (union of all relationship types)        │
//! ├──────────────────────────┼───────────────────────────────────────────┤
//! │ labels_matices[i]        │ Diagonal matrix per label:               │
//! │                          │ node_id x node_id -> bool                │
//! ├──────────────────────────┼───────────────────────────────────────────┤
//! │ node_labels_matrix       │ Matrix: node_id x label_id -> bool       │
//! │                          │ (maps each node to all its labels)       │
//! ├──────────────────────────┼───────────────────────────────────────────┤
//! │ relationship_matrices[i] │ Tensor per type: src x dst x edge_id     │
//! │                          │ (supports multiple edges between same    │
//! │                          │  src/dst pair via 3rd dimension)         │
//! ├──────────────────────────┼───────────────────────────────────────────┤
//! │ relationship_type_matrix │ Matrix: edge_id x type_id -> bool        │
//! │                          │ (maps each edge to its type)             │
//! ├──────────────────────────┼───────────────────────────────────────────┤
//! │ node_attrs               │ AttributeStore: node properties          │
//! │ relationship_attrs       │ AttributeStore: edge properties          │
//! ├──────────────────────────┼───────────────────────────────────────────┤
//! │ node_indexer             │ Secondary indexes on node properties     │
//! │ cache                    │ LRU cache for parsed query plans         │
//! └──────────────────────────┴───────────────────────────────────────────┘
//! ```
//!
//! ## ID Allocation and Recycling
//!
//! Deleted node/edge IDs are tracked in `RoaringTreemap` bitmaps and reused
//! before allocating fresh IDs. The `reserve_node` / `reserve_relationship`
//! methods first reclaim from deleted IDs, then extend the ID space. This
//! keeps matrices compact and avoids unbounded ID growth.
//!
//! ## Versioning
//!
//! `Graph::new_version()` creates a shallow copy suitable for a write
//! transaction. Matrices use Copy-on-Write (see [`super::cow::Cow`]) so
//! they are only duplicated when the writer actually mutates them. The
//! `version` counter is incremented on each write transaction.
//!
//! ## Query Plan Caching
//!
//! The graph caches parsed and planned queries in an LRU cache. On cache hit,
//! the plan is returned directly without reparsing. The cache key is the
//! raw query string. Plans are invalidated when the UDF version changes.

use std::{
    collections::HashMap,
    hash::Hash,
    num::NonZeroUsize,
    sync::{
        Arc,
        atomic::{AtomicU64, Ordering},
    },
    time::{Duration, Instant},
};

use rustc_hash::{FxBuildHasher, FxHashMap, FxHashSet};

use atomic_refcell::AtomicRefCell;
use lru::LruCache;
use orx_tree::DynTree;
use parking_lot::{Mutex, MutexGuard};
use roaring::RoaringTreemap;
use thiserror::Error;

#[cfg(feature = "index-falkordb")]
use crate::index::falkordb::{
    falkordb_index::FalkorDbIndex,
    graph_writes::{self, index_only_writes},
};
use crate::index::index_docs::IndexDocs;
use crate::{
    entity_type::EntityType,
    graph::{
        attribute_store::{AttrNameMap, AttributeStore},
        constraint::{Constraint, ConstraintStatus, ConstraintType},
        endpoint_index::EndpointIndex,
        graphblas::{
            matrix::{Descriptor, Dup, Matrix},
            serialization::{Encode, EncodeState, PayloadEntry, Writer},
            tensor::{GrB_INDEX_MAX, Tensor},
            vector::Vector,
            versioned_matrix::{self, VersionedMatrix},
        },
        id_space::{IdSpace, IdSpaceError},
    },
    index::{
        Field,
        indexer::{Document, IndexInfo, IndexOptions, IndexQuery, IndexType, Indexer},
    },
    parser::cypher::Parser,
    planner::{IR, Planner, binder::Binder, optimizer::optimize},
    runtime::{orderset::OrderSet, value::Value, vec_distance},
    threadpool::spawn,
};

/// Result of query parsing and planning.
///
/// Contains the execution plan along with metadata about parsing performance.
pub struct Plan {
    /// The execution plan tree
    pub plan: Arc<DynTree<IR>>,
    /// Whether this plan was retrieved from cache
    pub cached: bool,
    /// Query parameters extracted from CYPHER prefix, already evaluated
    pub parameters: HashMap<String, Value>,
    /// Time spent parsing the query
    pub parse_duration: Duration,
    /// Time spent planning/optimizing the query
    pub plan_duration: Duration,
    /// Byte offset in the original query where the actual query (without
    /// CYPHER params prefix) begins. Used by the slowlog to separate the
    /// parameter portion from the query text.
    pub params_offset: usize,
}

/// Opaque identifier for a node label.
#[derive(Default, Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct LabelId(pub usize);

/// Opaque identifier for a relationship type.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct TypeId(pub usize);

/// Opaque identifier for a node.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
#[repr(transparent)]
pub struct NodeId(u64);

/// Opaque identifier for a relationship (edge).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
#[repr(transparent)]
pub struct RelationshipId(u64);

/// Which halves of a node's adjacency to enumerate.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EdgeDirection {
    Outgoing,
    Incoming,
    Both,
}

impl std::str::FromStr for EdgeDirection {
    type Err = ();

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "outgoing" => Ok(Self::Outgoing),
            "incoming" => Ok(Self::Incoming),
            "both" => Ok(Self::Both),
            _ => Err(()),
        }
    }
}

impl From<LabelId> for usize {
    fn from(val: LabelId) -> Self {
        val.0
    }
}

impl From<TypeId> for usize {
    fn from(val: TypeId) -> Self {
        val.0
    }
}

impl From<u64> for NodeId {
    fn from(value: u64) -> Self {
        Self(value)
    }
}

impl From<NodeId> for u64 {
    fn from(value: NodeId) -> Self {
        value.0
    }
}

impl From<u64> for RelationshipId {
    fn from(value: u64) -> Self {
        Self(value)
    }
}

impl From<RelationshipId> for u64 {
    fn from(value: RelationshipId) -> Self {
        value.0
    }
}

impl Plan {
    #[must_use]
    pub const fn new(
        plan: Arc<DynTree<IR>>,
        cached: bool,
        parameters: HashMap<String, Value>,
        parse_duration: Duration,
        plan_duration: Duration,
        params_offset: usize,
    ) -> Self {
        Self {
            plan,
            cached,
            parameters,
            parse_duration,
            plan_duration,
            params_offset,
        }
    }
}

/// Detailed memory usage breakdown returned by [`Graph::memory_usage_report`].
///
/// All sizes are in bytes; the command handler converts to megabytes.
pub struct MemoryUsageReport {
    pub label_matrices_sz: usize,
    pub relation_matrices_sz: usize,
    pub node_block_storage_sz: usize,
    pub node_attr_by_label: Vec<(Arc<String>, usize)>,
    pub unlabeled_node_attr_sz: usize,
    pub edge_block_storage_sz: usize,
    pub edge_attr_by_type: Vec<(Arc<String>, usize)>,
    pub indices_sz: usize,
}

/// One label a deleted node carried, as [`Graph::delete_nodes`] reports them.
///
/// Named for the same reason as [`DeletedEdge`] and `AttrRef`: two `u64`s side
/// by side, where transposing them attributes every label to the wrong node and
/// nothing about the types would notice.
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct DeletedNodeLabel {
    pub node: u64,
    pub label: u64,
}

/// A relationship removed by [`Graph::delete_relationships`] or
/// [`Graph::delete_implicit_edges`]: its id, **its type**, and its endpoints.
///
/// The type is captured here because it cannot be recovered afterwards — the
/// edge is gone by the time effects are built — and v3's `DELETE_EDGE` groups by
/// it. `index_remove_edge_docs` is not a substitute: it is only populated for
/// types that actually carry an index.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct DeletedEdge {
    /// The edge's own id.
    pub id: RelationshipId,
    /// Its relationship type.
    pub type_id: u64,
    /// Its endpoints, in wire order. Named rather than positional because both
    /// are `NodeId`: a transposition here reverses every deleted edge and
    /// nothing about the types would catch it.
    pub src: NodeId,
    pub dst: NodeId,
}

/// Why a bulk node operation refused.
///
/// Typed rather than a `String` because the effects apply path renders these
/// into a divergence report an operator reads, and "which id, and which of the
/// two ways it was wrong" is the whole content of that report.
#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum NodeOpError {
    /// Anything the graph itself reported while doing the work.
    #[error("{0}")]
    Graph(String),

    /// The ids do not fit the graph's id space. Every judgement about whether a
    /// node is live is made there rather than here — see
    /// [`crate::graph::id_space`] — because half of it needs a batch and half of
    /// it needs only the recycle bin, and splitting them across two types is how
    /// the two halves drift apart.
    ///
    /// `kind` lives here rather than in [`IdSpaceError`] because the id space
    /// deliberately does not know which entity it counts — it is the same type
    /// twice — while every method on this graph does.
    ///
    /// Worded for the person who sees it. Every variant of [`IdSpaceError`] is
    /// an engine fault — none of them is something a query can ask for — so the
    /// message leads with that and with the one fact that person needs, which is
    /// that nothing was written. The arithmetic follows for whoever reads the
    /// report.
    #[error(
        "internal error in the {kind} id space: {source}. No part of this write was applied. \
         This is a bug in FalkorDB rather than a problem with the query — please report it"
    )]
    IdSpace {
        kind: &'static str,
        source: IdSpaceError,
    },

    /// A relationship the open batch created, and did not delete again, ends at
    /// a node that is not live — freed, or never allocated.
    ///
    /// Checked once at the end of the batch by [`Graph::validate`], not per
    /// record: a batch may legitimately name an endpoint it freed earlier, as
    /// long as the relationship is gone again by the end (the effects buffer's
    /// cancelled create/delete pair does exactly this). One left standing hangs
    /// off a recycled id, and the next node to reclaim that id inherits it.
    #[error(
        "internal error: relationship {id} was left attached to a node that is not live. \
         No part of this write was applied. This is a bug in FalkorDB rather than a problem \
         with the query — please report it"
    )]
    DanglingRelationship { id: u64 },
}

impl NodeOpError {
    /// The id-space refusal, as one about nodes.
    #[must_use]
    pub const fn node(source: IdSpaceError) -> Self {
        Self::IdSpace {
            kind: "node",
            source,
        }
    }

    /// The same, about relationships.
    #[must_use]
    pub const fn relationship(source: IdSpaceError) -> Self {
        Self::IdSpace {
            kind: "relationship",
            source,
        }
    }
}

impl From<String> for NodeOpError {
    fn from(e: String) -> Self {
        Self::Graph(e)
    }
}

/// The main graph data structure.
///
/// Stores nodes, relationships, labels, and properties using sparse matrices
/// for efficient graph operations. Supports:
/// - Node and relationship creation/deletion
/// - Label and property assignment
/// - Index-based lookups
/// - Query plan caching
///
/// # Thread Safety
///
/// The Graph is `Send + Sync` but not internally synchronized. Use [`MvccGraph`]
/// for concurrent access with proper read/write isolation.
pub struct Graph {
    /// Graph name (Redis key name)
    name: String,
    /// Maximum node capacity (for matrix sizing)
    node_cap: u64,
    /// Maximum relationship capacity (for matrix sizing)
    relationship_cap: u64,
    /// The node id space: which ids are live, which are free, and what the
    /// batch in flight has created. Every id this graph hands out or takes
    /// back goes through it, and nothing else may move the two numbers the
    /// boundary is made of.
    node_ids: IdSpace,
    /// The relationship id space. Same type, same rules — two counted ranges
    /// with a free set is all either of them is.
    relationship_ids: IdSpace,
    /// Empty matrix for operations
    zero_matrix: VersionedMatrix<bool>,
    /// Combined adjacency matrix (all relationship types)
    adjacancy_matrix: VersionedMatrix<bool>,
    /// Matrix mapping nodes to their labels
    node_labels_matrix: VersionedMatrix<bool>,
    /// Matrix mapping relationships to their types
    relationship_type_matrix: VersionedMatrix<bool>,
    /// Per-label matrices (label ID → node membership)
    labels_matices: Vec<VersionedMatrix<bool>>,
    /// Per-type relationship tensors (type ID → src×dst×edge_id)
    relationship_matrices: Vec<Tensor>,
    /// Graph-wide reverse index: `edge_id` → `(src, dst)` for O(1) endpoint
    /// lookup, as contiguous slots indexed by edge id. Edge IDs are densely
    /// allocated, so slots are far more compact than a hash map (~31 B/edge
    /// with control bytes and load-factor slack). Wrapped in `Arc` so MVCC
    /// `new_version` is O(1); the first edge mutation per version pays one
    /// `Arc::make_mut` deep clone of the tier it writes to — not of the whole
    /// index — and node-only writes pay nothing.
    ///
    /// [`EndpointIndex`] sizes its fields to the endpoints it holds, so this is
    /// 6 bytes per edge on a graph of millions of nodes rather than a flat 8 —
    /// and it has no ceiling, where the previous `(src << 32) | dst` packing
    /// refused any node id past 2^32.
    edge_endpoints: Arc<EndpointIndex>,
    /// The graph's one attribute-name dictionary: name → id and id → name, shared by
    /// both stores below so an id means the same attribute everywhere it appears — in a
    /// span, the RDB, a `GRAPH.EFFECT`, or a compact reply.
    ///
    /// Deliberately *not* per store. Two dictionaries numbered the same name
    /// differently for nodes and relationships, and because effects put a bare id on
    /// the wire, an RDB-seeded replica resolved it against different numbering and wrote
    /// to the wrong attribute (#2457). C has the same shape: one `attributes` array on
    /// `GraphContext`, two `DataBlock`s.
    attrs_name: AttrNameMap,
    /// Node property storage
    node_attrs: AttributeStore,
    /// Relationship property storage
    relationship_attrs: AttributeStore,
    /// Index manager for node property indexes
    node_indexer: Indexer,
    /// Index manager for edge property indexes
    edge_indexer: Indexer,
    /// Label names (ID → name mapping)
    node_labels: Vec<Arc<String>>,
    /// Label name → ID, the reverse of `node_labels`.
    ///
    /// A label test is a per-row operation (`n:Person` for every row of a scan),
    /// so resolving the name must not walk the whole schema: with 500 labels
    /// registered, `MATCH (n) WHERE n:Person RETURN count(n)` over 10k nodes
    /// measured 2.1x the same query on a one-label schema, all of it in the
    /// walk. Maintained only by `intern_label`, so it cannot drift.
    node_labels_index: FxHashMap<String, LabelId>,
    /// Relationship type names (ID → name mapping)
    relationship_types: Vec<Arc<String>>,
    /// LRU cache for query plans
    cache: Arc<Mutex<LruCache<String, Arc<PlanTree>>>>,
    /// Graph constraints (unique, mandatory)
    constraints: Vec<Constraint>,
    /// Version counter (incremented on each write transaction)
    pub version: u64,
    /// Schema version (incremented only on schema changes: new labels, relationship types, or attributes)
    pub schema_version: u64,
    /// FalkorDB numeric indexes, folded into the graph version: `new_version`
    /// forks them copy-on-write and the committed-version swap publishes graph +
    /// index atomically.
    ///
    /// `pub(crate)` for `index::falkordb`: `graph_writes` reads it to stage changes, and
    /// `FalkorDbIndex::apply` updates it.
    #[cfg(feature = "index-falkordb")]
    pub(crate) falkordb_index: FalkorDbIndex,
}

/// Wrapper for plan trees to implement Send+Sync.
/// Also stores the UDF version at cache time for invalidation.
struct PlanTree {
    plan: DynTree<IR>,
    udf_version: u64,
}

#[allow(clippy::non_send_fields_in_send_ty)]
unsafe impl Send for PlanTree {}
unsafe impl Sync for PlanTree {}

unsafe impl Send for Graph {}
unsafe impl Sync for Graph {}

/// Populates an index in the background for existing nodes.
///
/// Each batch borrows the latest committed graph (via the Indexer's shared
/// graph reference) to get a fresh label matrix and attribute store,
/// ensuring nodes added by write transactions between batches are visible.
///
/// The Indexer's serialization lock serializes each batch with write-path
/// `commit_index` calls, so they never run concurrently.  Within a
/// batch the lock is held, preventing writes from committing index
/// changes.  Between batches the lock is released, allowing writes
/// to proceed.
/// Which kind of entity a background population job is building an
/// index for. Controls how ids are enumerated and how attributes are
/// resolved; every other step of the batch loop is shared.
#[derive(Copy, Clone)]
enum IndexKind {
    Node,
    Edge,
}

/// Cursor position between batches.
///
/// - For nodes: `row` is the next node id to visit; the other fields
///   are always `None` (per-row cursor suffices).
/// - For edges: `row` is the next `src` row in the relationship tensor.
///   When `within_row_dst` is `Some(d)`, all edges at `(row, dst)`
///   with `dst < d` have been indexed and must be skipped on resume.
///   When additionally `within_pair_edge_id` is `Some(e)`, the pair
///   at `(row, d)` has multiple edges and the ones with
///   `edge_id <= e` have already been indexed — the remainder of the
///   same-pair group must still be processed. Matches the C
///   implementation's `(prev_src, prev_dst, prev_eid)` skip pattern
///   in `src/index/index_construct.c:_Index_PopulateEdgeIndex`.
#[derive(Clone, Copy, Default)]
struct BatchCursor {
    row: u64,
    within_row_dst: Option<u64>,
    within_pair_edge_id: Option<u64>,
}

fn populate_index(
    kind: IndexKind,
    label: Arc<String>,
    indexer: Indexer,
) {
    // Capture the field snapshot and ticket in one read-side critical
    // section so the documents we build match the generation we own.
    let Some(snapshot) = indexer.acquire_population_snapshot(&label) else {
        return;
    };
    populate_index_batch(
        kind,
        label,
        indexer,
        snapshot.fields,
        0,
        BatchCursor::default(),
        snapshot.ticket,
    );
}

/// Processes one batch of index population and spawns the next batch.
///
/// Node and edge indexes share this loop; the only kind-specific bits
/// are which matrix we walk (label matrix vs relationship tensor) and
/// which attribute store we read.
fn populate_index_batch(
    kind: IndexKind,
    label: Arc<String>,
    indexer: Indexer,
    attrs: HashMap<Arc<String>, Vec<Arc<Field>>>,
    mut progress: u64,
    cursor: BatchCursor,
    ticket: crate::index::indexer::PopulationTicket,
) {
    spawn(
        move || {
            const BATCH_SIZE: usize = 10_000;

            let exhausted;
            let mut next_cursor = cursor;
            let mut do_recurse = false;

            // Hold the Indexer's serialization lock for the entire batch
            // AND through the final ticket-release / recurse decision. Without
            // this, `drop_index_bg` can remove the index entry between
            // batch completion and ticket release. If a subsequent CREATE
            // recreates an entry under the same label, release still targets
            // the original generation via `ticket.generation_id`.
            {
                // Deliberately no global lock: a batch only touches ticket
                // bookkeeping and document add/delete, never the RediSearch spec
                // lifecycle, and taking it per batch would serialize background
                // population against the main thread.
                let lock = indexer.write_lock();
                let guard = lock.lock();

                if !indexer.is_ticket_current(&ticket) {
                    // Index entry was recreated under us — our captured
                    // `attrs` is stale and would commit partial-spec docs
                    // into the new rs_idx. The fresh populate spawned by
                    // recreate will repopulate from cursor 0 with the full
                    // current schema. Release only this generation's
                    // ticket so stale workers never decrement the fresh
                    // generation's pending counter.
                    indexer.release_population_ticket(&ticket);
                    return;
                }

                if indexer.is_cancelled() || indexer.ticket_pending_changes(&ticket) > 1 {
                    indexer.release_population_ticket(&ticket);
                    return;
                }

                let Some(graph) = indexer.get_graph() else {
                    // Graph not yet committed — reschedule this batch.
                    // MvccGraph::commit() will set the indexer's graph
                    // reference, so the next attempt will find it.
                    drop(guard);
                    drop(lock);
                    std::thread::sleep(Duration::from_millis(1));
                    populate_index_batch(kind, label, indexer, attrs, progress, cursor, ticket);
                    return;
                };

                // Collect this batch's entities.
                //
                // For nodes: walk the label matrix from `cursor.row`
                // (keyed by node id).
                // For edges: walk the relationship tensor from
                // `cursor.row` (keyed by `src` row). When
                // `cursor.within_row_dst` is `Some`, skip entries
                // `(src, dst)` where `src == cursor.row` and
                // `dst <= within_row_dst` — those were already
                // processed in a prior batch that ran out of
                // BATCH_SIZE mid-row. Matches C's `(prev_src, prev_dst)`
                // skip in `_Index_PopulateEdgeIndex`.
                let ids: Vec<u64>;
                let edge_triples: Vec<(u64, u64, u64)>;
                let scanned_count: usize;
                {
                    let g = graph.borrow();
                    match kind {
                        IndexKind::Node => {
                            ids = g
                                .get_label_matrix(&label)
                                .map(|lm| {
                                    lm.iter(cursor.row, u64::MAX)
                                        .take(BATCH_SIZE)
                                        .map(|(n, _)| n)
                                        .collect()
                                })
                                .unwrap_or_default();
                            edge_triples = Vec::new();
                            scanned_count = ids.len();
                        }
                        IndexKind::Edge => {
                            let skip_src = cursor.row;
                            let skip_dst = cursor.within_row_dst;
                            let skip_eid = cursor.within_pair_edge_id;
                            let triples: Vec<(u64, u64, u64)> = g
                                .get_relationship_matrix(&label)
                                .map(|t| {
                                    t.iter(cursor.row, u64::MAX, false)
                                        .filter(|(src, dst, eid)| {
                                            // Row mismatch: past the resume
                                            // src entirely, always included.
                                            if *src != skip_src {
                                                return true;
                                            }
                                            // Within the resume row: skip
                                            // completed columns; within the
                                            // resume column (multi-edge),
                                            // skip the already-indexed edge
                                            // ids.
                                            match (skip_dst, skip_eid) {
                                                (Some(d), Some(e)) if *dst == d => *eid > e,
                                                (Some(d), _) => *dst > d,
                                                _ => true,
                                            }
                                        })
                                        .take(BATCH_SIZE)
                                        .collect()
                                })
                                .unwrap_or_default();
                            ids = Vec::new();
                            scanned_count = triples.len();
                            edge_triples = triples;
                        }
                    }
                }

                let mut batch: Vec<Document> = Vec::with_capacity(scanned_count);

                // Build a document for `id`, allocating the RSDoc only once we
                // know the entity has at least one indexed field. Populating an
                // index created before its fields are seeded would otherwise
                // create-then-free a document for every field-less entity (e.g.
                // scanning a 1.7M-edge tensor), pure allocator churn. Returns
                // `None` when no indexed field is present. `make_doc` builds the
                // right key kind (node id vs edge triple) lazily.
                let build_doc =
                    |id: u64, is_edge: bool, g: &Graph, make_doc: &dyn Fn() -> Document| {
                        let mut doc: Option<Document> = None;
                        for (attr, fields) in &attrs {
                            let value = if is_edge {
                                g.get_relationship_attribute(RelationshipId(id), attr)
                            } else {
                                g.get_node_attribute(NodeId(id), attr)
                            };
                            if let Some(value) = value {
                                let doc = doc.get_or_insert_with(make_doc);
                                for field in fields {
                                    doc.set(field, &value);
                                }
                            }
                        }
                        doc
                    };

                // Advance `next_cursor` based on the *last scanned id*,
                // not the last emitted doc, so we don't get stuck when
                // most entities have no indexed attributes (few docs
                // produced) but there are still more to scan.
                match kind {
                    IndexKind::Node => {
                        let last_id = ids.last().copied();
                        for id in ids {
                            let g = graph.borrow();
                            if let Some(doc) = build_doc(id, false, &g, &|| Document::new(id)) {
                                batch.push(doc);
                            }
                        }
                        if let Some(id) = last_id {
                            next_cursor = BatchCursor {
                                row: id + 1,
                                within_row_dst: None,
                                within_pair_edge_id: None,
                            };
                        }
                    }
                    IndexKind::Edge => {
                        let last_pos = edge_triples.last().map(|(s, d, e)| (*s, *d, *e));
                        for (src, dst, eid) in edge_triples {
                            let g = graph.borrow();
                            if let Some(doc) =
                                build_doc(eid, true, &g, &|| Document::new_edge(src, dst, eid))
                            {
                                batch.push(doc);
                            }
                        }
                        if let Some((last_src, last_dst, last_eid)) = last_pos {
                            next_cursor = BatchCursor {
                                row: last_src,
                                within_row_dst: Some(last_dst),
                                within_pair_edge_id: Some(last_eid),
                            };
                        }
                    }
                }

                exhausted = scanned_count < BATCH_SIZE;

                if !batch.is_empty() {
                    progress += batch.len() as u64;
                    let mut add_docs = HashMap::new();
                    add_docs.insert(label.clone(), batch);
                    indexer.commit(&mut add_docs, &mut HashMap::new());
                    indexer.update_progress(&label, progress);
                }

                if exhausted {
                    indexer.release_population_ticket(&ticket);
                } else {
                    do_recurse = true;
                }
                // guard dropped here
            }

            if do_recurse {
                populate_index_batch(kind, label, indexer, attrs, progress, next_cursor, ticket);
            }
        },
        Some(0),
    );
}

fn drop_index_bg(
    label: Arc<String>,
    node_indexer: Indexer,
) {
    spawn(
        move || {
            // Indexer lock only, never the global lock: `Indexer::remove` swaps the
            // index map, and the `Index` it drops takes no lock either. Reaching for
            // the global lock *under* the indexer lock is the AB-BA that hung
            // `test_index_create` for six hours (issue #726).
            //
            // The lock serializes against `populate_index_batch`, which holds it for
            // a whole batch, so the populate worker can't be mid-batch here.
            let lock = node_indexer.write_lock();
            let _guard = lock.lock();
            node_indexer.remove(&label);
        },
        Some(0),
    );
}

/// Default for the NODE_CREATION_BUFFER configuration; the config
/// registration and `CONFIGURATION_NODE_CREATION_BUFFER` in the root crate
/// reference this constant so the default lives in one place.
pub const DEFAULT_NODE_CREATION_BUFFER: u64 = 16384;

/// Effective NODE_CREATION_BUFFER configuration value: the chunk size (in
/// entities) that matrix capacities grow by.
///
/// Set once at module init from the normalized config (power of two, >= 128);
/// immutable afterwards.
pub static NODE_CREATION_BUFFER: AtomicU64 = AtomicU64::new(DEFAULT_NODE_CREATION_BUFFER);

/// Capacity growth step for entity matrices. Sparse matrices carry a
/// row-pointer array sized by the matrix dimension, so doubling the
/// capacity wastes up to `4 * cap` bytes per matrix at large graph sizes.
/// Growing 25% at a time (rounded up to a NODE_CREATION_BUFFER chunk)
/// bounds that slop while keeping resizes rare: each resize triggers
/// GraphBLAS format conversions costing O(entries), so smaller growth
/// steps measurably slow bulk inserts.
///
/// Never past `GrB_INDEX_MAX`, the largest dimension GraphBLAS accepts. The
/// step is checked rather than wrapped: near the top of `u64` the unchecked
/// `cap + cap / 4` wrapped, and because `cap` stays a multiple of the chunk it
/// never reached `needed` again — an infinite loop in release. Ids that large
/// are refused before they get here (`IdSpace::create`), so the clamp
/// is what keeps a caller that forgets from hanging instead of failing. #2892.
fn grow_cap(
    mut cap: u64,
    needed: u64,
) -> u64 {
    let chunk = NODE_CREATION_BUFFER.load(Ordering::Relaxed);
    while needed > cap && cap < GrB_INDEX_MAX {
        cap = cap
            .checked_add((cap / 4).max(chunk))
            .and_then(|c| c.checked_next_multiple_of(chunk))
            .map_or(GrB_INDEX_MAX, |c| c.min(GrB_INDEX_MAX));
    }
    cap
}

impl Graph {
    #[must_use]
    pub fn new(
        n: u64,
        e: u64,
        cache_size: usize,
        version: u64,
        name: &str,
    ) -> Self {
        Self {
            name: name.to_string(),
            node_cap: n,
            relationship_cap: e,
            node_ids: IdSpace::new(),
            relationship_ids: IdSpace::new(),
            zero_matrix: VersionedMatrix::<bool>::new(0, 0),
            adjacancy_matrix: VersionedMatrix::<bool>::new(n, n),
            node_labels_matrix: VersionedMatrix::<bool>::new(0, 0),
            relationship_type_matrix: VersionedMatrix::<bool>::new(0, 0),
            labels_matices: Vec::new(),
            relationship_matrices: Vec::new(),
            edge_endpoints: Arc::new(EndpointIndex::default()),
            attrs_name: AttrNameMap::default(),
            node_attrs: AttributeStore::new(),
            relationship_attrs: AttributeStore::new(),
            node_indexer: Indexer::default(),
            edge_indexer: Indexer::default(),
            node_labels: Vec::new(),
            node_labels_index: FxHashMap::default(),
            relationship_types: Vec::new(),
            cache: Arc::new(Mutex::new(LruCache::new(
                NonZeroUsize::new(cache_size.max(1)).expect("cache_size.max(1) is always >= 1"),
            ))),
            constraints: Vec::new(),
            version,
            schema_version: 0,
            #[cfg(feature = "index-falkordb")]
            falkordb_index: FalkorDbIndex::new(),
        }
    }

    /// Restore a graph from decoded RDB data.
    ///
    /// Used by the RDB load path to construct a fully-populated graph
    /// without going through the mutation API.
    #[must_use]
    #[allow(clippy::too_many_arguments)]
    pub fn restore(
        name: &str,
        cache_size: usize,
        node_count: u64,
        relationship_count: u64,
        deleted_nodes: RoaringTreemap,
        deleted_relationships: RoaringTreemap,
        adjacancy_matrix: VersionedMatrix<bool>,
        node_labels_matrix: VersionedMatrix<bool>,
        relationship_type_matrix: VersionedMatrix<bool>,
        labels_matices: Vec<VersionedMatrix<bool>>,
        relationship_matrices: Vec<Tensor>,
        node_labels: Vec<Arc<String>>,
        relationship_types: Vec<Arc<String>>,
        attrs_name: AttrNameMap,
        node_attrs: AttributeStore,
        relationship_attrs: AttributeStore,
    ) -> Self {
        // Rebuild the graph-wide reverse index after RDB load to ensure
        // complete sync with the decoded edges.
        // Two scans rather than one scan into a `Vec` of triples: materialising
        // them would add ~24 bytes per edge of peak memory on top of the graph
        // being restored, which is enough to fail a load that would otherwise
        // fit. The first scan takes only maxima, which sizes the index once, so
        // the second neither widens nor reallocates.
        //
        // The first pass also recovers where the index's width tiers begin.
        // Sizing everything to the graph's widest endpoint would be simpler and
        // would flatten the tiering on every load; under incremental growth an
        // edge lands in the widest tier any earlier edge needed, so tier `r`
        // begins at the smallest edge id whose own endpoints need at least `r`.
        // Three scalars, no per-edge state.
        let mut max_edge_id = 0u64;
        let mut starts = [u64::MAX; 3];
        for tensor in &relationship_matrices {
            for (src, dst, edge_id) in tensor.iter_edges() {
                max_edge_id = max_edge_id.max(edge_id);
                let rank = EndpointIndex::rank_for(src.max(dst));
                for r in 1..=rank {
                    let slot = &mut starts[usize::from(r) - 1];
                    *slot = (*slot).min(edge_id);
                }
            }
        }
        let len = if relationship_matrices.iter().any(|t| t.edge_count() > 0) {
            max_edge_id + 1
        } else {
            0
        };
        // A tier nothing reached starts at the end, i.e. stays empty. Clamped
        // monotone so a later tier never begins before an earlier one.
        let mut acc = len;
        for slot in starts.iter_mut().rev() {
            acc = acc.min(*slot);
            *slot = acc;
        }
        let to_slot = |v: u64| usize::try_from(v).expect("edge id exceeds usize");
        let mut edge_endpoints = EndpointIndex::default();
        edge_endpoints.prepare_tiers(starts.map(to_slot), to_slot(len));
        for tensor in &relationship_matrices {
            for (src, dst, edge_id) in tensor.iter_edges() {
                edge_endpoints.set(edge_id, src, dst);
            }
        }

        let chunk = NODE_CREATION_BUFFER.load(Ordering::Relaxed);
        let node_ids = IdSpace::restored(node_count, deleted_nodes);
        let relationship_ids = IdSpace::restored(relationship_count, deleted_relationships);
        let node_cap = node_ids.bound();
        let relationship_cap = relationship_ids.bound();
        let schema_version = (node_labels.len() + relationship_types.len()) as u64;
        Self {
            name: name.to_string(),
            node_cap: node_cap.next_multiple_of(chunk).max(64),
            relationship_cap: relationship_cap.next_multiple_of(chunk).max(64),
            node_ids,
            relationship_ids,
            zero_matrix: VersionedMatrix::<bool>::new(0, 0),
            adjacancy_matrix,
            node_labels_matrix,
            relationship_type_matrix,
            labels_matices,
            relationship_matrices,
            edge_endpoints: Arc::new(edge_endpoints),
            attrs_name,
            node_attrs,
            relationship_attrs,
            node_indexer: Indexer::default(),
            edge_indexer: Indexer::default(),
            node_labels_index: node_labels
                .iter()
                .enumerate()
                .map(|(i, l)| (l.as_str().to_string(), LabelId(i)))
                .collect(),
            node_labels,
            relationship_types,
            cache: Arc::new(Mutex::new(LruCache::new(
                NonZeroUsize::new(cache_size.max(1)).expect("cache_size.max(1) is always >= 1"),
            ))),
            constraints: Vec::new(),
            version: 0,
            schema_version,
            // Empty on restore: the RDB does not carry the index, so the
            // populate path rebuilds it.
            #[cfg(feature = "index-falkordb")]
            falkordb_index: FalkorDbIndex::new(),
        }
    }

    /// Rebuild derived matrices after RDB load.
    ///
    /// - `relationship_type_matrix`: `(edge_id, type_index) = true` for all edges
    /// - Tensor backward (`mt`): transpose of forward (`m`)
    pub fn rebuild_derived_matrices(&mut self) {
        // Decoded matrices keep the saving server's node_cap, which `grow_cap`
        // leaves up to 25% past the highest node id, while `restore` sets
        // node_cap from that id. Take the larger, so the resize below only
        // grows: a load never shrinks a matrix, and `Tensor::resize` never has
        // to drop entries (#3246).
        let saved = std::iter::once(self.adjacancy_matrix.nrows())
            .chain(std::iter::once(self.adjacancy_matrix.ncols()))
            .chain(std::iter::once(self.node_labels_matrix.nrows()))
            .chain(self.labels_matices.iter().map(VersionedMatrix::nrows))
            .chain(
                self.relationship_matrices
                    .iter()
                    .flat_map(|t| [t.nrows(), t.ncols()]),
            )
            .max()
            .unwrap_or(0);
        self.node_cap = self.node_cap.max(saved);
        self.resize_node_matrices();
        let rc = self.relationship_cap;
        self.relationship_type_matrix
            .resize(rc, self.relationship_types.len() as u64);

        // Rebuild relationship_type_matrix and tensor backward matrices
        for (type_idx, tensor) in self.relationship_matrices.iter_mut().enumerate() {
            // Rebuild backward (transpose) matrix from forward matrix in one operation
            tensor.rebuild_backward();

            // Iterate edges matrix to rebuild relationship_type_matrix
            for (_, _, edge_id) in tensor.iter(0, u64::MAX, false) {
                self.relationship_type_matrix
                    .set(edge_id, type_idx as u64, true);
            }
        }
    }

    /// Reclaim attribute-arena growth slop on blocks touched by this version.
    /// Called once at MVCC commit.
    pub fn trim_attr_stores(&mut self) {
        self.node_attrs.trim();
        self.relationship_attrs.trim();
    }

    #[must_use]
    pub fn new_version(&self) -> Self {
        // One dictionary clone per version instead of the two the split tables cost.
        let attrs_name = self.attrs_name.clone();
        let node_attrs = self.node_attrs.new_version();
        let relationship_attrs = self.relationship_attrs.new_version();

        // Tensor::dup() is copy-on-write; edge_endpoints is behind an Arc, so
        // the clone below is O(1) and the deep copy is deferred to the first
        // edge mutation in the new version.
        let relationship_matrices: Vec<Tensor> =
            self.relationship_matrices.iter().map(Tensor::dup).collect();

        Self {
            name: self.name.clone(),
            node_cap: self.node_cap,
            relationship_cap: self.relationship_cap,
            // Cloned with a fresh batch: a version is where a batch begins, so
            // the previous one's `created` set never reaches a published
            // version — nor the memory it holds, which `GRAPH.MEMORY` does not
            // count and no reader would ever look at.
            node_ids: self.node_ids.new_version(),
            relationship_ids: self.relationship_ids.new_version(),
            zero_matrix: self.zero_matrix.dup(),
            adjacancy_matrix: self.adjacancy_matrix.dup(),
            node_labels_matrix: self.node_labels_matrix.dup(),
            relationship_type_matrix: self.relationship_type_matrix.dup(),
            labels_matices: self
                .labels_matices
                .iter()
                .map(VersionedMatrix::dup)
                .collect(),
            relationship_matrices,
            edge_endpoints: self.edge_endpoints.clone(),
            attrs_name,
            node_attrs,
            relationship_attrs,
            node_indexer: self.node_indexer.clone(),
            edge_indexer: self.edge_indexer.clone(),
            node_labels: self.node_labels.clone(),
            node_labels_index: self.node_labels_index.clone(),
            relationship_types: self.relationship_types.clone(),
            cache: self.cache.clone(),
            constraints: self.constraints.clone(),
            version: self.version + 1,
            schema_version: self.schema_version,
            #[cfg(feature = "index-falkordb")]
            falkordb_index: self.falkordb_index.clone(),
        }
    }

    #[must_use]
    pub fn name(&self) -> &str {
        &self.name
    }

    #[must_use]
    pub const fn node_count(&self) -> u64 {
        self.node_ids.live()
    }

    /// Returns the number of nodes with the given label.
    #[must_use]
    pub fn label_node_count(
        &self,
        label: &str,
    ) -> u64 {
        self.get_label_matrix(label).map_or(
            0,
            super::graphblas::versioned_matrix::VersionedMatrix::nvals,
        )
    }

    #[must_use]
    pub const fn relationship_count(&self) -> u64 {
        self.relationship_ids.live()
    }

    /// Number of nodes with the given label (by label index).
    #[must_use]
    pub fn label_node_count_by_idx(
        &self,
        label_idx: usize,
    ) -> u64 {
        self.labels_matices[label_idx].nvals()
    }

    /// Number of edges of the given relationship type (by type index).
    #[must_use]
    pub fn type_edge_count(
        &self,
        type_idx: usize,
    ) -> u64 {
        self.relationship_matrices[type_idx].edge_count()
    }

    /// Number of distinct property keys across nodes and relationships.
    ///
    /// Just the dictionary's length: there is one table per graph and it is keyed
    /// by name, so entries are distinct by construction. This used to union two
    /// per-store tables through a `HashSet`; after they were merged the union
    /// became the same table twice.
    #[must_use]
    pub const fn property_key_count(&self) -> usize {
        self.attrs_name.len()
    }

    #[must_use]
    pub const fn node_cap(&self) -> u64 {
        self.node_cap
    }

    #[must_use]
    pub const fn labels_count(&self) -> usize {
        self.node_labels.len()
    }

    #[must_use]
    pub fn get_labels(&self) -> &[Arc<String>] {
        &self.node_labels
    }

    #[must_use]
    pub fn get_label_by_id(
        &self,
        id: LabelId,
    ) -> Arc<String> {
        self.node_labels[id.0].clone()
    }

    #[must_use]
    pub fn get_types(&self) -> &[Arc<String>] {
        &self.relationship_types
    }

    #[must_use]
    pub fn get_type(
        &self,
        id: TypeId,
    ) -> Option<Arc<String>> {
        self.relationship_types.get(id.0).cloned()
    }

    /// The graph's attribute names in id order; position is the id.
    ///
    /// Was a deduplicated union of two per-store tables, walked once per property on the
    /// relationship reply path. With one dictionary it is a plain iteration and the
    /// per-call `HashSet` is gone.
    pub fn get_attrs(&self) -> impl Iterator<Item = &Arc<String>> + '_ {
        self.attrs_name.iter()
    }

    /// Register `label`, or return the id it already has. The only writer of
    /// `node_labels` and `node_labels_index`, so the two stay in step.
    fn intern_label(
        &mut self,
        label: &Arc<String>,
    ) -> LabelId {
        if let Some(&id) = self.node_labels_index.get(label.as_str()) {
            return id;
        }
        let id = LabelId(self.node_labels.len());
        self.node_labels.push(label.clone());
        self.node_labels_index
            .insert(label.as_str().to_string(), id);
        id
    }

    pub fn get_label_id_mut(
        &mut self,
        label: &str,
    ) -> LabelId {
        if let Some(id) = self.get_label_id(label) {
            return id;
        }

        let id = self.intern_label(&Arc::new(label.to_string()));
        self.labels_matices
            .push(VersionedMatrix::<bool>::new(self.node_cap, self.node_cap));
        // Registering a label changes a matrix dimension — `node_labels_matrix`
        // is nodes x labels — so it is reconciled here, where the dimension
        // changed, rather than by whichever write reaches the new column first.
        // Once per label ever, and `resize` is four comparisons when nothing
        // else moved.
        self.resize();
        id
    }

    pub fn get_label_id(
        &self,
        label: &str,
    ) -> Option<LabelId> {
        self.node_labels_index.get(label).copied()
    }

    pub fn get_type_id(
        &self,
        relationship_type: &str,
    ) -> Option<TypeId> {
        self.relationship_types
            .iter()
            .position(|t| t.as_str() == relationship_type)
            .map(TypeId)
    }

    /// Check if a node has a specific label.
    #[must_use]
    pub fn node_has_label(
        &self,
        node_id: NodeId,
        label: &str,
    ) -> bool {
        self.get_label_id(label).is_some_and(|label_id| {
            self.node_labels_matrix
                .get(node_id.0, label_id.0 as u64)
                .is_some()
        })
    }

    /// Check if a node has a specific label by id (no string lookup).
    #[must_use]
    pub fn node_has_label_id(
        &self,
        node_id: NodeId,
        label_id: LabelId,
    ) -> bool {
        self.node_labels_matrix
            .get(node_id.0, label_id.0 as u64)
            .is_some()
    }

    /// Check if an edge has a specific relationship type.
    #[must_use]
    pub fn edge_has_type(
        &self,
        edge_id: RelationshipId,
        type_name: &str,
    ) -> bool {
        self.get_type_id(type_name).is_some_and(|type_id| {
            self.relationship_type_matrix
                .get(edge_id.0, type_id.0 as u64)
                .is_some()
        })
    }

    /// Get-or-create a relationship type by name, returning its `TypeId`.
    pub fn get_type_id_mut(
        &mut self,
        relationship_type: &str,
    ) -> TypeId {
        if let Some(pos) = self
            .relationship_types
            .iter()
            .position(|t| t.as_str() == relationship_type)
            .map(TypeId)
        {
            return pos;
        }

        self.register_relationship_type(Arc::new(relationship_type.to_string()))
    }

    /// Append a new relationship type: its name, its tensor, and the extra
    /// column in `relationship_type_matrix` (relationships x types). Every
    /// registration goes through here so none can skip the resize: a type
    /// registered with no edge (a constraint, a replica's `ADD_SCHEMA`) used to
    /// leave the matrix a column short, and every later edge delete built a
    /// removal mask the matrix refused, keeping the deleted edge's type (#3244).
    fn register_relationship_type(
        &mut self,
        relationship_type: Arc<String>,
    ) -> TypeId {
        self.relationship_types.push(relationship_type);
        let id = self.relationship_types.len() - 1;
        self.relationship_matrices
            .insert(id, Tensor::new(self.node_cap, self.node_cap));
        self.resize();
        TypeId(id)
    }

    pub fn get_plan(
        &self,
        query: &str,
    ) -> Result<Plan, String> {
        let mut parse_duration = Duration::ZERO;
        let mut plan_duration = Duration::ZERO;

        let mut parser = Parser::new(query);
        let (parameters, query_no_params) = parser.parse_parameters()?;
        let params_offset = query.len() - query_no_params.len();
        let query = query_no_params;

        // The optimizer wants the same values the runtime will see.
        let param_values = parameters.clone();

        let current_udf_version = crate::runtime::functions::udf_version();

        {
            let mut cache = self.cache.lock();
            if let Some(plan) = cache.get(query)
                && plan.udf_version == current_udf_version
            {
                let plan = plan.clone();
                drop(cache);
                let optimize_plan = optimize(&plan.plan, self, &param_values);
                return Ok(Plan::new(
                    Arc::new(optimize_plan),
                    true,
                    parameters,
                    parse_duration,
                    plan_duration,
                    params_offset,
                ));
            }
        }

        let start = Instant::now();
        let raw_ir = parser.parse()?;
        let (ir, scope_vars) = Binder::default().bind(raw_ir)?;
        ir.validate()?;
        parse_duration = start.elapsed();

        let mut planner = Planner::new(scope_vars);
        let start = Instant::now();
        let plan = planner.plan(ir);
        let plan = planner.finish(plan);
        let optimize_plan = optimize(&plan, self, &param_values);
        plan_duration = start.elapsed();

        // Only cache the plan if UDF version hasn't changed during planning.
        // A drift means the plan may reference stale UDF bindings.
        if crate::runtime::functions::udf_version() == current_udf_version {
            self.cache.lock().push(
                query.to_string(),
                Arc::new(PlanTree {
                    plan,
                    udf_version: current_udf_version,
                }),
            );
        }
        Ok(Plan::new(
            Arc::new(optimize_plan),
            false,
            parameters,
            parse_duration,
            plan_duration,
            params_offset,
        ))
    }

    #[must_use]
    pub fn get_label_matrix(
        &self,
        label: &str,
    ) -> Option<&VersionedMatrix<bool>> {
        self.get_label_id(label)
            .map(|id| &self.labels_matices[id.0])
    }

    fn get_label_matrix_mut(
        &mut self,
        label: &Arc<String>,
    ) -> &mut VersionedMatrix<bool> {
        let id = self.intern_label(label);
        if id.0 == self.labels_matices.len() {
            let m = VersionedMatrix::<bool>::new(self.node_cap, self.node_cap);
            self.labels_matices.insert(id.0, m);
            self.resize();
        }
        &mut self.labels_matices[id.0]
    }

    fn get_relationship_matrix_mut(
        &mut self,
        relationship_type: &Arc<String>,
    ) -> &mut Tensor {
        if !self.relationship_types.contains(relationship_type) {
            self.register_relationship_type(relationship_type.clone());
        }

        self.relationship_types
            .iter()
            .position(|l| l.as_str() == relationship_type.as_str())
            .map(|i| &mut self.relationship_matrices[i])
            .expect("relationship type was just inserted")
    }

    #[must_use]
    pub fn get_relationship_matrix(
        &self,
        relationship_type: &Arc<String>,
    ) -> Option<&Tensor> {
        if !self.relationship_types.contains(relationship_type) {
            return None;
        }

        self.relationship_types
            .iter()
            .position(|l| l.as_str() == relationship_type.as_str())
            .map(|i| &self.relationship_matrices[i])
    }

    #[must_use]
    pub fn get_node_attribute_id(
        &self,
        attr: &Arc<String>,
    ) -> Option<usize> {
        self.attrs_name.get_index_of(attr)
    }

    #[must_use]
    pub const fn node_attribute_count(&self) -> usize {
        self.attrs_name.len()
    }

    #[must_use]
    pub fn get_relationship_attribute_id(
        &self,
        attr: &Arc<String>,
    ) -> Option<usize> {
        self.attrs_name.get_index_of(attr)
    }

    /// The id for `attr`, or `None` if this graph has never seen the name.
    ///
    /// Was an O(N) scan over a union of two per-store tables, per property serialized.
    /// There is one dictionary now, so it is the dictionary's own lookup — and node,
    /// relationship and "global" ids are the same thing.
    #[must_use]
    pub fn get_global_attribute_id(
        &self,
        attr: &Arc<String>,
    ) -> Option<usize> {
        self.attrs_name.get_index_of(attr)
    }

    /// Hand a reserved node id back, unused.
    ///
    /// Nothing else has to be undone, because a reservation is not state this
    /// graph keeps — see [`IdSpace::reserve`], which is also where the rule
    /// that keeps the id from being re-issued inside the same commit lives.
    ///
    /// # Errors
    ///
    /// [`IdSpaceError`], wrapped, if returning the id left the id space
    /// contradicting itself.
    pub(crate) fn cancel_node_id(
        &mut self,
        id: NodeId,
    ) -> Result<(), NodeOpError> {
        self.node_ids.cancel(id.into()).map_err(NodeOpError::node)?;
        Ok(())
    }

    /// The same for relationships.
    ///
    /// # Errors
    ///
    /// As [`Self::cancel_node_id`].
    pub(crate) fn cancel_relationship_id(
        &mut self,
        id: RelationshipId,
    ) -> Result<(), NodeOpError> {
        self.relationship_ids
            .cancel(id.into())
            .map_err(NodeOpError::relationship)?;
        Ok(())
    }

    /// Begin a batch in both id spaces, at the boundary as it stands now.
    ///
    /// A batch is the span an [`IdSpace`] judges as one: a whole effects buffer,
    /// or one commit segment of a write query. Records inside one arrive grouped
    /// by shape rather than ordered by id, so the space is legitimately
    /// fragmented partway through and only has to be whole at the end — which is
    /// what [`IdSpace::verify`] asks, through [`Self::node_id_space`].
    ///
    /// Both spaces together because every caller opens both: a query that
    /// creates nodes may cascade into edges, and a buffer carries records of
    /// either kind.
    ///
    /// # Errors
    ///
    /// [`IdSpaceError`], wrapped, if either space already contradicts itself —
    /// opening a batch over a corrupt one would re-anchor the boundary on the
    /// bad value and hide it.
    /// Private: a batch is only ever opened as part of closing one, so the only
    /// production caller is [`Self::roll_id_batches`]. A version that has just
    /// been forked opens its own through [`IdSpace::new_version`].
    fn open_id_batches(&mut self) -> Result<(), NodeOpError> {
        self.node_ids.open_batch().map_err(NodeOpError::node)?;
        self.relationship_ids
            .open_batch()
            .map_err(NodeOpError::relationship)?;
        Ok(())
    }

    /// Close the open batch and begin the next one where it left the boundary.
    ///
    /// A batch is not a scope: the write path's batch ends and the next begins
    /// at one instant, partway through one `next()` of a pull-based operator,
    /// so there is no frame for a guard to wrap. One call rather than two so
    /// the open cannot be kept while the check is dropped.
    ///
    /// # Errors
    ///
    /// [`NodeOpError::IdSpace`] if the closing batch left an impossible id
    /// space, or the next one would open over a space that contradicts itself.
    pub(crate) fn roll_id_batches(&mut self) -> Result<(), NodeOpError> {
        self.verify_id_batches()?;
        self.open_id_batches()
    }

    /// Check everything this graph must be true about itself before a version
    /// of it is published.
    ///
    /// Deliberately opaque: callers are told *that* a version is checked, not
    /// what is checked, so an invariant added later needs no call-site change.
    /// Today that is the id batches, and that every relationship the batch
    /// created still ends at two live nodes; [`MvccGraph::commit`] is the
    /// place a version becomes visible, and the effects apply path and
    /// `GRAPH.BULK` ask it before that.
    ///
    /// # Errors
    ///
    /// The first refusal, naming the entity kind it is about.
    pub fn validate(&self) -> Result<(), NodeOpError> {
        self.verify_id_batches()?;
        self.verify_created_relationships()
    }

    /// Check that every relationship this batch created, and did not delete
    /// again, ends at two live nodes.
    ///
    /// Only the batch's own relationships: one that predates it was checked by
    /// the batch that created it, and deleting a node with relationships is
    /// refused before the node goes (implicitly by Cypher's `DELETE`, and by
    /// the effects apply path's `NodeHasRelationships`). O(1) per created
    /// relationship — an endpoint-index lookup and two liveness probes.
    ///
    /// # Errors
    ///
    /// [`NodeOpError::DanglingRelationship`] naming the lowest such id.
    fn verify_created_relationships(&self) -> Result<(), NodeOpError> {
        let rels = &self.relationship_ids;
        let nodes = &self.node_ids;
        // Between batches the node space is dense, so live is "below the
        // boundary and not free".
        let bound = nodes.bound();
        let free = nodes.recycled();
        // The probes are most of the cost, and the ordinary bulk create has
        // nothing free on either side: skip them there.
        let check_free = !free.is_empty();
        let live = |n: u64| n < bound && !(check_free && free.contains(n));
        let skip_freed = !rels.recycled().is_empty();
        // `taken` is untrimmed and also holds what the batch released again
        // (a cancelled reservation, a create then delete) — those are free.
        for id in rels.taken() {
            if skip_freed && rels.is_free(id) {
                continue;
            }
            if !self
                .endpoints_for_edge(id)
                .is_some_and(|(src, dst)| live(src) && live(dst))
            {
                return Err(NodeOpError::DanglingRelationship { id });
            }
        }
        Ok(())
    }

    /// Check that both batches left possible id spaces behind.
    ///
    /// # Errors
    ///
    /// [`NodeOpError::IdSpace`], naming which of the two disagreed.
    fn verify_id_batches(&self) -> Result<(), NodeOpError> {
        self.node_ids.verify().map_err(NodeOpError::node)?;
        self.relationship_ids
            .verify()
            .map_err(NodeOpError::relationship)?;
        Ok(())
    }

    /// The node id space, to ask it something this graph has no opinion about.
    ///
    /// Read-only. Every way of *moving* an id is a method on this graph, so a
    /// caller holding this cannot take one: it can check the batch
    /// ([`IdSpace::verify`]) and read the boundary, and that is the whole of it.
    #[must_use]
    pub const fn node_id_space(&self) -> &IdSpace {
        &self.node_ids
    }

    /// The same for relationships.
    #[must_use]
    pub const fn relationship_id_space(&self) -> &IdSpace {
        &self.relationship_ids
    }

    /// Where the node id space ends: ids below were handed out, ids at or above
    /// never were. True as stated only between batches, where the space is dense
    /// — which is exactly when an [`IdSpace`] is opened against it.
    #[must_use]
    pub fn node_id_bound(&self) -> u64 {
        self.node_ids.bound()
    }

    /// The same for relationships.
    #[must_use]
    pub fn relationship_id_bound(&self) -> u64 {
        self.relationship_ids.bound()
    }

    /// Create every node in `nodes` as part of a batch, or refuse and change
    /// nothing.
    ///
    /// The batch is required rather than optional because it is the only thing
    /// that can say what "already live" means here. Records inside one effects
    /// buffer are grouped by shape rather than ordered by id, so a create of
    /// 500..600 may precede one of 0..500; judged against a boundary this graph
    /// derives, the second is rejected — the derived boundary has advanced to
    /// 100 — even though the buffer is legitimate. The batch carries the boundary
    /// as it stood before any of that, which is the only one the whole buffer can
    /// be judged against.
    ///
    /// Reading the boundary off the batch rather than taking it as a parameter of
    /// its own is what stops a caller handing over a boundary that disagrees with
    /// the batch it is handing over with it.
    ///
    /// There is no unchecked way in. Every caller has a batch — the graph's own,
    /// opened when the version was forked and rolled by [`Self::roll_id_batches`]
    /// — so the check and the state move together and a caller cannot forget one.
    ///
    /// # Errors
    ///
    /// [`IdSpaceError::AlreadyLive`], wrapped, for the lowest id it cannot
    /// create — one already handed out and not freed. Refusing is the point: the
    /// live count moves unconditionally, so an already-live id used to
    /// double-count silently and shift every later fresh id.
    ///
    /// [`NodeOpError::IdSpace`] if the ids do not fit the batch — see
    /// [`crate::graph::id_space`].
    pub fn create_nodes(
        &mut self,
        nodes: &RoaringTreemap,
    ) -> Result<(), NodeOpError> {
        // One call, checked and moved together. The bin and the live count are
        // this graph's half of the boundary and they are handed over; the
        // boundary as it stood is the batch's, and the batch keeps it. An id
        // reaches the graph through this function or not at all, so nothing that
        // creates a node can be added later and forget to account for it.
        self.node_ids.create(nodes).map_err(NodeOpError::node)?;
        self.grow_for_nodes(nodes);
        Ok(())
    }

    /// Size the matrices to hold `nodes`.
    ///
    /// The ledger half of the same transition is [`IdSpace::create`] and the two
    /// are always a pair, so this is private and [`Self::create_nodes`] is the
    /// only way in.
    fn grow_for_nodes(
        &mut self,
        nodes: &RoaringTreemap,
    ) {
        // Ensure capacity covers the highest node ID (effects replay may
        // insert IDs above the current count when applied one-by-one).
        if let Some(max_id) = nodes.max() {
            let needed = max_id + 1;
            if needed > self.node_cap {
                self.node_cap = grow_cap(self.node_cap, needed);
                self.resize_node_matrices();
            }
        }

        self.resize();
    }

    #[must_use]
    pub fn max_node_id(&self) -> u64 {
        self.node_ids.max_id()
    }

    #[must_use]
    pub fn max_relationship_id(&self) -> u64 {
        self.relationship_ids.max_id()
    }

    /// Set node attributes from a record's row-major layout.
    ///
    /// The map form makes the caller allocate a `Vec` per entity and this
    /// function sort them back into the id order the wire already had. See
    /// [`AttributeStore::insert_attrs_rows`].
    /// Set node attributes from a record's row-major layout, for nodes already
    /// known to share one label set.
    ///
    /// The labels come from the caller rather than from this graph, and on the
    /// replication path that is the point: a v3 `UPDATE_NODE` states the label
    /// set the **primary** saw, so indexing under it makes the replica's index
    /// hold what the primary's holds. Re-deriving would make the replica agree
    /// with its own label matrix instead — which is the same thing only while
    /// nothing has diverged, and silently different once something has.
    ///
    /// It is also the cheap form, for the same reason
    /// [`Self::set_relationships_attributes_of_type`] is.
    /// [`Self::set_nodes_attributes`] walks `node_labels_matrix.iter(id, id)`
    /// per node to answer the same question; here the record's grouping has
    /// already established that every id shares the set, so the
    /// indexed-attribute test runs once for the whole record and what remains
    /// per node is an insert.
    ///
    /// There is no label-deriving row-major counterpart any more. Both callers
    /// on the apply path — `CREATE_NODE` and `UPDATE_NODE` — carry a
    /// `LabelSet`, so one existed only to re-derive what the record had already
    /// stated. `set_nodes_attributes` stays for the query path, where the node
    /// is being read anyway and no record has spoken for it.
    ///
    /// `label_ids` must be within this graph's dictionary — `apply` bounds-checks
    /// them through `checked_label_ids` before calling, the way C's
    /// `ApplyUpdateEdge` checks its `r_id`.
    pub fn set_nodes_attributes_rows_of_labels(
        &mut self,
        ids: &[u64],
        label_ids: &[u64],
        attr_ids: &[u16],
        rows: &[Value],
        docs: &mut IndexDocs,
    ) -> Result<(usize, usize), String> {
        let index_add_docs = &mut docs.node_adds;
        // Before the overwrite, while the old values are still readable.
        #[cfg(feature = "index-falkordb")]
        docs.native.extend(graph_writes::node_rows_set(
            self, ids, label_ids, attr_ids, rows,
        ));
        let (nremoved, nset) = self.node_attrs.insert_attrs_rows(ids, attr_ids, rows)?;

        if self.node_indexer.has_indices() {
            for &label_id in label_ids {
                let Some(label) = self.node_labels.get(label_id as usize) else {
                    continue;
                };
                // Once per (label, attribute) for the whole record, rather than
                // once per (node, label, attribute).
                let indexed = attr_ids.iter().any(|&attr_id| {
                    self.attrs_name
                        .get(attr_id as usize)
                        .is_some_and(|key| self.node_indexer.has_indexed_attr(label, key))
                });
                if indexed {
                    let docs = index_add_docs.entry(label_id).or_default();
                    docs.extend(ids.iter().copied());
                }
            }
        }
        Ok((nremoved, nset))
    }

    pub fn set_nodes_attributes(
        &mut self,
        attrs: &FxHashMap<u64, Vec<(u16, Value)>>,
        docs: &mut IndexDocs,
    ) -> Result<(usize, usize), String> {
        let index_add_docs = &mut docs.node_adds;
        // Before the overwrite, while the old values are still readable.
        #[cfg(feature = "index-falkordb")]
        docs.native
            .extend(graph_writes::node_attrs_set(self, attrs));
        let (nremoved, nset) = self.node_attrs.insert_attrs(attrs)?;

        if self.node_indexer.has_indices() {
            for (id, attrs) in attrs {
                for (_, label_id) in self.node_labels_matrix.iter(*id, *id) {
                    let label = &self.node_labels[label_id as usize];
                    for (attr_id, _) in attrs {
                        let Some(key) = self.attrs_name.get(*attr_id as usize) else {
                            continue;
                        };
                        if self.node_indexer.has_indexed_attr(label, key) {
                            index_add_docs.entry(label_id).or_default().insert(*id);
                        }
                    }
                }
            }
        }
        Ok((nremoved, nset))
    }

    /// Import attributes for nodes created in the current transaction.
    ///
    /// `new_labels` maps each created node to the label ids set this
    /// transaction (a created node has no committed labels, so this is its
    /// complete label set). Reading labels from here instead of
    /// `node_labels_matrix` keeps the write path off `iter`, whose `wait`
    /// forces a pending-delta merge per query — O(accumulated delta).
    pub fn import_node_attrs(
        &mut self,
        attrs: &FxHashMap<u64, Vec<(u16, Value)>>,
        new_labels: &FxHashMap<u64, Vec<u64>>,
        docs: &mut IndexDocs,
    ) -> usize {
        let index_add_docs = &mut docs.node_adds;
        let nset = self.node_attrs.import_attrs(attrs);

        #[cfg(feature = "index-falkordb")]
        docs.native
            .extend(graph_writes::new_node_attrs(self, attrs, new_labels));

        if self.node_indexer.has_indices() {
            for (id, attrs) in attrs {
                let Some(label_ids) = new_labels.get(id) else {
                    continue;
                };
                for &label_id in label_ids {
                    let label = &self.node_labels[label_id as usize];
                    for (attr_id, _) in attrs {
                        let Some(key) = self.attrs_name.get(*attr_id as usize) else {
                            continue;
                        };
                        if self.node_indexer.has_indexed_attr(label, key) {
                            index_add_docs.entry(label_id).or_default().insert(*id);
                        }
                    }
                }
            }
        }
        nset
    }

    /// Import pre-resolved node attributes directly into the cache.
    /// Used by bulk insert to avoid per-node OrderMap allocations.
    ///
    /// Marks the imported nodes for (re)indexing, as
    /// [`import_node_attrs`](Self::import_node_attrs) does. `label_ids` is the label set the
    /// caller is applying to every node in `data` — a bulk token carries one label set for
    /// all its rows, so it is passed once instead of looked up per node.
    ///
    /// Keeping the tracking here rather than at the call site matters: the alternative is an
    /// unwritten rule that attributes must be imported before labels are set, and the natural
    /// order (the one [`Pending::commit`] uses) is the opposite, so a future refactor would
    /// silently stop indexing bulk-loaded rows.
    ///
    /// Tracking runs **before** the import because `import_attrs_resolved` drains `data`.
    pub fn import_node_attrs_resolved(
        &mut self,
        data: &mut Vec<(u64, Vec<(u16, Value)>)>,
        label_ids: &[LabelId],
        docs: &mut IndexDocs,
    ) -> usize {
        let index_add_docs = &mut docs.node_adds;
        #[cfg(feature = "index-falkordb")]
        docs.native
            .extend(graph_writes::bulk_node_attrs(self, data, label_ids));

        if self.node_indexer.has_indices() {
            for (id, attrs) in data.iter() {
                for label_id in label_ids {
                    let label = &self.node_labels[label_id.0];
                    for (attr_id, _) in attrs {
                        let Some(key) = self.attrs_name.get(*attr_id as usize) else {
                            continue;
                        };
                        if self.node_indexer.has_indexed_attr(label, key) {
                            index_add_docs
                                .entry(label_id.0 as u64)
                                .or_default()
                                .insert(*id);
                        }
                    }
                }
            }
        }
        self.node_attrs.import_attrs_resolved(data)
    }

    /// Resolve a node attribute name to its index, creating if needed.
    pub fn get_or_create_node_attr_id(
        &mut self,
        attr: &Arc<String>,
    ) -> u16 {
        self.attrs_name.get_or_create(attr)
    }

    /// Resolve a node attribute name to its index, if it exists.
    #[must_use]
    pub fn get_node_attr_id(
        &self,
        attr: &Arc<String>,
    ) -> Option<u16> {
        self.attrs_name.get_index_of(attr).map(|i| i as u16)
    }

    /// Node attribute name for an index.
    #[must_use]
    pub fn node_attr_name(
        &self,
        attr_id: u16,
    ) -> Option<Arc<String>> {
        self.attrs_name.get(attr_id as usize).cloned()
    }

    /// Resolve a relationship attribute name to its index, if it exists.
    #[must_use]
    pub fn get_rel_attr_id(
        &self,
        attr: &Arc<String>,
    ) -> Option<u16> {
        self.attrs_name.get_index_of(attr).map(|i| i as u16)
    }

    /// Relationship attribute name for an index.
    #[must_use]
    pub fn rel_attr_name(
        &self,
        attr_id: u16,
    ) -> Option<Arc<String>> {
        self.attrs_name.get(attr_id as usize).cloned()
    }

    /// Import pre-resolved relationship attributes directly into the cache.
    ///
    /// Marks the imported edges for (re)indexing, exactly as
    /// [`import_relationship_attrs`](Self::import_relationship_attrs) does; the caller
    /// publishes them with [`commit_edge_index`](Self::commit_edge_index). Tracking runs
    /// **before** the import because `import_attrs_resolved` drains `data`.
    pub fn import_relationship_attrs_resolved(
        &mut self,
        data: &mut Vec<(u64, Vec<(u16, Value)>)>,
        type_id: TypeId,
        docs: &mut IndexDocs,
    ) -> usize {
        let index_add_edge_docs = &mut docs.edge_adds;
        #[cfg(feature = "index-falkordb")]
        docs.native
            .extend(graph_writes::bulk_edge_attrs(self, data, type_id));

        self.track_edge_index_updates_of_type(
            type_id,
            data.iter().map(|(id, attrs)| (id, attrs)),
            index_add_edge_docs,
        );
        self.relationship_attrs.import_attrs_resolved(data)
    }

    /// Resolve a relationship attribute name to its index, creating if needed.
    pub fn get_or_create_rel_attr_id(
        &mut self,
        attr: &Arc<String>,
    ) -> u16 {
        self.attrs_name.get_or_create(attr)
    }

    pub fn import_relationship_attrs(
        &mut self,
        attrs: &FxHashMap<u64, Vec<(u16, Value)>>,
        docs: &mut IndexDocs,
    ) -> usize {
        let index_add_edge_docs = &mut docs.edge_adds;
        let nset = self.relationship_attrs.import_attrs(attrs);

        #[cfg(feature = "index-falkordb")]
        docs.native
            .extend(graph_writes::new_edge_attrs(self, attrs));

        self.track_edge_index_updates(attrs, index_add_edge_docs);
        nset
    }

    /// Mark every `(type_id, edge_id)` whose changed attributes are
    /// indexed so the next `commit_edge_index` pass rebuilds their
    /// documents. Shared by the import and set paths.
    /// As [`track_edge_index_updates`](Self::track_edge_index_updates), for a caller that
    /// already knows the type every edge in `attrs` carries — a bulk token has exactly one.
    ///
    /// `get_relationship_type_id` iterates `relationship_type_matrix`, and `iter` waits on the
    /// matrix, forcing a pending-delta merge. Doing that once per edge right after
    /// `create_relationships_bulk` enqueued a large delta is the per-entity overhead the bulk
    /// path exists to avoid, so the type is resolved once by the caller instead.
    fn track_edge_index_updates_of_type<'a>(
        &self,
        type_id: TypeId,
        attrs: impl IntoIterator<Item = (&'a u64, &'a Vec<(u16, Value)>)>,
        index_add_edge_docs: &mut FxHashMap<u64, RoaringTreemap>,
    ) {
        if !self.edge_indexer.has_indices() {
            return;
        }
        let type_name = &self.relationship_types[type_id.0];
        for (id, attrs) in attrs {
            for (attr_id, _) in attrs {
                let Some(key) = self.attrs_name.get(*attr_id as usize) else {
                    continue;
                };
                if self.edge_indexer.has_indexed_attr(type_name, key) {
                    index_add_edge_docs
                        .entry(type_id.0 as u64)
                        .or_default()
                        .insert(*id);
                }
            }
        }
    }

    fn track_edge_index_updates<'a>(
        &self,
        attrs: impl IntoIterator<Item = (&'a u64, &'a Vec<(u16, Value)>)>,
        index_add_edge_docs: &mut FxHashMap<u64, RoaringTreemap>,
    ) {
        if !self.edge_indexer.has_indices() {
            return;
        }
        for (id, attrs) in attrs {
            let type_id = self.get_relationship_type_id(RelationshipId(*id));
            let type_name = &self.relationship_types[type_id.0];
            for (attr_id, _) in attrs {
                let Some(key) = self.attrs_name.get(*attr_id as usize) else {
                    continue;
                };
                if self.edge_indexer.has_indexed_attr(type_name, key) {
                    index_add_edge_docs
                        .entry(type_id.0 as u64)
                        .or_default()
                        .insert(*id);
                }
            }
        }
    }

    /// Give every id in `ids` every label in `label_ids`.
    ///
    /// The pair form takes the cartesian product already expanded, which means
    /// the caller allocates `ids x labels` twice over and this function then
    /// regroups it back into the per-label lists it wanted in the first place.
    /// A million-node create with one label spends about 24 MB of scratch
    /// saying something the two input slices already said.
    ///
    /// Here the product stays an iterator: `set_all` consumes one, and each
    /// label's diagonal is just `ids`.
    pub fn set_node_labels_product(
        &mut self,
        ids: &[u64],
        label_ids: &[u64],
        docs: &mut IndexDocs,
        all_new: bool,
    ) {
        let index_add_docs = &mut docs.node_adds;
        #[cfg(feature = "index-falkordb")]
        docs.native
            .extend(graph_writes::labels_product_added(self, ids, label_ids));

        // Which labels are indexed, decided once per label rather than once per
        // pair. Collected before the mutations below so the immutable borrows
        // of `node_labels` and `node_indexer` end first.
        let indexed: Vec<u64> = label_ids
            .iter()
            .copied()
            .filter(|&lid| {
                self.node_labels
                    .get(lid as usize)
                    .is_some_and(|label| self.node_indexer.has_index(label))
            })
            .collect();
        for lid in indexed {
            let label = self.node_labels[lid as usize].clone();
            for &id in ids {
                // The node has to hold an attribute this label *indexes*, not
                // merely some attribute.
                //
                // The point is symmetry with the remove side rather than a
                // demonstrated leak. `delete_nodes` has always tested exactly
                // this, so with the looser test here a node whose attributes
                // are none of them indexed was added to the index and never
                // matched by a removal. Whether RediSearch materializes a
                // document for a node with no indexed field is not observable
                // from outside the module — it is linked in, so `FT.INFO` is
                // not reachable — so this makes the two predicates the same
                // rather than fixing something measured.
                if self
                    .attr_names(&self.node_attrs, id)
                    .any(|attr| self.node_indexer.has_indexed_attr(&label, &attr))
                {
                    index_add_docs.entry(lid).or_default().insert(id);
                }
            }
        }

        for &lid in label_ids {
            let diag = ids.iter().map(|&id| (id, id));
            if all_new {
                self.labels_matices[lid as usize].set_all::<true>(diag);
            } else {
                self.labels_matices[lid as usize].set_all::<false>(diag);
            }
        }

        // The cartesian product, handed to GraphBLAS as two index lists rather
        // than enumerated here. `GrB_Matrix_assign` forms `ids x label_ids`
        // itself, so a million nodes taking one label is one call instead of a
        // million `setElement`s — and the slices are already exactly the `I`
        // and `J` it wants, so nothing is built to pass them.
        //
        // `set_product::<false>` cannot take that path — an existing node's
        // pair may already be live in the committed base, which only a
        // per-entry probe can tell — so it degrades to the iterator form.
        if all_new {
            self.node_labels_matrix.set_product::<true>(ids, label_ids);
        } else {
            self.node_labels_matrix.set_product::<false>(ids, label_ids);
        }
    }

    /// Bulk set node labels using parallel row/col slices (2 FFI calls per matrix).
    ///
    /// `all_new` asserts every `(node, label)` pair is fresh — the node was
    /// created in this transaction — allowing the unchecked delta insert.
    /// `SET n:Label` on pre-existing nodes may re-add a committed pair, which
    /// must go through the checked path to keep `dp ∩ m = ∅`.
    pub fn set_nodes_labels_bulk(
        &mut self,
        label_rows: &[u64],
        label_cols: &[u64],
        docs: &mut IndexDocs,
        all_new: bool,
    ) {
        let index_add_docs = &mut docs.node_adds;
        self.resize();

        #[cfg(feature = "index-falkordb")]
        docs.native
            .extend(graph_writes::labels_added(self, label_rows, label_cols));

        // Collect entries grouped by label for per-label matrices
        let num_labels = self.labels_matices.len();
        let mut by_label: Vec<Vec<u64>> = vec![Vec::new(); num_labels];

        for (&id, &label_id) in label_rows.iter().zip(label_cols.iter()) {
            by_label[label_id as usize].push(id);

            let label = &self.node_labels[label_id as usize];
            if self.node_indexer.has_index(label) && self.node_attrs.has_attributes(id) {
                index_add_docs.entry(label_id).or_default().insert(id);
            }
        }

        let pairs = label_rows.iter().copied().zip(label_cols.iter().copied());
        if all_new {
            self.node_labels_matrix.set_all::<true>(pairs);
        } else {
            self.node_labels_matrix.set_all::<false>(pairs);
        }

        for (lid, ids) in by_label.into_iter().enumerate() {
            if !ids.is_empty() {
                let diag = ids.iter().map(|&id| (id, id));
                if all_new {
                    self.labels_matices[lid].set_all::<true>(diag);
                } else {
                    self.labels_matices[lid].set_all::<false>(diag);
                }
            }
        }
    }

    pub fn remove_nodes_labels(
        &mut self,
        label_rows: &[u64],
        label_cols: &[u64],
        docs: &mut IndexDocs,
    ) {
        let remove_docs = &mut docs.node_removes;
        self.resize();

        #[cfg(feature = "index-falkordb")]
        docs.native
            .extend(graph_writes::labels_removed(self, label_rows, label_cols));

        for (&id, &label_id) in label_rows.iter().zip(label_cols.iter()) {
            self.node_labels_matrix.remove(id, label_id);
            self.labels_matices[label_id as usize].remove(id, id);
            let label = &self.node_labels[label_id as usize];
            if self.node_indexer.has_index(label) {
                remove_docs.entry(label_id).or_default().insert(id);
            }
        }
    }

    /// Delete `deleted_nodes`, returning the `(node_id, label_id)` pairs they
    /// carried.
    ///
    /// The pairs are a by-product, not extra work: clearing the label matrices
    /// already has to collect them. Effects replication needs them because the
    /// label set is what tells a replica which label-scoped indexes to clear,
    /// and by the time the effect is encoded — after `commit` — the labels are
    /// gone from the graph. Same reason `delete_relationships` hands back its
    /// endpoints. They arrive grouped by node in ascending node order; a node
    /// with no labels contributes none, so a caller reconciling against
    /// `deleted_nodes` must expect gaps.
    pub fn delete_nodes(
        &mut self,
        deleted_nodes: &RoaringTreemap,
        docs: &mut IndexDocs,
    ) -> Result<Vec<DeletedNodeLabel>, NodeOpError> {
        let remove_docs = &mut docs.node_removes;
        // Judged and freed together: every id asked for is refused or none is,
        // and the ones that survive that leave the live count and enter the bin
        // in one step. Nodes resolve exactly, so the two sets are one.
        self.node_ids
            .release(deleted_nodes, deleted_nodes)
            .map_err(NodeOpError::node)?;

        // After the release, so a refused delete leaves the index untouched too, and before
        // the teardown below, while the labels and attributes are still readable.
        #[cfg(feature = "index-falkordb")]
        docs.native
            .extend(graph_writes::nodes_deleted(self, deleted_nodes));

        // Every removal below is a per-entity tombstone, and every lookup below
        // is a row seek. Nothing here touches an entry that does not belong to a
        // deleted node, so the cost is O(|deleted|) rather than O(graph).
        //
        // It used to build diagonal mask matrices and hand them to `remove_mask`,
        // whose `element_wise_multiply` takes `m` as an operand: GraphBLAS then
        // walks the base matrix's vectors, so a delete of any size cost O(graph).
        // Deleting one node from a 200,000-node graph spent ~240M instructions,
        // against ~564k in the C implementation, which is flat in graph size.
        // `VersionedMatrix::remove` marks the same tombstone one entry at a time
        // (`dm[i,j] = true` when `m` holds the pair, else drop it from `dp`),
        // which is what `remove_nodes_labels` already does for label removal.
        //
        // The two are equivalent because `dp ∩ m = ∅` holds for
        // `VersionedMatrix<bool>`: its `set` clears the `dm` tombstone when `m`
        // already holds the pair instead of writing a shadowing `dp` entry. So
        // `remove_mask`'s two effects — tombstone `mask ∩ m`, drop `mask ∩ dp` —
        // can never both apply to one entry, which is exactly the choice `remove`
        // makes per entry. (The valued matrices *do* allow `dp` to shadow `m`;
        // `remove` is defined only on the boolean ones.)
        //
        // That invariant is covered by
        // `delta_invariants_hold_across_mutation_sequences`, and this specific
        // substitution is machine-checked as
        // `eff_removeMask_eq_foldl_remove` in `proofs/versioned_matrix`.
        // Which labels each deleted node carries. Collected first because the
        // iterator borrows `node_labels_matrix` for the duration and the removals
        // below need it mutably.
        //
        // `seek` is a row jump (`GxB_rowIterator_seekRow`), so one iterator
        // re-seeked per deleted row replaces both the previous full scan and the
        // per-node iterator construction that the full scan had replaced. There
        // is no size threshold: this is O(|deleted|) for every delete, so there
        // is no shape of input the old whole-matrix scan would win.
        let mut pairs: Vec<DeletedNodeLabel> = Vec::with_capacity(deleted_nodes.len() as usize);
        {
            let mut it = self.node_labels_matrix.iter(0, self.node_cap);
            for node_id in deleted_nodes {
                it.seek(node_id, node_id);
                pairs.extend(
                    it.by_ref()
                        .map(|(node, label)| DeletedNodeLabel { node, label }),
                );
            }
        }

        for &DeletedNodeLabel {
            node: node_id,
            label: label_id,
        } in &pairs
        {
            let lid = label_id as usize;

            let label = &self.node_labels[lid];
            if self.node_indexer.has_index(label) {
                for attr in self.attr_names(&self.node_attrs, node_id) {
                    if self.node_indexer.has_indexed_attr(label, &attr) {
                        remove_docs.entry(label_id).or_default().insert(node_id);
                        break;
                    }
                }
            }

            self.labels_matices[lid].remove(node_id, node_id);
            self.node_labels_matrix.remove(node_id, label_id);
        }

        self.node_attrs.remove_all(deleted_nodes);
        Ok(pairs)
    }

    pub fn get_node_relationships(
        &self,
        id: NodeId,
    ) -> impl Iterator<Item = (NodeId, NodeId, RelationshipId)> + '_ {
        self.relationship_matrices
            .iter()
            .flat_map(move |m| m.iter(id.0, id.0, false).chain(m.iter(id.0, id.0, true)))
            .map(|(src, dest, id)| {
                let src_node = NodeId(src);
                let dest_node = NodeId(dest);
                (src_node, dest_node, RelationshipId(id))
            })
    }

    /// The lowest of `nodes` that still has a relationship, in either direction.
    ///
    /// Two questions, each answered in bulk with a cost that follows `nodes`
    /// rather than the graph: whether any of them has one at all, and — only
    /// when one does, which is a refusal — which is the lowest.
    ///
    /// * Outgoing: the graph-wide adjacency matrix, which is exact for this (a
    ///   pair leaves it when its last edge of any type goes), so one matrix
    ///   answers for every type.
    /// * Incoming: that matrix is stored by row, and a column question asked of
    ///   it visits every row. Each type's backward adjacency holds the same
    ///   pairs by destination, so the incoming side asks those instead —
    ///   one bulk product per type, each following `nodes`.
    ///
    /// Both are `Aᵀ·x` over the indicator `x` of `nodes`, which GraphBLAS
    /// computes by pushing just the selected rows.
    #[must_use]
    pub fn first_node_with_relationships(
        &self,
        nodes: &RoaringTreemap,
    ) -> Option<u64> {
        let adj = &self.adjacancy_matrix;
        if nodes.is_empty() || adj.nvals() == 0 {
            return None;
        }
        // An id past the matrices has neither a row nor a column.
        let n = adj.nrows();
        let ids: Vec<u64> = nodes.iter().take_while(|&id| id < n).collect();
        if ids.is_empty() {
            return None;
        }
        let x = Vector::<bool>::from_sorted_indices(n, &ids);
        let touched = adj.count_in_rows(&x) > 0
            || self
                .relationship_matrices
                .iter()
                .any(|t| t.count_pairs_into(&x) > 0);
        if !touched {
            return None;
        }

        // Some node in the set has a relationship, and the buffer will be
        // refused: find the lowest, re-seeking one iterator per matrix.
        let mut out = adj.iter(0, 0);
        let mut inc: Vec<_> = self
            .relationship_matrices
            .iter()
            .map(|t| t.iter(0, 0, true))
            .collect();
        ids.into_iter().find(|&id| {
            out.seek(id, id);
            out.next().is_some()
                || inc.iter_mut().any(|it| {
                    it.seek(id, id);
                    it.next().is_some()
                })
        })
    }

    /// Returns an iterator over all relationship tensors (one per type).
    pub fn relationship_matrices_iter(&self) -> impl Iterator<Item = &Tensor> {
        self.relationship_matrices.iter()
    }

    /// Get all relationships for a node, optionally filtered by relationship types.
    /// When `types` is empty, returns relationships of all types (equivalent to `[*]`).
    /// Tuples are always `(src, dst, edge_id)` in original edge orientation,
    /// regardless of `direction`.
    pub fn get_node_relationships_by_type(
        &self,
        id: NodeId,
        types: &[Arc<String>],
        direction: EdgeDirection,
    ) -> impl Iterator<Item = (NodeId, NodeId, RelationshipId)> + '_ {
        let matrices: Vec<&Tensor> = if types.is_empty() {
            self.relationship_matrices.iter().collect()
        } else {
            types
                .iter()
                .filter_map(|t| self.get_relationship_matrix(t))
                .collect()
        };
        let (with_outgoing, with_incoming) = match direction {
            EdgeDirection::Outgoing => (true, false),
            EdgeDirection::Incoming => (false, true),
            EdgeDirection::Both => (true, true),
        };
        matrices
            .into_iter()
            .flat_map(move |m| {
                let outgoing = with_outgoing
                    .then(|| m.iter(id.0, id.0, false))
                    .into_iter()
                    .flatten();
                // A self-loop appears in both halves; when the outgoing half is
                // also enumerated, drop it from the incoming half.
                let incoming = with_incoming
                    .then(|| {
                        m.iter(id.0, id.0, true)
                            .filter(move |(src, _, _)| !with_outgoing || *src != id.0)
                    })
                    .into_iter()
                    .flatten();
                outgoing.chain(incoming)
            })
            .map(|(src, dest, id)| (NodeId(src), NodeId(dest), RelationshipId(id)))
    }

    /// Count the number of incoming edges to a node.
    #[must_use]
    pub fn get_node_indegree(
        &self,
        id: NodeId,
    ) -> usize {
        self.relationship_matrices
            .iter()
            .map(|m| m.col_degree(id.0) as usize)
            .sum()
    }

    /// Count the number of incoming edges to a node, filtered by relationship types.
    #[must_use]
    pub fn get_node_indegree_by_type(
        &self,
        id: NodeId,
        types: &[Arc<String>],
    ) -> usize {
        types
            .iter()
            .filter_map(|t| self.get_relationship_matrix(t))
            .map(|m| m.col_degree(id.0) as usize)
            .sum()
    }

    /// Count the number of outgoing edges from a node.
    #[must_use]
    pub fn get_node_outdegree(
        &self,
        id: NodeId,
    ) -> usize {
        self.relationship_matrices
            .iter()
            .map(|m| m.row_degree(id.0) as usize)
            .sum()
    }

    /// Count the number of outgoing edges from a node, filtered by relationship types.
    #[must_use]
    pub fn get_node_outdegree_by_type(
        &self,
        id: NodeId,
        types: &[Arc<String>],
    ) -> usize {
        types
            .iter()
            .filter_map(|t| self.get_relationship_matrix(t))
            .map(|m| m.row_degree(id.0) as usize)
            .sum()
    }

    #[must_use]
    pub fn get_nodes(
        &self,
        labels: &OrderSet<Arc<String>>,
        min_row: u64,
    ) -> Box<dyn Iterator<Item = NodeId>> {
        if labels.is_empty() {
            // Full scan: live node IDs are exactly `0..=max_node_id` minus the
            // deleted set. A range walk with a roaring-bitmap membership check
            // avoids the per-element GraphBLAS row-iterator overhead, which
            // dominates the cost of unfiltered `MATCH (n)` scans.
            //
            // It is also why no matrix of live nodes is kept: the bitmap
            // already answers the question, and maintaining a parallel
            // GraphBLAS diagonal made every write pay structural upkeep
            // proportional to the graph rather than to the write.
            if self.node_ids.live() == 0 {
                return Box::new(std::iter::empty());
            }
            let max_id = self.max_node_id();
            if self.node_ids.recycled().is_empty() {
                return Box::new((min_row..=max_id).map(NodeId));
            }
            let deleted = self.node_ids.recycled().clone();
            return Box::new(
                (min_row..=max_id)
                    .filter_map(move |id| (!deleted.contains(id)).then_some(NodeId(id))),
            );
        }
        if labels.len() == 1 {
            if let Some(label_matrix) = self.get_label_matrix(&labels[0]) {
                return Box::new(
                    label_matrix
                        .iter(min_row, u64::MAX)
                        .map(|(id, _)| NodeId(id)),
                );
            }
            return Box::new(std::iter::empty());
        }
        let matrices = labels
            .iter()
            .map(|label| self.get_label_matrix(label))
            .collect::<Option<Vec<_>>>();
        Box::new(
            matrices
                .map_or_else(
                    || self.zero_matrix.extract().iter(min_row, u64::MAX),
                    |mut matrices| {
                        let mut iter = matrices.iter_mut();
                        let mut m = iter.next().unwrap().extract();
                        for label_matrix in iter {
                            m.element_wise_multiply(
                                None,
                                None,
                                Some(&label_matrix.extract()),
                                None,
                            );
                        }
                        m.iter(min_row, u64::MAX)
                    },
                )
                .map(|(id, _)| NodeId(id)),
        )
    }

    #[allow(clippy::cast_possible_truncation)]
    pub fn get_node_label_ids(
        &self,
        id: NodeId,
    ) -> impl Iterator<Item = LabelId> {
        self.node_labels_matrix
            .iter(id.0, id.0)
            .map(|(_, l)| LabelId(l as usize))
    }

    pub fn get_node_labels(
        &self,
        id: NodeId,
    ) -> impl Iterator<Item = Arc<String>> {
        self.get_node_label_ids(id)
            .map(move |label_id| self.node_labels[label_id.0].clone())
    }

    #[must_use]
    pub fn get_node_attribute(
        &self,
        id: NodeId,
        attr: &Arc<String>,
    ) -> Option<Value> {
        self.attr_by_name(&self.node_attrs, id.0, attr)
    }

    /// Fetches a node attribute using a pre-resolved attribute index.
    /// Use `get_node_attribute_id` to resolve the index once, then call
    /// this method for each node to avoid repeated string lookups.
    #[must_use]
    pub fn get_node_attribute_by_idx(
        &self,
        id: NodeId,
        attr_idx: u16,
    ) -> Option<Value> {
        self.node_attrs.get_attr_by_idx(id.0, attr_idx)
    }

    /// Batch variant of `get_node_attribute_by_idx`.
    /// Pushes one `Value` per id into `out`, substituting `default` for
    /// missing entries (so callers don't allocate a temp `Vec<Option<_>>`).
    pub fn get_node_attributes_by_idx(
        &self,
        ids: &[NodeId],
        attr_idx: u16,
        default: &Value,
        out: &mut Vec<Value>,
    ) {
        // SAFETY: NodeId is `#[repr(transparent)]` over u64.
        let keys: &[u64] = unsafe { std::slice::from_raw_parts(ids.as_ptr().cast(), ids.len()) };
        self.node_attrs
            .get_attrs_by_idx_batch_into(keys, attr_idx, default, out);
    }

    /// Create relationships of a single type using flat arrays.
    ///
    /// Avoids HashMap overhead while using individual GraphBLAS set calls. The
    /// id space is required rather than optional: every caller has one now, and
    /// "checked against nothing" was a value pretending to be a mode.
    ///
    /// # Errors
    ///
    /// [`IdSpaceError`], wrapped, when `id_space` is given and the ids do not fit
    /// it — the relationship counterpart of what [`Self::create_nodes`] refuses.
    pub fn create_relationships_bulk(
        &mut self,
        type_name: &Arc<String>,
        srcs: &[u64],
        dsts: &[u64],
        rel_ids: &[u64],
    ) -> Result<(), NodeOpError> {
        // The three slices are read positionally below — `set_all_from_slices`,
        // the endpoint index and the type matrix each walk all of `rel_ids`,
        // zipped against `srcs` and `dsts`. The id space is told about the ids
        // as a *set*. Nothing reconciles those two readings, so a caller that
        // breaks either one makes them describe different graphs: `[0, 0]`
        // counts one relationship and builds two tensor edges under the one id,
        // and a short `srcs` silently truncates the zips while the id space has
        // already counted every id.
        //
        // Refused rather than reconciled, because every shape that gets here is
        // malformed and there is no reading of it to prefer. It matters most on
        // `effects/v3/apply.rs`, where the ids arrive off the wire in a decoded
        // `IdList` — the one caller whose input this process did not produce.
        if srcs.len() != rel_ids.len() || dsts.len() != rel_ids.len() {
            return Err(NodeOpError::Graph(format!(
                "bulk relationship create got {} ids, {} sources and {} destinations; \
                 the three must describe the same edges",
                rel_ids.len(),
                srcs.len(),
                dsts.len()
            )));
        }
        let ids: RoaringTreemap = rel_ids.iter().copied().collect();
        if ids.len() != rel_ids.len() as u64 {
            return Err(NodeOpError::Graph(format!(
                "bulk relationship create got {} ids of which only {} are distinct; \
                 an id names one edge",
                rel_ids.len(),
                ids.len()
            )));
        }
        self.relationship_ids
            .create(&ids)
            .map_err(NodeOpError::relationship)?;

        if let Some(&max_id) = rel_ids.iter().max() {
            let needed = max_id + 1;
            if needed > self.relationship_cap {
                self.relationship_cap = grow_cap(self.relationship_cap, needed);
                self.resize_relationship_matrices();
            }
        }

        self.get_relationship_matrix_mut(type_name);
        let type_idx = self
            .relationship_types
            .iter()
            .position(|t| t.as_str() == type_name.as_str())
            .unwrap();

        self.resize();

        self.relationship_matrices[type_idx].set_all_from_slices(srcs, dsts, rel_ids);

        // Maintain the graph-wide reverse index alongside the tensor edges.
        // Reserve exactly: MVCC clones reset capacity to `len`, so amortized
        // doubling here would only leave ~2x slack behind, never save reallocs.
        let endpoints = Arc::make_mut(&mut self.edge_endpoints);
        // Size for the whole batch first: growing per edge is a reallocation
        // per edge, since the index reserves exactly rather than doubling.
        if let (Some(&max_id), Some(max_endpoint)) = (
            rel_ids.iter().max(),
            srcs.iter().chain(dsts.iter()).max().copied(),
        ) {
            endpoints.prepare(max_id, max_endpoint);
        }
        for ((&src, &dst), &id) in srcs.iter().zip(dsts.iter()).zip(rel_ids.iter()) {
            endpoints.set(id, src, dst);
        }

        self.adjacancy_matrix
            .set_all::<false>(srcs.iter().copied().zip(dsts.iter().copied()));

        let type_id = type_idx as u64;
        let type_ids: Vec<u64> = vec![type_id; rel_ids.len()];
        self.relationship_type_matrix
            .set_all::<true>(rel_ids.iter().copied().zip(type_ids.iter().copied()));
        Ok(())
    }

    /// Fold oversized delta-plus into the base for all shared matrices at
    /// the end of a GRAPH.BULK command, preventing dp accumulation across
    /// commands. `fold_latched` latches the fold decision (via `wait`) and
    /// executes it immediately — mutations are done here, so the mid-tx
    /// fold pathology cannot occur, and deferring to the next version's
    /// `dup`/`flush` would leave the final command's deltas unfolded.
    pub fn flush_for_bulk(&mut self) {
        self.node_labels_matrix.fold_latched();
        for m in &mut self.labels_matices {
            m.fold_latched();
        }
        self.adjacancy_matrix.fold_latched();
        self.relationship_type_matrix.fold_latched();
        for t in &mut self.relationship_matrices {
            t.fold_latched();
        }
    }

    /// Prepare a just-committed version for publication: fold every delta that
    /// has grown comparable to its base into that base, then materialize the
    /// committed base (`m`) layer of every matrix and tensor.
    ///
    /// Folding bounds a committed version's delta memory; see
    /// [`VersionedMatrix::fold_oversized`] for why the sub-hatch deltas are
    /// deliberately left for the next `flush`.
    ///
    /// Waiting the bases is what makes publication safe: readers reach bases
    /// lock-free (dp/dm reads go through the mutex-guarded `Matrix::wait`), so
    /// a pending base in a visible snapshot lets concurrent readers corrupt
    /// GrB state. No-op per matrix when already synced, and it has to run
    /// after the fold, which leaves the base pending.
    pub fn fold_oversized_deltas(&mut self) {
        self.zero_matrix.wait_base();
        self.adjacancy_matrix.fold_oversized();
        self.adjacancy_matrix.wait_base();
        self.node_labels_matrix.fold_oversized();
        self.node_labels_matrix.wait_base();
        self.relationship_type_matrix.fold_oversized();
        self.relationship_type_matrix.wait_base();
        for m in &mut self.labels_matices {
            m.fold_oversized();
            m.wait_base();
        }
        for t in &mut self.relationship_matrices {
            t.fold_oversized();
            t.wait_base();
        }
    }

    /// Materialize all pending GraphBLAS operations on every matrix.
    /// Called from pthread_atfork prepare handler to ensure no internal
    /// GraphBLAS locks are held at fork time.
    pub fn wait_all(&self) {
        self.zero_matrix.wait_all();
        self.adjacancy_matrix.wait_all();
        self.node_labels_matrix.wait_all();
        self.relationship_type_matrix.wait_all();
        for m in &self.labels_matices {
            m.wait_all();
        }
        for t in &self.relationship_matrices {
            t.wait_all();
        }
    }

    /// Returns true if every matrix is fully synced — i.e. `wait_all`
    /// has been called and no writer has since enqueued pending ops.
    /// Used by the post-fork child handler to verify the parent's
    /// pre_fork sync took effect before emitting an RDB.
    #[must_use]
    pub fn is_synced(&self) -> bool {
        self.zero_matrix.is_synced()
            && self.adjacancy_matrix.is_synced()
            && self.node_labels_matrix.is_synced()
            && self.relationship_type_matrix.is_synced()
            && self.labels_matices.iter().all(VersionedMatrix::is_synced)
            && self.relationship_matrices.iter().all(Tensor::is_synced)
    }

    pub fn set_relationships_attributes(
        &mut self,
        attrs: &FxHashMap<u64, Vec<(u16, Value)>>,
        docs: &mut IndexDocs,
    ) -> Result<(usize, usize), String> {
        let index_add_edge_docs = &mut docs.edge_adds;
        // Before the overwrite, while the old values are still readable.
        #[cfg(feature = "index-falkordb")]
        docs.native
            .extend(graph_writes::edge_attrs_set(self, attrs));
        let (nremoved, nset) = self.relationship_attrs.insert_attrs(attrs)?;
        self.track_edge_index_updates(attrs, index_add_edge_docs);
        Ok((nremoved, nset))
    }

    /// As [`Self::set_relationships_attributes`], for edges already known to
    /// share one type.
    ///
    /// The difference is entirely in the index bookkeeping: the general form
    /// calls `get_relationship_type_id` per edge, and that is a
    /// `relationship_type_matrix.iter(id, id)` each time — the per-entity delta
    /// iteration `import_node_attrs` documents as O(accumulated delta). Every
    /// caller that already knows the type should state it.
    ///
    /// The v3 `UPDATE_EDGE` record does, since #2570: its group key is the
    /// relationship type, so one record is one type by construction.
    pub fn set_relationships_attributes_of_type(
        &mut self,
        type_id: TypeId,
        attrs: &FxHashMap<u64, Vec<(u16, Value)>>,
        docs: &mut IndexDocs,
    ) -> Result<(usize, usize), String> {
        let index_add_edge_docs = &mut docs.edge_adds;
        // Before the overwrite, while the old values are still readable.
        #[cfg(feature = "index-falkordb")]
        docs.native
            .extend(graph_writes::edge_attrs_set_of_type(self, type_id, attrs));
        let (nremoved, nset) = self.relationship_attrs.insert_attrs(attrs)?;
        self.track_edge_index_updates_of_type(type_id, attrs, index_add_edge_docs);
        Ok((nremoved, nset))
    }

    #[must_use]
    pub fn is_node_deleted(
        &self,
        id: NodeId,
    ) -> bool {
        self.node_ids.is_free(id.0)
    }

    #[must_use]
    pub fn deleted_nodes_count(&self) -> u64 {
        self.node_ids.recycled_count()
    }

    #[must_use]
    pub const fn deleted_nodes(&self) -> &RoaringTreemap {
        self.node_ids.recycled()
    }

    #[must_use]
    pub fn deleted_relationships_count(&self) -> u64 {
        self.relationship_ids.recycled_count()
    }

    #[must_use]
    pub const fn deleted_relationships(&self) -> &RoaringTreemap {
        self.relationship_ids.recycled()
    }

    #[must_use]
    pub fn label_matrices(&self) -> &[VersionedMatrix<bool>] {
        &self.labels_matices
    }

    #[must_use]
    pub const fn adjacency_matrix(&self) -> &VersionedMatrix<bool> {
        &self.adjacancy_matrix
    }

    #[must_use]
    pub fn relationship_tensors(&self) -> &[Tensor] {
        &self.relationship_matrices
    }

    #[must_use]
    pub fn is_relationship_deleted(
        &self,
        id: RelationshipId,
    ) -> bool {
        self.relationship_ids.is_free(id.0)
    }

    pub fn delete_relationships(
        &mut self,
        rels: &RoaringTreemap,
        docs: &mut IndexDocs,
    ) -> Result<Vec<DeletedEdge>, NodeOpError> {
        let index_remove_edge_docs = &mut docs.edge_removes;
        if rels.is_empty() {
            return Ok(Vec::new());
        }
        let num_types = self.relationship_matrices.len();

        // --- Phase 1: resolve (type, src, dst) per edge without mutating state ---
        // Endpoints come from the graph-wide reverse index (O(1)); the type from
        // a single re-seekable iterator over `relationship_type_matrix`. Walking
        // `rels` (O(deleted)) with per-edge seeks avoids scanning every edge in
        // the [min, max] id range. Only edges that resolve to both endpoints and
        // a type are recorded in `resolved`; stale/non-existent ids are skipped
        // so they can't corrupt counters or bitmaps in phase 2.
        let mut by_type: Vec<Vec<(u64, u64, u64)>> = vec![Vec::new(); num_types];
        let mut resolved = RoaringTreemap::new();
        {
            let min_id = rels.min().expect("rels is non-empty");
            let mut type_iter = self.relationship_type_matrix.iter(min_id, min_id);
            #[allow(clippy::cast_possible_truncation)]
            for edge_id in rels {
                let Some((src, dst)) = self.endpoints_for_edge(edge_id) else {
                    continue;
                };
                type_iter.seek(edge_id, edge_id);
                if let Some((_, type_idx)) = type_iter.next() {
                    by_type[type_idx as usize].push((edge_id, src, dst));
                    resolved.insert(edge_id);
                }
            }
        }

        // --- Phase 2: mutate state for the actually-resolved edges only ---
        // Refused over everything asked for, freed over what resolved. Phase 1
        // does not mutate, so a refusal here still leaves the graph untouched —
        // it has only cost the resolution walk.
        self.relationship_ids
            .release(rels, &resolved)
            .map_err(NodeOpError::relationship)?;

        // After the release, so a refused delete leaves the index untouched too, and before
        // the teardown below, while the attributes and types are still readable.
        #[cfg(feature = "index-falkordb")]
        docs.native
            .extend(graph_writes::edges_deleted(self, &resolved));

        self.relationship_attrs.remove_all(&resolved);

        let mut endpoints: Vec<DeletedEdge> = Vec::with_capacity(resolved.len() as usize);
        // (edge_id, type_id) pairs for a single bulk removal from the type matrix.
        let mut tm_rows: Vec<u64> = Vec::with_capacity(endpoints.capacity());
        let mut tm_cols: Vec<u64> = Vec::with_capacity(endpoints.capacity());
        // (src, dst) pairs emptied from a tensor — candidates for adjacency removal.
        let mut adj_candidates: Vec<(u64, u64)> = Vec::new();

        for (type_idx, type_rels) in by_type.iter().enumerate() {
            if type_rels.is_empty() {
                continue;
            }
            let type_id = type_idx as u64;

            // Stage index document removals for indexed relationship types.
            if self
                .edge_indexer
                .has_index(&self.relationship_types[type_idx])
            {
                let docs = index_remove_edge_docs.entry(type_id).or_default();
                for &(edge_id, src, dst) in type_rels {
                    docs.insert(edge_id, (src, dst));
                }
            }

            for &(edge_id, src, dst) in type_rels {
                tm_rows.push(edge_id);
                tm_cols.push(type_id);
                endpoints.push(DeletedEdge {
                    id: RelationshipId(edge_id),
                    type_id,
                    src: NodeId(src),
                    dst: NodeId(dst),
                });
                self.clear_edge_endpoint(edge_id);
            }

            adj_candidates.extend(self.relationship_matrices[type_idx].remove_all(type_rels));
        }

        // Remove every deleted edge from relationship_type_matrix in one masked op.
        if !tm_rows.is_empty() {
            let mut type_mask =
                Matrix::<bool>::new(self.relationship_cap, self.relationship_types.len() as u64);
            type_mask.build(&tm_rows, &tm_cols);
            self.relationship_type_matrix.remove_mask(&type_mask);
        }

        // Update adjacancy_matrix for pairs that lost all edges.
        if !adj_candidates.is_empty() {
            if num_types > 1 {
                // Multiple types — keep only pairs empty across all tensors.
                adj_candidates.retain(|&(src, dst)| {
                    !self
                        .relationship_matrices
                        .iter()
                        .any(|tensor| tensor.get(src, dst).next().is_some())
                });
            }
            if !adj_candidates.is_empty() {
                let node_cap = self.node_cap;
                let adj_rows: Vec<u64> = adj_candidates.iter().map(|&(src, _)| src).collect();
                let adj_cols: Vec<u64> = adj_candidates.iter().map(|&(_, dst)| dst).collect();
                let mut adj_mask = Matrix::<bool>::new(node_cap, node_cap);
                adj_mask.build(&adj_rows, &adj_cols);
                self.adjacancy_matrix.remove_mask(&adj_mask);
            }
        }

        Ok(endpoints)
    }

    ///
    /// Instead of discovering edges per-node during the delete operator, this
    /// method iterates each tensor once for all deleted nodes and batch-removes
    /// the edges. Edges already in `explicit_rels` are skipped (they're handled
    /// by `delete_relationships`).
    ///
    /// Every pair that loses its last edge is cleared from the adjacency
    /// matrix, including pairs whose endpoints are both deleted: node ids are
    /// recycled from `deleted_nodes`, so a bit left behind is not unreachable,
    /// it describes an edge between whichever nodes take the ids next (#2771).
    /// Returns the list of implicitly deleted edges as `(edge_id, src, dst)`
    /// so the caller can record them for effects/replication.
    pub fn delete_implicit_edges(
        &mut self,
        deleted_nodes: &RoaringTreemap,
        explicit_rels: &RoaringTreemap,
        docs: &mut IndexDocs,
    ) -> Result<Vec<DeletedEdge>, String> {
        let index_remove_edge_docs = &mut docs.edge_removes;
        if self.relationship_matrices.is_empty() {
            return Ok(Vec::new());
        }

        let mut all_implicit: Vec<DeletedEdge> = Vec::new();
        // Pairs where an endpoint survives — the survivor may still hold an
        // edge of another type, so these need a per-tensor check.
        let mut check_adj_pairs: std::collections::HashSet<(u64, u64)> =
            std::collections::HashSet::default();
        // Pairs where both endpoints are deleted — known non-adjacent, no
        // check needed. `Tensor::remove_all` yields each pair at most once, so
        // a duplicate here means two relationship types connected the same
        // pair; the bulk `build` below collapses those, so they are left in.
        let mut dead_adj_pairs: Vec<(u64, u64)> = Vec::new();

        for type_idx in 0..self.relationship_matrices.len() {
            let mut rels: Vec<(u64, u64, u64)> = Vec::new();

            // Collect all edges for deleted nodes from this tensor.
            //
            // One iterator pair for the whole type, re-seeked per node, rather
            // than a fresh pair per node: building one allocates a
            // `GxB_Iterator` per layer and waits the tensor, so per-node
            // construction cost scales with the deleted set and the number of
            // relationship types while having nothing to do with how many edges
            // those nodes actually have. Deleting a million edgeless nodes over
            // six types built twelve million iterators to yield nothing.
            {
                let tensor = &self.relationship_matrices[type_idx];
                let mut outgoing = tensor.iter(0, 0, false);
                let mut incoming = tensor.iter(0, 0, true);
                for node_id in deleted_nodes {
                    outgoing.seek(node_id, node_id);
                    for (src, dst, edge_id) in &mut outgoing {
                        if !explicit_rels.contains(edge_id) {
                            rels.push((edge_id, src, dst));
                        }
                    }
                    // Incoming edges — skip if source is also a deleted node
                    // (those edges are already collected from the source's
                    // outgoing iteration), and skip self-loops already found above.
                    incoming.seek(node_id, node_id);
                    for (src, dst, edge_id) in &mut incoming {
                        if src != node_id
                            && !deleted_nodes.contains(src)
                            && !explicit_rels.contains(edge_id)
                        {
                            rels.push((edge_id, src, dst));
                        }
                    }
                }
            }

            if rels.is_empty() {
                continue;
            }

            // Batch remove from relationship_type_matrix using bulk mask
            let type_id = type_idx as u64;
            let tm_rows: Vec<u64> = rels.iter().map(|&(id, _, _)| id).collect();
            let tm_cols: Vec<u64> = vec![type_id; rels.len()];
            let mut type_mask =
                Matrix::<bool>::new(self.relationship_cap, self.relationship_types.len() as u64);
            type_mask.build(&tm_rows, &tm_cols);

            let del_keys: RoaringTreemap = rels.iter().map(|&(id, _, _)| id).collect();
            let type_name = &self.relationship_types[type_idx];
            let is_indexed = self.edge_indexer.has_index(type_name);
            for &(edge_id, src, dst) in &rels {
                all_implicit.push(DeletedEdge {
                    id: RelationshipId(edge_id),
                    type_id,
                    src: NodeId(src),
                    dst: NodeId(dst),
                });

                // Stage an edge-index document removal so cascade
                // deletes don't leave stale index hits on the next
                // query. Matches `delete_relationships`' handling.
                if is_indexed {
                    index_remove_edge_docs
                        .entry(type_id)
                        .or_default()
                        .insert(edge_id, (src, dst));
                }
            }
            // Before the type matrix and attributes are torn down below.
            #[cfg(feature = "index-falkordb")]
            docs.native
                .extend(graph_writes::edges_deleted(self, del_keys.iter()));
            self.relationship_type_matrix.remove_mask(&type_mask);
            self.relationship_attrs.remove_all(&del_keys);

            // Drop deleted edges from the graph-wide reverse index.
            for &(edge_id, _, _) in &rels {
                self.clear_edge_endpoint(edge_id);
            }

            // Batch-remove from tensor — remove_all uses bulk mask operations
            let emptied = self.relationship_matrices[type_idx].remove_all(&rels);
            for (src, dst) in emptied {
                // Both endpoints are being deleted, so no edge between them
                // can survive the commit: every edge incident to a deleted
                // node is either collected above or sits in `explicit_rels`,
                // which `delete_relationships` removes later in this same
                // commit. Clearing the pair is therefore unconditionally
                // right, and skipping the tensor probe below is not merely an
                // optimisation — running ahead of `delete_relationships`, that
                // probe would still find an explicitly-deleted edge of another
                // type between this pair and conclude it is adjacent, leaving
                // the clear to be redone by that later pass.
                if deleted_nodes.contains(src) && deleted_nodes.contains(dst) {
                    dead_adj_pairs.push((src, dst));
                } else {
                    check_adj_pairs.insert((src, dst));
                }
            }
        }

        // Discovered from this graph's own tensors rather than named by a
        // caller, so the refusals cannot fire here — which is why they are asked
        // anyway. An implicit edge that is already free, or that sits above the
        // entry boundary without this batch having created it, is this graph
        // disagreeing with itself.
        //
        // Asked after the tensors, attributes and reverse index have already
        // been mutated, which looks like it would leave a half-deleted graph
        // behind. It cannot: `self` is the private MVCC version, the only
        // caller propagates this error out through `Pending::commit`, and a
        // write query that returns an error never reaches `commit` — the fork
        // is dropped with the damage inside it. Unwinding by hand would mean
        // resolving every implicit edge in a read-only pass first, which buys
        // nothing over the rollback that already exists.
        // The ids as one set, so the count and the free set cannot be written
        // from two different sets — they were, and agreed only because an edge
        // has exactly one type.
        let freed: RoaringTreemap = all_implicit.iter().map(|e| u64::from(e.id)).collect();
        self.relationship_ids
            .release(&freed, &freed)
            .map_err(|e| e.to_string())?;

        // Clear adjacency for every pair that lost its last edge, in one bulk
        // `build` rather than a `setElement` per pair — matching what
        // `delete_relationships` does. Both halves feed the same coordinate
        // lists so a mass `DETACH DELETE` crosses the FFI boundary once, and
        // `GxB_Matrix_build_Scalar` yields an iso mask (one shared value, not
        // a byte per entry) that repeated `set` calls would not. It also
        // collapses duplicate coordinates itself, so the cross-type repeats in
        // `dead_adj_pairs` need no separate dedup pass — sorting them here
        // would only re-do work the build has to do anyway.
        let mut adj_rows: Vec<u64> =
            Vec::with_capacity(dead_adj_pairs.len() + check_adj_pairs.len());
        let mut adj_cols: Vec<u64> = Vec::with_capacity(adj_rows.capacity());
        for (src, dst) in dead_adj_pairs {
            adj_rows.push(src);
            adj_cols.push(dst);
        }
        for (src, dst) in check_adj_pairs {
            let has_edges = self
                .relationship_matrices
                .iter()
                .any(|tensor| tensor.get(src, dst).next().is_some());
            if !has_edges {
                adj_rows.push(src);
                adj_cols.push(dst);
            }
        }
        if !adj_rows.is_empty() {
            let mut adj_mask = Matrix::<bool>::new(self.node_cap, self.node_cap);
            adj_mask.build(&adj_rows, &adj_cols);
            self.adjacancy_matrix.remove_mask(&adj_mask);
        }

        Ok(all_implicit)
    }

    pub fn get_src_dest_relationships(
        &self,
        src: NodeId,
        dest: NodeId,
        types: &[Arc<String>],
    ) -> impl Iterator<Item = RelationshipId> + use<> {
        let iters: Vec<_> = if types.is_empty() {
            &self.relationship_types
        } else {
            types
        }
        .iter()
        .filter_map(|relationship_type| self.get_relationship_matrix(relationship_type))
        .map(|relationship_matrix| relationship_matrix.get(src.0, dest.0))
        .collect();

        iters.into_iter().flat_map(|iter| iter.map(RelationshipId))
    }

    /// Build a relationship matrix summing only the given types (no
    /// source/destination label restriction). Returns `None` when `types` is
    /// non-empty but none of the types exist in the schema (caller should
    /// short-circuit to an empty result).
    #[must_use]
    pub fn build_relationship_matrix_unrestricted(
        &self,
        types: &[Arc<String>],
    ) -> Option<Matrix<bool>> {
        let matrices = types
            .iter()
            .filter_map(|relationship_type| self.get_relationship_matrix(relationship_type))
            .collect::<Vec<_>>();
        if !types.is_empty() && matrices.is_empty() {
            return None;
        }
        let mut iter = matrices.into_iter();
        let mut m = iter.next().map_or_else(
            || self.adjacancy_matrix.extract(),
            super::graphblas::tensor::Tensor::extract,
        );
        for relationship_matrix in iter {
            // The raw fwd layers may hold pending work; set_pattern's GrB ops
            // would finish it internally, racing other readers on the shared
            // handles. No-op when already synced.
            relationship_matrix.wait_fwd();
            m.set_pattern(
                Some(relationship_matrix.fwd_dm()),
                relationship_matrix.fwd_m(),
                Some(Descriptor::C),
            );
            m.set_pattern(None, relationship_matrix.fwd_dp(), None);
        }
        Some(m)
    }

    /// Resolve a set of label names to ids. Returns `None` if any label is not
    /// in the schema (which means no node could match).
    #[must_use]
    pub fn resolve_label_ids(
        &self,
        labels: &OrderSet<Arc<String>>,
    ) -> Option<Vec<LabelId>> {
        labels.iter().map(|l| self.get_label_id(l)).collect()
    }

    /// Build a relationship matrix combining the given types and filtering by
    /// source/destination labels.
    #[must_use]
    pub fn build_relationship_matrix(
        &self,
        types: &[Arc<String>],
        src_labels: &OrderSet<Arc<String>>,
        dest_labels: &OrderSet<Arc<String>>,
    ) -> Matrix<bool> {
        let matrices = types
            .iter()
            .filter_map(|relationship_type| self.get_relationship_matrix(relationship_type))
            .collect::<Vec<_>>();
        let src_labels_matrices = src_labels
            .iter()
            .map(|label| self.get_label_matrix(label))
            .collect::<Option<Vec<_>>>();
        let dest_labels_matrices = dest_labels
            .iter()
            .map(|label| self.get_label_matrix(label))
            .collect::<Option<Vec<_>>>();
        let no_match = (!types.is_empty() && matrices.is_empty())
            || src_labels_matrices.is_none()
            || dest_labels_matrices.is_none();

        let src_labels_matrices = src_labels_matrices.unwrap_or_default();
        let dest_labels_matrices = dest_labels_matrices.unwrap_or_default();

        if no_match {
            self.zero_matrix.extract()
        } else {
            let mut iter = matrices.into_iter();
            let mut m = iter.next().map_or_else(
                || self.adjacancy_matrix.extract(),
                super::graphblas::tensor::Tensor::extract,
            );
            for relationship_matrix in iter {
                m.element_wise_add(None, None, Some(&relationship_matrix.extract()), None);
            }

            if !src_labels_matrices.is_empty() {
                let mut iter = src_labels_matrices.iter();
                let mut src_matrix = iter.next().unwrap().extract();
                for label_matrix in iter {
                    src_matrix.element_wise_multiply(
                        None,
                        None,
                        Some(&label_matrix.extract()),
                        None,
                    );
                }
                m.rmxm(&src_matrix);
            }
            if !dest_labels_matrices.is_empty() {
                let mut iter = dest_labels_matrices.iter();
                let mut dest_matrix = iter.next().unwrap().extract();
                for label_matrix in iter {
                    dest_matrix.element_wise_multiply(
                        None,
                        None,
                        Some(&label_matrix.extract()),
                        None,
                    );
                }
                m.lmxm(&dest_matrix);
            }
            m
        }
    }

    /// Convenience wrapper: build the matrix and iterate it in one call.
    pub fn get_relationships(
        &self,
        types: &[Arc<String>],
        src_labels: &OrderSet<Arc<String>>,
        dest_labels: &OrderSet<Arc<String>>,
        from_id: Option<NodeId>,
        to_id: Option<NodeId>,
    ) -> impl Iterator<Item = (NodeId, NodeId)> + use<> {
        let m = self.build_relationship_matrix(types, src_labels, dest_labels);
        let (min_row, max_row) = from_id.map_or((0, u64::MAX), |id| (id.0, id.0));
        m.iter(min_row, max_row)
            .filter(move |(_, dest)| to_id.is_none() || to_id.unwrap().0 == *dest)
            .map(|(src, dest)| (NodeId(src), NodeId(dest)))
    }

    #[must_use]
    pub fn get_relationship_type_id(
        &self,
        id: RelationshipId,
    ) -> TypeId {
        #[allow(clippy::cast_possible_truncation)]
        self.relationship_type_matrix
            .iter(id.0, id.0)
            .map(|(_, l)| TypeId(l as usize))
            .next()
            .expect("relationship must have a type in type_matrix")
    }

    /// Decode the (src, dst) endpoints for an edge from the graph-wide reverse
    /// index. `None` if the edge does not exist — the fallible counterpart of
    /// [`Self::get_relationship_endpoints`], which panics.
    #[must_use]
    pub fn endpoints_for_edge(
        &self,
        edge_id: u64,
    ) -> Option<(u64, u64)> {
        self.edge_endpoints.get(edge_id)
    }

    /// Clear an edge's endpoint slot in the reverse index (on deletion).
    /// Leaves the slot as a tombstone; the vector never shrinks.
    fn clear_edge_endpoint(
        &mut self,
        edge_id: u64,
    ) {
        Arc::make_mut(&mut self.edge_endpoints).clear(edge_id);
    }

    /// Returns (src, dst) for an edge via the maintained reverse index.
    #[must_use]
    pub fn get_relationship_endpoints(
        &self,
        id: RelationshipId,
    ) -> (NodeId, NodeId) {
        if let Some((src, dst)) = self.endpoints_for_edge(id.0) {
            return (NodeId(src), NodeId(dst));
        }

        panic!("relationship {} not found", id.0);
    }

    /// Iterate the relationship type matrix over a range of edge IDs.
    /// Returns `(edge_id, type_index)` pairs.
    #[must_use]
    pub fn relationship_type_matrix_iter(
        &self,
        min_edge_id: u64,
        max_edge_id: u64,
    ) -> versioned_matrix::Iter {
        self.relationship_type_matrix.iter(min_edge_id, max_edge_id)
    }

    #[must_use]
    pub fn get_relationship_attribute(
        &self,
        id: RelationshipId,
        attr: &Arc<String>,
    ) -> Option<Value> {
        self.attr_by_name(&self.relationship_attrs, id.0, attr)
    }

    /// Fetches a relationship attribute using a pre-resolved attribute
    /// index. Use `get_relationship_attribute_id` to resolve the index
    /// once, then call this per relationship to avoid repeated string
    /// lookups.
    #[must_use]
    pub fn get_relationship_attribute_by_idx(
        &self,
        id: RelationshipId,
        attr_idx: u16,
    ) -> Option<Value> {
        self.relationship_attrs.get_attr_by_idx(id.0, attr_idx)
    }

    /// Borrow the relationship attribute store directly.
    ///
    /// Lets a caller hand a GraphBLAS user-defined operator a minimal, read-only
    /// handle to just the relationship weights (see `algo.MSF`'s weight operator)
    /// rather than a raw pointer to the whole graph.
    #[must_use]
    pub const fn relationship_attrs(&self) -> &AttributeStore {
        &self.relationship_attrs
    }

    /// Batch variant of `get_relationship_attribute_by_idx`.
    /// Pushes one `Value` per id into `out`, substituting `default` for
    /// missing entries (so callers don't allocate a temp `Vec<Option<_>>`).
    pub fn get_relationship_attributes_by_idx(
        &self,
        ids: &[RelationshipId],
        attr_idx: u16,
        default: &Value,
        out: &mut Vec<Value>,
    ) {
        // SAFETY: RelationshipId is `#[repr(transparent)]` over u64.
        let keys: &[u64] = unsafe { std::slice::from_raw_parts(ids.as_ptr().cast(), ids.len()) };
        self.relationship_attrs
            .get_attrs_by_idx_batch_into(keys, attr_idx, default, out);
    }

    fn resize_node_matrices(&mut self) {
        self.adjacancy_matrix.resize(self.node_cap, self.node_cap);
        self.node_labels_matrix
            .resize(self.node_cap, self.labels_matices.len() as u64);
        for label_matrix in &mut self.labels_matices {
            label_matrix.resize(self.node_cap, self.node_cap);
        }
        for relationship_matrix in &mut self.relationship_matrices {
            relationship_matrix.resize(self.node_cap, self.node_cap);
        }
    }

    fn resize_relationship_matrices(&mut self) {
        self.relationship_type_matrix
            .resize(self.relationship_cap, self.relationship_types.len() as u64);
    }

    fn resize(&mut self) {
        if self.node_ids.live() > self.node_cap {
            self.node_cap = grow_cap(self.node_cap, self.node_ids.live());
            self.resize_node_matrices();
        }

        if self.labels_matices.len() as u64 > self.node_labels_matrix.ncols() {
            self.node_labels_matrix
                .resize(self.node_cap, self.labels_matices.len() as u64);
        }

        if self.relationship_ids.live() > self.relationship_cap {
            self.relationship_cap = grow_cap(self.relationship_cap, self.relationship_ids.live());
            self.resize_relationship_matrices();
        }

        if self.relationship_types.len() as u64 > self.relationship_type_matrix.ncols() {
            self.relationship_type_matrix
                .resize(self.relationship_cap, self.relationship_types.len() as u64);
        }
    }

    // ---- attribute name resolution ----------------------------------------
    //
    // `AttributeStore` is an id-keyed structure and does not own the name table;
    // the graph does. These three resolve between the two, so the store's API stays
    // honest about what it can answer on its own and no caller has to pass the
    // graph's dictionary back into it.

    /// Value of a named attribute on an entity in `store`.
    fn attr_by_name(
        &self,
        store: &AttributeStore,
        key: u64,
        attr: &Arc<String>,
    ) -> Option<Value> {
        let idx = self.attrs_name.get_index_of(attr)? as u16;
        store.get_attr_by_idx(key, idx)
    }

    /// Names of the attributes an entity in `store` carries.
    fn attr_names<'a>(
        &'a self,
        store: &'a AttributeStore,
        key: u64,
    ) -> impl Iterator<Item = Arc<String>> + 'a {
        store
            .get_attr_ids(key)
            .filter_map(move |id| self.attrs_name.get(id as usize).cloned())
    }

    /// Name/value pairs for an entity in `store`, in one storage pass.
    fn attr_pairs<'a>(
        &'a self,
        store: &'a AttributeStore,
        key: u64,
    ) -> impl Iterator<Item = (Arc<String>, Value)> + 'a {
        store
            .get_all_attrs_by_id(key)
            .filter_map(move |(id, value)| {
                self.attrs_name.get(id as usize).map(|n| (n.clone(), value))
            })
    }

    pub fn get_node_attrs(
        &self,
        id: NodeId,
    ) -> impl Iterator<Item = Arc<String>> + '_ {
        self.attr_names(&self.node_attrs, id.0)
    }

    /// Get all attribute names and values for a node in a single storage pass.
    pub fn get_node_all_attrs(
        &self,
        id: NodeId,
    ) -> impl Iterator<Item = (Arc<String>, Value)> + '_ {
        self.attr_pairs(&self.node_attrs, id.0)
    }

    pub fn get_node_all_attrs_by_id(
        &self,
        id: NodeId,
    ) -> impl Iterator<Item = (u16, Value)> + '_ {
        self.node_attrs.get_all_attrs_by_id(id.0)
    }

    /// Number of attributes stored for a node (0 if none).
    #[must_use]
    pub fn get_node_attr_count(
        &self,
        id: NodeId,
    ) -> usize {
        self.node_attrs.attr_count(id.0)
    }

    pub fn get_relationship_attrs(
        &self,
        id: RelationshipId,
    ) -> impl Iterator<Item = Arc<String>> + '_ {
        self.attr_names(&self.relationship_attrs, id.0)
    }

    /// Get all attribute names and values for a relationship in a single storage pass.
    pub fn get_relationship_all_attrs(
        &self,
        id: RelationshipId,
    ) -> impl Iterator<Item = (Arc<String>, Value)> + '_ {
        self.attr_pairs(&self.relationship_attrs, id.0)
    }

    pub fn get_relationship_all_attrs_by_id(
        &self,
        id: RelationshipId,
    ) -> impl Iterator<Item = (u16, Value)> + '_ {
        self.relationship_attrs.get_all_attrs_by_id(id.0)
    }

    /// Number of attributes stored for a relationship (0 if none).
    #[must_use]
    pub fn get_relationship_attr_count(
        &self,
        id: RelationshipId,
    ) -> usize {
        self.relationship_attrs.attr_count(id.0)
    }

    pub fn create_index(
        &mut self,
        index_type: &IndexType,
        entity_type: &EntityType,
        label: &Arc<String>,
        attrs: &Vec<Arc<String>>,
        options: Option<IndexOptions>,
    ) -> Result<(), String> {
        match entity_type {
            EntityType::Node => {
                let len = self.get_label_matrix_mut(label).nvals();
                self.node_indexer
                    .create_index(index_type, label, attrs, len, options)?;
                // Register attribute names so they appear in
                // db.propertyKeys() even if no entity yet uses them.
                for attr in attrs {
                    self.add_node_attribute_name(attr);
                }
                populate_index(IndexKind::Node, label.clone(), self.node_indexer.clone());
            }
            EntityType::Relationship => {
                // get-or-create the relationship type so that
                // db.relationshipTypes() reflects indexed (but still
                // empty) types.
                let len = self.get_relationship_matrix_mut(label).edge_count();
                self.edge_indexer
                    .create_index(index_type, label, attrs, len, options)?;
                for attr in attrs {
                    self.add_rel_attribute_name(attr);
                }
                populate_index(IndexKind::Edge, label.clone(), self.edge_indexer.clone());
            }
        }
        #[cfg(feature = "index-falkordb")]
        graph_writes::create_index(self, index_type, *entity_type, label, attrs);
        Ok(())
    }

    /// Create an index and populate it synchronously (for RDB load).
    /// Unlike `create_index`, this doesn't spawn async tasks.
    ///
    /// **The caller must reach `populate_indexes_sync` before publishing this version.** This
    /// leaves the native column created but *empty*, and an empty column is indistinguishable
    /// from one that legitimately matches nothing — a query reaching it would return no rows
    /// rather than falling back. The only caller, `rebuild_indexes` in the RDB decoder, pairs
    /// the two before the graph is published, so no reader can observe the gap; a new caller
    /// that skips the populate would silently serve empty results.
    pub fn create_index_sync(
        &mut self,
        index_type: &IndexType,
        entity_type: &EntityType,
        label: &Arc<String>,
        attrs: &Vec<Arc<String>>,
        options: Option<IndexOptions>,
    ) -> Result<(), String> {
        match entity_type {
            EntityType::Node => {
                let len = self.get_label_matrix_mut(label).nvals();
                self.node_indexer
                    .create_index(index_type, label, attrs, len, options)?;
                // Same bookkeeping as `create_index`: surface the
                // indexed attr names in `db.propertyKeys()` even if no
                // entity has yet written to them. Critical for
                // RDB-load and EFFECT_CREATE_INDEX (replica) paths,
                // which go through this sync variant.
                for attr in attrs {
                    self.add_node_attribute_name(attr);
                }
                // Don't spawn async — caller will populate via populate_index_sync
            }
            EntityType::Relationship => {
                // get-or-create the relationship type so
                // `db.relationshipTypes()` reflects indexed (but still
                // empty) types even on replicas / after RDB load.
                let len = self.get_relationship_matrix_mut(label).edge_count();
                self.edge_indexer
                    .create_index(index_type, label, attrs, len, options)?;
                for attr in attrs {
                    self.add_rel_attribute_name(attr);
                }
            }
        }
        // The native columns start empty too; `populate_indexes_sync` builds them.
        #[cfg(feature = "index-falkordb")]
        self.falkordb_index
            .create_unpopulated(index_type, *entity_type, label, attrs);
        Ok(())
    }

    /// Synchronously populate all pending indexes.
    /// Used after RDB load when the graph is fully constructed.
    pub fn populate_indexes_sync(&mut self) {
        let node_snapshots = self.node_indexer.acquire_population_snapshots();
        for snapshot in node_snapshots {
            let label = snapshot.ticket.label().clone();
            let attrs = snapshot.fields;
            if let Some(lm) = self.get_label_matrix(&label) {
                // Pre-resolve attribute indices to avoid string lookups per node
                let resolved_attrs: Vec<(u16, Vec<_>)> = attrs
                    .iter()
                    .filter_map(|(attr, fields)| {
                        self.get_node_attribute_id(attr)
                            .map(|idx| (idx as u16, fields.clone()))
                    })
                    .collect();

                let mut batch = Vec::new();
                for (n, _) in lm.iter(0, u64::MAX) {
                    // Allocate the RSDoc only once a field is present — nodes
                    // without an indexed attribute produce no document (and no
                    // create+free churn).
                    let mut doc: Option<Document> = None;
                    for (attr_idx, fields) in &resolved_attrs {
                        if let Some(value) = self.get_node_attribute_by_idx(NodeId(n), *attr_idx) {
                            let doc = doc.get_or_insert_with(|| Document::new(n));
                            for field in fields {
                                doc.set(field, &value);
                            }
                        }
                    }
                    if let Some(doc) = doc {
                        batch.push(doc);
                    }
                }
                if !batch.is_empty() {
                    let mut add_docs = HashMap::new();
                    add_docs.insert(label.clone(), batch);
                    self.node_indexer.commit(&mut add_docs, &mut HashMap::new());
                }
            }
            self.node_indexer
                .release_population_ticket(&snapshot.ticket);
            #[cfg(feature = "index-falkordb")]
            graph_writes::populate(self, EntityType::Node, &label, &attrs);
        }

        // Edge indexes: symmetric to the node path, but walk the
        // relationship tensor and emit `Document::new_edge(src, dst, eid)`
        // so RediSearch keys stay the 24-byte `[src, dst, edge_id]`
        // triple that `Index_RemoveEdge` expects on delete. Stream
        // the tensor iterator directly so we don't materialize every
        // `(src, dst, eid)` triple for large relationship types on
        // RDB load.
        let edge_snapshots = self.edge_indexer.acquire_population_snapshots();
        for snapshot in edge_snapshots {
            let type_name = snapshot.ticket.label().clone();
            let attrs = snapshot.fields;
            if let Some(tensor) = self.get_relationship_matrix(&type_name) {
                let mut batch = Vec::new();
                for (src, dst, eid) in tensor.iter(0, u64::MAX, false) {
                    // Allocate the RSDoc only once a field is present — edges
                    // without an indexed attribute produce no document (and no
                    // create+free churn).
                    let mut doc: Option<Document> = None;
                    for (attr, fields) in &attrs {
                        if let Some(value) = self.attr_by_name(&self.relationship_attrs, eid, attr)
                        {
                            let doc = doc.get_or_insert_with(|| Document::new_edge(src, dst, eid));
                            for field in fields {
                                doc.set(field, &value);
                            }
                        }
                    }
                    if let Some(doc) = doc {
                        batch.push(doc);
                    }
                }
                if !batch.is_empty() {
                    let mut add_docs = HashMap::new();
                    add_docs.insert(type_name.clone(), batch);
                    self.edge_indexer.commit(&mut add_docs, &mut HashMap::new());
                }
            }
            self.edge_indexer
                .release_population_ticket(&snapshot.ticket);
            #[cfg(feature = "index-falkordb")]
            graph_writes::populate(self, EntityType::Relationship, &type_name, &attrs);
        }
    }

    /// The indexer serialization locks, cloned so a caller can take them **before**
    /// borrowing the graph.
    ///
    /// That is the order `populate_index_batch` uses (indexer lock held across its
    /// graph borrow), so anything that needs a *mutable* borrow of the same version —
    /// the index undo path — must take these first or the two collide, which
    /// `AtomicRefCell` reports by panicking.
    #[must_use]
    pub fn index_locks(&self) -> (Arc<Mutex<()>>, Arc<Mutex<()>>) {
        (
            self.node_indexer.write_lock(),
            self.edge_indexer.write_lock(),
        )
    }

    /// Apply a unit of work's staged native-index changes (`docs.native`) to this version's index.
    /// A no-op without the `index-falkordb` feature, which has no native index. `self` must be the
    /// private version the changes were staged against.
    pub fn apply_index_writes(
        &mut self,
        docs: &mut IndexDocs,
    ) {
        #[cfg(feature = "index-falkordb")]
        self.falkordb_index.apply(&mut docs.native);
        #[cfg(not(feature = "index-falkordb"))]
        let _ = docs;
    }

    /// Commit a unit of work's index changes into this version: the native index's staged changes,
    /// then RediSearch's node and edge documents. For an owner that publishes both at one point:
    /// the replica at the end of an effects buffer, `GRAPH.BULK` once every token has succeeded.
    /// A Cypher query applies the native part at the end of each `Commit`
    /// ([`Self::apply_index_writes`]) and publishes RediSearch's later.
    ///
    /// A kind with no documents is skipped before its indexer lock is taken.
    pub fn commit_index_docs(
        &mut self,
        docs: &mut IndexDocs,
    ) {
        self.apply_index_writes(docs);
        if !docs.node_adds.is_empty() || !docs.node_removes.is_empty() {
            self.commit_index(&mut docs.node_adds, &mut docs.node_removes);
        }
        if !docs.edge_adds.is_empty() || !docs.edge_removes.is_empty() {
            self.commit_edge_index(&mut docs.edge_adds, &mut docs.edge_removes);
        }
    }

    /// Write node index documents to RediSearch, taking the node indexer lock.
    pub fn commit_index(
        &mut self,
        index_add_docs: &mut FxHashMap<u64, RoaringTreemap>,
        remove_docs: &mut FxHashMap<u64, RoaringTreemap>,
    ) {
        let lock = self.node_indexer.write_lock();
        let guard = lock.lock();
        self.commit_index_kind(&guard, IndexKind::Node, index_add_docs, remove_docs);
    }

    /// As [`Self::commit_index`], for a caller that already holds the node indexer
    /// lock from [`Self::index_locks`] — which it must, to have borrowed the graph in
    /// the sanctioned order.
    pub fn commit_index_locked(
        &mut self,
        guard: &MutexGuard<'_, ()>,
        index_add_docs: &mut FxHashMap<u64, RoaringTreemap>,
        remove_docs: &mut FxHashMap<u64, RoaringTreemap>,
    ) {
        self.commit_index_kind(guard, IndexKind::Node, index_add_docs, remove_docs);
    }

    /// Write edge index documents to RediSearch, taking the edge indexer lock.
    pub fn commit_edge_index(
        &mut self,
        index_add_edge_docs: &mut FxHashMap<u64, RoaringTreemap>,
        remove_edge_docs: &mut FxHashMap<u64, FxHashMap<u64, (u64, u64)>>,
    ) {
        let lock = self.edge_indexer.write_lock();
        let guard = lock.lock();
        self.commit_edge_index_locked(&guard, index_add_edge_docs, remove_edge_docs);
    }

    /// As [`Self::commit_edge_index`], for a caller already holding the edge indexer
    /// lock from [`Self::index_locks`].
    pub fn commit_edge_index_locked(
        &mut self,
        _guard: &MutexGuard<'_, ()>,
        index_add_edge_docs: &mut FxHashMap<u64, RoaringTreemap>,
        remove_edge_docs: &mut FxHashMap<u64, FxHashMap<u64, (u64, u64)>>,
    ) {
        if index_add_edge_docs.is_empty() && remove_edge_docs.is_empty() {
            return;
        }

        let indexer = &self.edge_indexer;

        let mut add_docs: HashMap<Arc<String>, Vec<Document>> = HashMap::new();
        for (type_id, ids) in index_add_edge_docs.drain() {
            let name = &self.relationship_types[type_id as usize];
            let fields = indexer.get_fields(name);

            // Resolve `(src, dst)` only for the edge ids we actually
            // need, instead of materializing the full tensor every
            // commit. With N ids out of M tensor entries we stop the
            // scan as soon as all N are found. Edges being indexed
            // are expected to still be live in the tensor (deletes
            // go through the remove path), so any id left in
            // `pending` after the scan is treated the same as before
            // — skipped below.
            let mut pending: FxHashSet<u64> = ids.iter().collect();
            let mut endpoints: FxHashMap<u64, (u64, u64)> =
                FxHashMap::with_capacity_and_hasher(ids.len() as usize, FxBuildHasher);
            if let Some(t) = self.relationship_matrices.get(type_id as usize) {
                for (src, dst, eid) in t.iter(0, u64::MAX, false) {
                    if pending.remove(&eid) {
                        endpoints.insert(eid, (src, dst));
                        if pending.is_empty() {
                            break;
                        }
                    }
                }
            }

            let mut docs = Vec::with_capacity(ids.len() as usize);
            for id in ids {
                let Some(&(src, dst)) = endpoints.get(&id) else {
                    // Edge vanished between track time and commit;
                    // nothing to index.
                    continue;
                };
                let mut doc = Document::new_edge(src, dst, id);
                for (key, fields) in &fields {
                    if let Some(value) = self.attr_by_name(&self.relationship_attrs, id, key) {
                        for field in fields {
                            doc.set(field, &value);
                        }
                    }
                }
                docs.push(doc);
            }
            add_docs.insert(name.clone(), docs);
        }

        // Removes: (src, dst) captured at delete time lets us
        // reconstruct the 24-byte `[src, dst, edge_id]` RediSearch key
        // — matches FalkorDB C's `Index_RemoveEdge` in
        // `src/index/index_edge.c`.
        let mut remove: HashMap<Arc<String>, HashMap<u64, (u64, u64)>> = HashMap::new();
        for (type_id, edges) in remove_edge_docs.drain() {
            let name = &self.relationship_types[type_id as usize];
            remove.insert(name.clone(), edges.into_iter().collect());
        }

        indexer.commit_edge(&mut add_docs, &mut remove);
    }

    /// Shared body for `commit_index` / `commit_edge_index`: resolve the
    /// id sets (keyed by label or type id) into `Document`s against the
    /// matching attribute store, then hand them to the underlying
    /// `Indexer::commit`.
    fn commit_index_kind(
        &mut self,
        _guard: &MutexGuard<'_, ()>,
        kind: IndexKind,
        index_add_docs: &mut FxHashMap<u64, RoaringTreemap>,
        remove_docs: &mut FxHashMap<u64, RoaringTreemap>,
    ) {
        if index_add_docs.is_empty() && remove_docs.is_empty() {
            return;
        }

        // Measurement gate, not a shipping mode: see `index_only_writes`. The native index
        // was already maintained by the write hooks, so only the redundant RediSearch feed is
        // dropped.
        #[cfg(feature = "index-falkordb")]
        if matches!(kind, IndexKind::Node) && index_only_writes() {
            index_add_docs.clear();
            remove_docs.clear();
            return;
        }

        let (indexer, names, attr_store) = match kind {
            IndexKind::Node => (&self.node_indexer, &self.node_labels, &self.node_attrs),
            IndexKind::Edge => unreachable!("use commit_edge_index for edges"),
        };

        let mut add_docs = HashMap::new();
        for (slot, ids) in index_add_docs.drain() {
            let name = &names[slot as usize];
            let fields = indexer.get_fields(name);
            let mut docs = vec![];
            for id in ids {
                let mut doc = Document::new(id);
                for (key, fields) in &fields {
                    if let Some(value) = self.attr_by_name(attr_store, id, key) {
                        for field in fields {
                            doc.set(field, &value);
                        }
                    }
                }
                docs.push(doc);
            }
            add_docs.insert(name.clone(), docs);
        }

        let mut remove = HashMap::new();
        for (slot, ids) in remove_docs.drain() {
            let name = &names[slot as usize];
            remove.insert(name.clone(), ids);
        }

        indexer.commit(&mut add_docs, &mut remove);
    }

    pub fn drop_index(
        &mut self,
        index_type: &IndexType,
        entity_type: &EntityType,
        label: &Arc<String>,
        attrs: &[Arc<String>],
    ) -> Result<usize, String> {
        // Expand an empty `attrs` to the full set of fields of `index_type`
        // (matches the `target_attrs` derivation in `Indexer::drop_index`);
        // otherwise an empty-attr drop would bypass constraint protection.
        let indexer = match entity_type {
            EntityType::Node => &self.node_indexer,
            EntityType::Relationship => &self.edge_indexer,
        };
        let effective_attrs: Vec<Arc<String>> = if attrs.is_empty() {
            indexer
                .get_fields(label)
                .into_iter()
                .filter(|(_, fields)| fields.iter().any(|f| f.ty == *index_type))
                .map(|(attr, _)| attr)
                .collect()
        } else {
            attrs.to_vec()
        };

        // Check if any UNIQUE constraint depends on this index
        for attr in &effective_attrs {
            if self.constraint_depends_on_index(entity_type, label, attr, index_type) {
                return Err("Index supports constraint".to_string());
            }
        }

        let (indexer, total, kind) = match entity_type {
            EntityType::Node => {
                let total = self.get_label_matrix(label).map_or(
                    0,
                    super::graphblas::versioned_matrix::VersionedMatrix::nvals,
                );
                (&mut self.node_indexer, total, IndexKind::Node)
            }
            EntityType::Relationship => {
                let total = self
                    .get_relationship_matrix(label)
                    .map_or(0, Tensor::edge_count);
                (&mut self.edge_indexer, total, IndexKind::Edge)
            }
        };

        let lock = indexer.write_lock();
        let _guard = lock.lock();

        let reindex = indexer.drop_index(label, attrs, index_type, total);

        match reindex {
            Some((dropped, remaining)) if dropped > 0 => {
                // Drop the native columns only now, after the indexer confirmed the drop.
                // Doing it earlier meant the `no such index` arm below could leave RediSearch
                // holding the index while the native columns were already gone — DROP INDEX
                // reports failure but half the state is destroyed.
                #[cfg(feature = "index-falkordb")]
                self.falkordb_index
                    .drop_index(index_type, *entity_type, label, &effective_attrs);
                if remaining > 0 {
                    indexer.recreate_index(label)?;
                    populate_index(kind, label.clone(), indexer.clone());
                } else {
                    drop_index_bg(label.clone(), indexer.clone());
                }
                Ok(dropped)
            }
            _ => {
                // Include every requested attr so multi-attribute
                // drops don't silently trim the list in the error.
                let attr_list = attrs
                    .iter()
                    .map(|a| a.as_str())
                    .collect::<Vec<_>>()
                    .join(", ");
                Err(format!(
                    "Unable to drop index on :{label}({attr_list}): no such index."
                ))
            }
        }
    }

    #[must_use]
    pub fn is_indexed(
        &self,
        label: &Arc<String>,
        field: &Arc<String>,
        index_type: &IndexType,
    ) -> bool {
        self.node_indexer.is_label_indexed(label, field, index_type)
    }

    pub fn get_indexed_nodes(
        &self,
        label: &Arc<String>,
        query: IndexQuery<Value>,
    ) -> impl Iterator<Item = NodeId> + use<> {
        self.node_indexer.query(label, query).map(NodeId)
    }

    /// Node ids for `query` from the index numeric column, or `None` to fall through to RediSearch
    /// (non-numeric / composite / missing column). Wraps
    /// [`FalkorDbIndex::query_numeric`], mapping raw ids to `NodeId`. `use<>` keeps the returned
    /// iterator free of the `&self` borrow — it owns its tree snapshot, so it outlives this
    /// borrow.
    #[cfg(feature = "index-falkordb")]
    pub fn query_index_numeric_nodes(
        &self,
        label: &Arc<String>,
        query: &IndexQuery<Value>,
    ) -> Option<impl Iterator<Item = NodeId> + use<>> {
        self.falkordb_index
            .query_numeric(EntityType::Node, label, query)
            .map(|iter| iter.map(NodeId))
    }

    /// Answer an EDGE numeric `Equal`/`Range` from the index column for `type_name`, yielding
    /// `(src, dst, edge_id)` — endpoints recovered from the graph's `edge_id → (src, dst)` reverse
    /// index (`endpoints_for_edge`), like RediSearch's edge read (which instead reads them from its
    /// 24-byte key). Endpoints are resolved eagerly into an owned iterator because the edge scan op
    /// only holds a temporary graph borrow, so the result must not borrow `self`. `None` (fall back to
    /// RediSearch) for non-numeric/composite predicates or a missing column.
    #[cfg(feature = "index-falkordb")]
    pub fn query_index_numeric_edges(
        &self,
        type_name: &Arc<String>,
        query: &IndexQuery<Value>,
    ) -> Option<impl Iterator<Item = (NodeId, NodeId, RelationshipId)> + use<>> {
        let iter = self
            .falkordb_index
            .query_numeric(EntityType::Relationship, type_name, query)?;
        // Own the reverse index rather than borrowing `self`, so the iterator stays lazy: the
        // signature is `+ use<>` (captures no lifetime), which is why this used to `collect()`
        // into a Vec. `edge_endpoints` is an `Arc`, so cloning is a refcount bump, and `get` is
        // the same lookup `endpoints_for_edge` does. Laziness matters here — a range scan
        // under a LIMIT should stop at the limit, not materialize every match first.
        let endpoints = Arc::clone(&self.edge_endpoints);
        Some(iter.filter_map(move |eid| {
            endpoints
                .get(eid)
                .map(|(src, dst)| (NodeId(src), NodeId(dst), RelationshipId(eid)))
        }))
    }

    #[must_use]
    pub fn is_edge_indexed(
        &self,
        label: &Arc<String>,
        field: &Arc<String>,
        index_type: &IndexType,
    ) -> bool {
        self.edge_indexer.is_label_indexed(label, field, index_type)
    }

    pub fn get_indexed_edges(
        &self,
        label: &Arc<String>,
        query: IndexQuery<Value>,
    ) -> impl Iterator<Item = (NodeId, NodeId, RelationshipId)> + use<> {
        // Edge index documents carry `(src, dst, edge_id)` in their
        // 24-byte key (set by `Document::new_edge`), so the result
        // iterator materializes endpoints directly — no relationship
        // tensor scan. Matches FalkorDB C's `EdgeIndexKey` layout.
        self.edge_indexer
            .query_edges(label, query)
            .map(|(src, dst, eid)| (NodeId(src), NodeId(dst), RelationshipId(eid)))
    }

    /// Get all edges of a given type (fallback when index can't be utilized).
    pub fn get_all_edges(
        &self,
        label: &Arc<String>,
    ) -> Vec<(NodeId, NodeId, RelationshipId)> {
        self.get_relationship_matrix(label)
            .map_or_else(std::vec::Vec::new, |tensor| {
                tensor
                    .iter(0, u64::MAX, false)
                    .map(|(src, dst, eid)| (NodeId(src), NodeId(dst), RelationshipId(eid)))
                    .collect()
            })
    }

    pub fn fulltext_query_nodes(
        &self,
        label: &Arc<String>,
        query: &str,
    ) -> Result<impl Iterator<Item = (NodeId, f64)> + use<>, String> {
        self.node_indexer
            .fulltext_query(label, query)
            .map(|r| r.map(|(id, score)| (NodeId(id), score)))
    }

    /// Execute a fulltext query against an *edge* index, yielding
    /// `(src, dst, edge_id, score)` tuples. Mirrors
    /// [`fulltext_query_nodes`] but goes through the `edge_indexer`
    /// and reads the 24-byte edge-index key produced by
    /// `Document::new_edge`.
    pub fn fulltext_query_edges(
        &self,
        label: &Arc<String>,
        query: &str,
    ) -> Result<impl Iterator<Item = (NodeId, NodeId, RelationshipId, f64)> + use<>, String> {
        self.edge_indexer
            .fulltext_query_edges(label, query)
            .map(|r| {
                r.map(|(src, dst, eid, score)| {
                    (NodeId(src), NodeId(dst), RelationshipId(eid), score)
                })
            })
    }

    /// Execute a KNN vector query against a node label's index,
    /// yielding `(NodeId, distance)` pairs ordered by ascending
    /// distance.
    ///
    /// Distances are computed manually from the query vector and each
    /// entity's stored vector — RediSearch's per-result score is *not*
    /// the KNN distance, and reading it returns 0. For each result we
    /// look up the entity's vector property and apply the index's
    /// similarity function. Results are eagerly materialized into a
    /// `Vec` so the caller can drop the graph borrow before iterating.
    pub fn vector_query_nodes(
        &self,
        label: &Arc<String>,
        field: &str,
        vector: Arc<thin_vec::ThinVec<f32>>,
        k: usize,
    ) -> Result<impl Iterator<Item = (NodeId, f64)> + use<>, String> {
        let attr = Arc::new(field.to_string());
        if let Some(expected) = self.node_indexer.get_vector_dimension(label, &attr)
            && expected as usize != vector.len()
        {
            return Err(format!(
                "Vector dimension mismatch, expected {expected} but got {}",
                vector.len()
            ));
        }
        let metric = self.node_indexer.get_vector_metric(label, &attr);
        let query_vec = Arc::clone(&vector);
        // `k` is user input. The index cannot hold more documents than there are
        // nodes, and a `k` far beyond that makes the KNN query return nothing.
        let k = k.min(self.node_count().max(1) as usize);
        let raw_iter = self.node_indexer.vector_query(label, field, vector, k)?;

        // Resolve the attribute name to its numeric slot once, rather than
        // re-hashing the attribute string for every KNN result. If the
        // attribute is unknown there are no vectors to score.
        let Some(attr_idx) = self.get_node_attribute_id(&attr).map(|i| i as u16) else {
            return Ok(Vec::new().into_iter());
        };
        // Collect the candidate ids first, then fetch their vectors in one
        // fused batch pass. This amortizes the per-shard read lock and gives
        // the attribute cache sequential access instead of one isolated
        // lookup per KNN result.
        let node_ids: Vec<NodeId> = raw_iter.map(|(id, _score)| NodeId(id)).collect();
        // Sized by the results, not by `k`: `k` is user input and may be far
        // larger than the index (an allocation of `k` entries aborts the server).
        let mut out: Vec<(NodeId, f64)> = Vec::with_capacity(node_ids.len());
        let mut vecs: Vec<Value> = Vec::with_capacity(node_ids.len());
        self.get_node_attributes_by_idx(&node_ids, attr_idx, &Value::Null, &mut vecs);
        for (node_id, entity) in node_ids.into_iter().zip(vecs) {
            let Value::VecF32(entity_vec) = entity else {
                continue;
            };
            if let Some(d) = vec_distance::distance(metric.as_deref(), &query_vec, &entity_vec) {
                out.push((node_id, d));
            }
        }
        // HNSW returns rows in (approximate) score order, but the
        // distance we recompute here may diverge slightly from
        // VecSim's internal ranking (different precision, different
        // reduction order). Sort by the value we actually expose so
        // the documented ascending-distance contract holds.
        out.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal));
        Ok(out.into_iter())
    }

    /// Execute a KNN vector query against an *edge* index, yielding
    /// `(src, dst, edge_id, distance)` tuples. Distances are computed
    /// from the query vector and each edge's stored vector — see
    /// [`vector_query_nodes`] for why.
    pub fn vector_query_edges(
        &self,
        label: &Arc<String>,
        field: &str,
        vector: Arc<thin_vec::ThinVec<f32>>,
        k: usize,
    ) -> Result<impl Iterator<Item = (NodeId, NodeId, RelationshipId, f64)> + use<>, String> {
        let attr = Arc::new(field.to_string());
        if let Some(expected) = self.edge_indexer.get_vector_dimension(label, &attr)
            && expected as usize != vector.len()
        {
            return Err(format!(
                "Vector dimension mismatch, expected {expected} but got {}",
                vector.len()
            ));
        }
        let metric = self.edge_indexer.get_vector_metric(label, &attr);
        let query_vec = Arc::clone(&vector);
        // Clamp the user-supplied `k` to the index's capacity (see `vector_query_nodes`).
        let k = k.min(self.relationship_count().max(1) as usize);
        let raw_iter = self
            .edge_indexer
            .vector_query_edges(label, field, vector, k)?;

        // Resolve the attribute slot once instead of per KNN result.
        let Some(attr_idx) = self.get_relationship_attribute_id(&attr).map(|i| i as u16) else {
            return Ok(Vec::new().into_iter());
        };
        // Collect candidate triples first, then fetch their vectors in one
        // fused batch pass (see `vector_query_nodes`).
        let triples: Vec<(NodeId, NodeId, RelationshipId)> = raw_iter
            .map(|(src, dst, eid, _score)| (NodeId(src), NodeId(dst), RelationshipId(eid)))
            .collect();
        let edge_ids: Vec<RelationshipId> = triples.iter().map(|&(_, _, eid)| eid).collect();
        // Sized by the results, not by the user-supplied `k` (see `vector_query_nodes`).
        let mut out: Vec<(NodeId, NodeId, RelationshipId, f64)> = Vec::with_capacity(triples.len());
        let mut vecs: Vec<Value> = Vec::with_capacity(edge_ids.len());
        self.get_relationship_attributes_by_idx(&edge_ids, attr_idx, &Value::Null, &mut vecs);
        for ((src, dst, edge_id), entity) in triples.into_iter().zip(vecs) {
            let Value::VecF32(entity_vec) = entity else {
                continue;
            };
            if let Some(d) = vec_distance::distance(metric.as_deref(), &query_vec, &entity_vec) {
                out.push((src, dst, edge_id, d));
            }
        }
        // See `vector_query_nodes` for why we sort by recomputed
        // distance instead of trusting the upstream HNSW order.
        out.sort_by(|a, b| a.3.partial_cmp(&b.3).unwrap_or(std::cmp::Ordering::Equal));
        Ok(out.into_iter())
    }

    #[must_use]
    pub fn index_info(&self) -> Vec<IndexInfo> {
        let mut infos = self.node_indexer.index_info();
        for info in &mut infos {
            info.entity_type = String::from("NODE");
        }
        let mut edge_infos = self.edge_indexer.index_info();
        for info in &mut edge_infos {
            info.entity_type = String::from("RELATIONSHIP");
        }
        infos.extend(edge_infos);
        infos
    }

    // ── Constraint management ─────────────────────────────────────────

    #[must_use]
    pub fn constraints(&self) -> &[Constraint] {
        &self.constraints
    }

    pub const fn constraints_mut(&mut self) -> &mut Vec<Constraint> {
        &mut self.constraints
    }

    /// Create a constraint, validating the data already in the graph.
    ///
    /// Returns whether validation was left unfinished: `false` if it ran
    /// inline and the constraint is already in its final status, `true` if the
    /// data is large enough that the constraint was parked UNDER CONSTRUCTION
    /// and the caller must settle it on a background thread.
    /// Does **not** intern the label or the property names. That is the
    /// command layer's, in `register_constraint_schema` — see the note there
    /// for why the two are separated and why the order is load-bearing.
    pub fn create_constraint(
        &mut self,
        ct: ConstraintType,
        entity_type: EntityType,
        label: &Arc<String>,
        properties: &[Arc<String>],
    ) -> Result<bool, String> {
        if ct == ConstraintType::Unique
            && !self.has_supporting_index(&entity_type, label, properties)
        {
            return Err("missing supporting exact-match index".into());
        }

        // Check for duplicates
        let existing_idx = self
            .constraints
            .iter()
            .position(|c| c.matches(&ct, &entity_type, label, properties));
        if let Some(idx) = existing_idx {
            if self.constraints[idx].status == ConstraintStatus::Failed {
                // Remove the failed constraint so it can be recreated
                self.constraints.remove(idx);
            } else {
                return Err("Constraint already exists".into());
            }
        }

        // Cloned here, where the values are actually stored, rather than by
        // the caller — which needs its own copies afterwards to announce the
        // constraint and was cloning for that reason. Both are `Arc`, so this
        // is a refcount bump plus one small vector, on a DDL path.
        let mut constraint = Constraint::new(ct, entity_type, label.clone(), properties.to_vec());

        // Entity count decides inline validation vs a background thread.
        let count = self.get_constraint_entity_count(&constraint);

        if count <= 10_000 {
            // Synchronous validation for small datasets
            if self.validate_constraint(&constraint) {
                constraint.status = ConstraintStatus::Operational;
            } else {
                constraint.status = ConstraintStatus::Failed;
            }
            self.constraints.push(constraint);
            Ok(false) // validated inline, nothing left to do
        } else {
            // Large dataset: mark under construction, caller spawns background validation
            constraint.status = ConstraintStatus::UnderConstruction;
            self.constraints.push(constraint);
            Ok(true) // caller must settle it on a background thread
        }
    }

    /// Add a constraint directly (for replication/restore). No validation.
    pub fn add_constraint_raw(
        &mut self,
        constraint: Constraint,
    ) {
        self.constraints.push(constraint);
    }

    /// Install a constraint with the status the primary reached, adding it if
    /// this graph does not have it yet and updating the status if it does.
    ///
    /// Idempotent because the primary announces a constraint **twice**: once
    /// when it is created, still under construction, and again when validation
    /// finishes and it is either operational or failed. A plain add would leave
    /// a duplicate; a plain "already exists, ignore" would leave the replica
    /// believing it is still under construction forever, which is what makes
    /// the second announcement load-bearing rather than noise.
    pub fn upsert_constraint_raw(
        &mut self,
        ct: ConstraintType,
        entity_type: EntityType,
        label: &Arc<String>,
        properties: &[Arc<String>],
        status: ConstraintStatus,
    ) {
        if let Some(existing) = self.constraints.iter_mut().find(|c| {
            c.ct == ct
                && c.entity_type == entity_type
                && c.label == *label
                && c.properties == properties
        }) {
            existing.status = status;
            return;
        }
        let mut constraint = Constraint::new(ct, entity_type, label.clone(), properties.to_vec());
        constraint.status = status;
        self.constraints.push(constraint);
    }

    fn get_constraint_entity_count(
        &self,
        constraint: &Constraint,
    ) -> u64 {
        match constraint.entity_type {
            EntityType::Node => self.label_node_count(&constraint.label),
            EntityType::Relationship => self
                .get_relationship_matrix(&constraint.label)
                .map_or(0, Tensor::edge_count),
        }
    }

    fn validate_constraint(
        &self,
        constraint: &Constraint,
    ) -> bool {
        match constraint.ct {
            ConstraintType::Mandatory => self.validate_mandatory_constraint(constraint),
            ConstraintType::Unique => self.validate_unique_constraint(constraint),
        }
    }

    /// Validate all constraints currently under construction and update their status.
    pub fn validate_pending_constraints(&mut self) {
        // Collect indices of pending constraints to avoid borrow conflicts
        let pending_indices: Vec<usize> = self
            .constraints
            .iter()
            .enumerate()
            .filter(|(_, c)| c.status == ConstraintStatus::UnderConstruction)
            .map(|(i, _)| i)
            .collect();

        for i in pending_indices {
            let valid = self.validate_constraint(&self.constraints[i].clone());
            self.constraints[i].status = if valid {
                ConstraintStatus::Operational
            } else {
                ConstraintStatus::Failed
            };
        }
    }

    /// Read-only phase of background constraint validation: compute the outcome
    /// (valid / invalid) for every constraint currently under construction,
    /// without mutating state. Pair with
    /// [`apply_constraint_validation_results`] under a write lock.
    ///
    /// Returns `(constraint_id, valid)` rather than indices because
    /// `drop_constraint` uses `swap_remove`, which invalidates positional
    /// references between the compute and apply phases.
    #[must_use]
    pub fn compute_pending_constraint_results(&self) -> Vec<(u64, bool)> {
        self.constraints
            .iter()
            .filter(|c| c.status == ConstraintStatus::UnderConstruction)
            .map(|c| (c.id, self.validate_constraint(c)))
            .collect()
    }

    /// Apply results computed by [`compute_pending_constraint_results`].
    /// Status is updated only for constraints that are still under
    /// construction and still present (a concurrent drop may have removed
    /// them, and `swap_remove` may have shuffled others into their slot).
    pub fn apply_constraint_validation_results(
        &mut self,
        results: Vec<(u64, bool)>,
    ) {
        for (id, valid) in results {
            if let Some(c) = self
                .constraints
                .iter_mut()
                .find(|c| c.id == id && c.status == ConstraintStatus::UnderConstruction)
            {
                c.status = if valid {
                    ConstraintStatus::Operational
                } else {
                    ConstraintStatus::Failed
                };
            }
        }
    }

    fn validate_mandatory_constraint(
        &self,
        constraint: &Constraint,
    ) -> bool {
        match constraint.entity_type {
            EntityType::Node => {
                let Some(lm) = self.get_label_matrix(&constraint.label) else {
                    return true;
                };
                for (node_id, _) in lm.iter(0, u64::MAX) {
                    for prop in &constraint.properties {
                        if self
                            .get_node_attribute(NodeId(node_id), prop)
                            .is_none_or(|val| matches!(val, Value::Null))
                        {
                            return false;
                        }
                    }
                }
                true
            }
            EntityType::Relationship => {
                let Some(tensor) = self.get_relationship_matrix(&constraint.label) else {
                    return true;
                };
                for (_, _, edge_id) in tensor.iter(0, u64::MAX, false) {
                    for prop in &constraint.properties {
                        if self
                            .get_relationship_attribute(RelationshipId(edge_id), prop)
                            .is_none_or(|val| matches!(val, Value::Null))
                        {
                            return false;
                        }
                    }
                }
                true
            }
        }
    }

    fn validate_unique_constraint(
        &self,
        constraint: &Constraint,
    ) -> bool {
        match constraint.entity_type {
            EntityType::Node => {
                let Some(lm) = self.get_label_matrix(&constraint.label) else {
                    return true;
                };
                let mut seen: FxHashSet<Vec<u8>> = FxHashSet::default();
                for (node_id, _) in lm.iter(0, u64::MAX) {
                    let key = Self::build_composite_key(&constraint.properties, |prop| {
                        self.get_node_attribute(NodeId(node_id), prop)
                    });
                    if key.is_empty() {
                        // a constrained property is NULL or absent, so this node
                        // does not participate in the constraint
                        continue;
                    }
                    if !seen.insert(key) {
                        return false;
                    }
                }
                true
            }
            EntityType::Relationship => {
                let Some(tensor) = self.get_relationship_matrix(&constraint.label) else {
                    return true;
                };
                let mut seen: FxHashSet<Vec<u8>> = FxHashSet::default();
                for (_, _, edge_id) in tensor.iter(0, u64::MAX, false) {
                    let key = Self::build_composite_key(&constraint.properties, |prop| {
                        self.get_relationship_attribute(RelationshipId(edge_id), prop)
                    });
                    if key.is_empty() {
                        // a constrained property is NULL or absent, so this edge
                        // does not participate in the constraint
                        continue;
                    }
                    if !seen.insert(key) {
                        return false;
                    }
                }
                true
            }
        }
    }

    /// Build the composite unique-constraint key for `properties`.
    ///
    /// Returns an empty key as soon as *any* constrained property is NULL or
    /// absent: such a key is unknown, and an unknown key cannot be proven to
    /// collide with another, so the entity satisfies the constraint vacuously.
    /// Callers treat an empty key as "this entity does not participate in the
    /// constraint" and skip it.
    #[must_use]
    pub fn build_composite_key(
        properties: &[Arc<String>],
        mut get: impl FnMut(&Arc<String>) -> Option<Value>,
    ) -> Vec<u8> {
        let mut key = Vec::new();
        for prop in properties {
            match get(prop) {
                Some(v) if !matches!(v, Value::Null) => {
                    key.extend_from_slice(format!("{v:?}").as_bytes());
                }
                _ => return Vec::new(),
            }
            key.push(b'|');
        }
        key
    }

    /// Drop a constraint by type, entity type, label and properties.
    pub fn drop_constraint(
        &mut self,
        ct: &ConstraintType,
        entity_type: &EntityType,
        label: &str,
        properties: &[Arc<String>],
    ) -> Result<(), String> {
        let idx = self
            .constraints
            .iter()
            .position(|c| c.matches(ct, entity_type, label, properties));
        match idx {
            Some(i) => {
                self.constraints.swap_remove(i);
                Ok(())
            }
            None => Err("Unable to drop constraint, no such constraint.".into()),
        }
    }

    /// Check if a unique constraint for the given label and properties has
    /// a supporting exact-match index for each property.
    #[must_use]
    pub fn has_supporting_index(
        &self,
        entity_type: &EntityType,
        label: &Arc<String>,
        properties: &[Arc<String>],
    ) -> bool {
        let indexer = match entity_type {
            EntityType::Node => &self.node_indexer,
            EntityType::Relationship => &self.edge_indexer,
        };
        // Check if the index exists (regardless of operational status)
        // since index population may still be in progress
        properties
            .iter()
            .all(|prop| indexer.has_field_for_label(label, prop, &IndexType::Range))
    }

    /// Check if any UNIQUE constraint depends on an index for the given label and attribute.
    #[must_use]
    pub fn constraint_depends_on_index(
        &self,
        entity_type: &EntityType,
        label: &Arc<String>,
        attr: &Arc<String>,
        index_type: &IndexType,
    ) -> bool {
        // Only Range indexes support UNIQUE constraints
        if *index_type != IndexType::Range {
            return false;
        }
        self.constraints.iter().any(|c| {
            c.ct == ConstraintType::Unique
                && c.entity_type == *entity_type
                && c.label.as_str() == label.as_str()
                && c.properties.iter().any(|p| p.as_str() == attr.as_str())
        })
    }

    pub fn cancel_indexing(&self) {
        self.node_indexer.cancel();
        self.edge_indexer.cancel();
    }

    /// Takes `&self` (not `&mut self`): it only publishes the graph
    /// reference into the node/edge indexers' own `Mutex`-guarded fields,
    /// via `Indexer::set_graph`. This lets `MvccGraph::commit()` call it
    /// through an immutable borrow of the graph, so the background index
    /// population thread's own immutable borrows of the same
    /// `AtomicRefCell<Graph>` are never blocked by (or racing against) a
    /// concurrent mutable borrow here -- see `MvccGraph::commit()`.
    pub fn set_indexer_graph(
        &self,
        graph: Arc<AtomicRefCell<Self>>,
    ) {
        self.node_indexer.set_graph(graph.clone());
        self.edge_indexer.set_graph(graph);
    }

    /// Build a materialized boolean adjacency matrix filtered by relationship types.
    /// If `rel_types` is empty, returns the full adjacency matrix.
    /// The caller owns the returned `Matrix`.
    #[must_use]
    pub fn build_adjacency_matrix(
        &self,
        rel_types: &[Arc<String>],
    ) -> Matrix<bool> {
        if rel_types.is_empty() {
            self.adjacancy_matrix.extract()
        } else if let [rel_type] = rel_types {
            // Single type: the extract already materializes an owned bool
            // matrix; skip the extra new + eWiseAdd pass.
            self.get_type_id(rel_type).map_or_else(
                || Matrix::<bool>::new(self.node_cap, self.node_cap),
                |type_id| self.relationship_matrices[usize::from(type_id)].extract(),
            )
        } else {
            let mut result = Matrix::<bool>::new(self.node_cap, self.node_cap);
            for rel_type in rel_types {
                if let Some(type_id) = self.get_type_id(rel_type) {
                    let m = self.relationship_matrices[usize::from(type_id)].extract();
                    result.element_wise_add(None, None, Some(&m), None);
                }
            }
            result
        }
    }

    /// Build a materialized boolean adjacency matrix that is symmetric (A + A^T).
    /// Used for undirected graph algorithms (WCC, CDLP, MSF).
    #[must_use]
    pub fn build_symmetric_adjacency_matrix(
        &self,
        rel_types: &[Arc<String>],
    ) -> Matrix<bool> {
        let a = self.build_adjacency_matrix(rel_types);
        let at = a.transpose();
        let mut result = Matrix::<bool>::new(self.node_cap, self.node_cap);
        result.element_wise_add(None, Some(&a), Some(&at), None);
        result
    }

    /// Compute a detailed breakdown of memory usage for `GRAPH.MEMORY USAGE`.
    ///
    /// `samples` controls how many entities are sampled per label/type when
    /// estimating attribute memory.  Clamped to \[1, 10000\].
    #[must_use]
    pub fn memory_usage_report(
        &self,
        samples: usize,
    ) -> MemoryUsageReport {
        let samples = samples.clamp(1, 10000);

        // --- label matrices ---
        let mut label_matrices_sz: usize = 0;
        label_matrices_sz += self.node_labels_matrix.memory_usage();
        for lm in &self.labels_matices {
            label_matrices_sz += lm.memory_usage();
        }

        // --- relation matrices ---
        // Per-type tensors plus the combined adjacency matrix and the zero
        // matrix, matching what C's `Graph_memoryUsage` folds in here.
        let mut relation_matrices_sz: usize =
            self.adjacancy_matrix.memory_usage() + self.zero_matrix.memory_usage();
        for rm in &self.relationship_matrices {
            relation_matrices_sz += rm.memory_usage();
        }

        // --- node block storage ---
        // Everything a node costs that is not its property values: the
        // attribute store's unattributed bytes (the per-node slot, which is
        // what makes an attribute-less node not free, and the counterpart of
        // C's per-node DataBlock item) and the deleted-id bitmap. Node
        // existence itself costs nothing beyond those — it is the id range
        // minus that bitmap, not a stored structure. Property values are
        // reported under the attribute components, and
        // `structural_memory_usage` excludes exactly those, so the two halves
        // cover the store without overlap.
        let node_block_storage_sz: usize =
            self.node_attrs.structural_memory_usage() + self.node_ids.recycled().serialized_size();

        // --- edge block storage ---
        // Mirrors the node side: the matrix recording each edge's existence and
        // type, plus the graph-wide edge_id → endpoint reverse index (one slot
        // per edge id, 4, 6, 8 or 16 bytes wide depending on the tier).
        let edge_block_storage_sz: usize = self.relationship_type_matrix.memory_usage()
            + self.relationship_attrs.structural_memory_usage()
            + self.relationship_ids.recycled().serialized_size()
            + self.edge_endpoints.memory_usage();

        // --- node attributes by label (sampling) ---
        let mut node_attr_by_label: Vec<(Arc<String>, usize)> = Vec::new();

        // Track processed node IDs (deduplicated) so that multi-label nodes are
        // counted once, under their first (lowest-index) label — matching the C
        // implementation — and so unlabeled nodes can be detected afterwards.
        // A dense bitvector indexed by node id gives O(1) membership/insert,
        // far cheaper than a RoaringTreemap when touching every node.
        // Sized by `node_cap` (the matrix dimension) rather than `max_node_id()`:
        // effects replay can leave sparse high ids whose value exceeds
        // `node_count + deleted_nodes.len() - 1`, but every id present in the
        // label/all-node matrices is strictly below `node_cap`.
        let mut seen = vec![false; self.node_cap() as usize];
        let mut total_labeled: u64 = 0;

        for (label_idx, label_name) in self.node_labels.iter().enumerate() {
            let label_matrix = &self.labels_matices[label_idx];
            let total_for_label = label_matrix.nvals();
            if total_for_label == 0 {
                node_attr_by_label.push((label_name.clone(), 0));
                continue;
            }

            // Iterate the full label matrix.  For attribute estimation, only
            // sample nodes that have NOT been processed by a previous label
            // (avoids double-counting multi-label nodes, matching C).
            let mut sampled_mem: usize = 0;
            let mut sampled_count: usize = 0;
            let mut unprocessed_count: u64 = 0;
            for (node_id, _) in label_matrix.iter(0, u64::MAX) {
                let slot = &mut seen[node_id as usize];
                if !*slot {
                    *slot = true;
                    total_labeled += 1;
                    unprocessed_count += 1;
                    if sampled_count < samples {
                        sampled_mem += self.estimate_entity_attr_size(&self.node_attrs, node_id);
                        sampled_count += 1;
                    }
                }
            }

            let estimated = if sampled_count > 0 {
                (sampled_mem as u64 * unprocessed_count / sampled_count as u64) as usize
            } else {
                0
            };
            node_attr_by_label.push((label_name.clone(), estimated));
        }

        // --- unlabeled node attributes ---
        let total_nodes = self.node_ids.live();
        let unlabeled_count = total_nodes.saturating_sub(total_labeled);
        let unlabeled_node_attr_sz = if unlabeled_count > 0 {
            // Sample unlabeled nodes, skipping labeled ones. Live ids are the
            // id range minus the deleted set — the same walk `get_nodes` uses
            // for an unfiltered scan.
            let mut sampled_mem: usize = 0;
            let mut sampled_count: usize = 0;
            for node_id in 0..=self.max_node_id() {
                if sampled_count >= samples {
                    break;
                }
                if self.node_ids.is_free(node_id) || seen[node_id as usize] {
                    continue;
                }
                sampled_mem += self.estimate_entity_attr_size(&self.node_attrs, node_id);
                sampled_count += 1;
            }
            if sampled_count > 0 {
                (sampled_mem as u64 * unlabeled_count / sampled_count as u64) as usize
            } else {
                0
            }
        } else {
            0
        };

        // --- edge attributes by type (sampling) ---
        let mut edge_attr_by_type: Vec<(Arc<String>, usize)> = Vec::new();
        for (type_idx, type_name) in self.relationship_types.iter().enumerate() {
            let tensor = &self.relationship_matrices[type_idx];
            let total_for_type = tensor.edge_count();
            if total_for_type == 0 {
                edge_attr_by_type.push((type_name.clone(), 0));
                continue;
            }

            let mut sampled_mem: usize = 0;
            let mut sampled_count: usize = 0;
            for (_, _, edge_id) in tensor.iter(0, u64::MAX, false) {
                if sampled_count >= samples {
                    break;
                }
                sampled_mem += self.estimate_entity_attr_size(&self.relationship_attrs, edge_id);
                sampled_count += 1;
            }

            let estimated = if sampled_count > 0 {
                (sampled_mem as u64 * total_for_type / sampled_count as u64) as usize
            } else {
                0
            };
            edge_attr_by_type.push((type_name.clone(), estimated));
        }

        // --- indices ---
        let indices_sz = self.node_indexer.memory_usage() + self.edge_indexer.memory_usage();

        MemoryUsageReport {
            label_matrices_sz,
            relation_matrices_sz,
            node_block_storage_sz,
            node_attr_by_label,
            unlabeled_node_attr_sz,
            edge_block_storage_sz,
            edge_attr_by_type,
            indices_sz,
        }
    }

    fn estimate_entity_attr_size(
        &self,
        store: &AttributeStore,
        entity_id: u64,
    ) -> usize {
        store.entity_memory_usage(entity_id)
    }

    /// Encode a single payload entry.
    pub fn encode_payload(
        &self,
        w: &mut dyn Writer,
        p: &PayloadEntry,
    ) {
        match p.state {
            EncodeState::Nodes => {
                self.node_attrs.encode_with_range(
                    w,
                    self.node_ids.recycled(),
                    self.max_node_id(),
                    p.count,
                    p.offset,
                );
            }
            EncodeState::DeletedNodes => {
                self.node_ids
                    .recycled()
                    .encode_with_range(w, p.count, p.offset);
            }
            EncodeState::Edges => {
                self.relationship_attrs.encode_with_range(
                    w,
                    self.relationship_ids.recycled(),
                    self.max_relationship_id(),
                    p.count,
                    p.offset,
                );
            }
            EncodeState::DeletedEdges => {
                self.relationship_ids
                    .recycled()
                    .encode_with_range(w, p.count, p.offset);
            }
            EncodeState::LabelsMatrices => {
                let label_matrices = self.label_matrices();
                w.write_unsigned(label_matrices.len() as u64);
                for (i, lm) in label_matrices.iter().enumerate() {
                    w.write_unsigned(i as u64);
                    lm.encode(w);
                }
            }
            EncodeState::RelationMatrices => {
                let tensors = self.relationship_tensors();
                for (i, tensor) in tensors.iter().enumerate() {
                    w.write_unsigned(i as u64);
                    tensor.encode(w);
                }
            }
            EncodeState::AdjMatrix => self.adjacancy_matrix.encode(w),
            EncodeState::LblsMatrix => self.node_labels_matrix.encode(w),
            _ => {}
        }
    }

    /// Get node attribute names.
    #[must_use]
    pub fn get_node_attribute_names(&self) -> Vec<Arc<String>> {
        self.attrs_name.iter().cloned().collect()
    }

    /// Get relationship attribute names.
    #[must_use]
    pub fn get_relationship_attribute_names(&self) -> Vec<Arc<String>> {
        self.attrs_name.iter().cloned().collect()
    }

    /// Register a node attribute name (get-or-create). Used by effect
    /// replication to pre-register attribute names on the replica.
    pub fn add_node_attribute_name(
        &mut self,
        name: &str,
    ) {
        let arc = Arc::new(name.to_string());
        if self.attrs_name.get_index_of(&arc).is_none() {
            self.attrs_name.insert(arc);
        }
    }

    /// Register a relationship attribute name (get-or-create). Used by effect
    /// replication to pre-register attribute names on the replica.
    pub fn add_rel_attribute_name(
        &mut self,
        name: &str,
    ) {
        // Identical to `add_node_attribute_name` now that there is one dictionary. Both
        // are kept because the effects wire still carries an ATTR_NODE/ATTR_REL
        // discriminator, which is vestigial from here on and is removed with the
        // `EFFECTS_VERSION` bump in #2419.
        self.attrs_name.insert(Arc::new(name.to_string()));
    }

    /// The graph's attribute names, in id order — index *is* the id.
    ///
    /// Was a node ∪ relationship union over two dictionaries; with one dictionary it is
    /// simply that dictionary's contents, and the RDB's flat table is the same list.
    #[must_use]
    pub fn build_global_attrs(&self) -> Vec<Arc<String>> {
        self.attrs_name.iter().cloned().collect()
    }
}

#[cfg(test)]
mod attr_id_space_tests {
    use super::super::graphblas::test_init::ensure_init;
    use super::*;

    fn attr(s: &str) -> Arc<String> {
        Arc::new(s.to_string())
    }

    /// A name has one id, whichever kind of entity introduced it.
    ///
    /// This is the invariant behind #2457. With a dictionary per store, `since` was
    /// registered only in the relationship table, so it got relationship-local id 0 —
    /// colliding with the *node* attribute already holding node-local id 0. Effects put a
    /// bare id on the wire, so a replica whose dictionary came from an RDB (one unified
    /// table) resolved that 0 to the wrong attribute.
    #[test]
    fn one_id_per_name_across_entity_kinds() {
        ensure_init();
        let mut g = Graph::new(16, 16, 1, 0, "attr_id_space");

        // Node attributes first, so a per-store numbering would start relationships back
        // at 0 and collide with `a`.
        let a = g.get_or_create_node_attr_id(&attr("a"));
        let b = g.get_or_create_node_attr_id(&attr("b"));
        // Then a relationship-only attribute.
        let since = g.get_or_create_rel_attr_id(&attr("since"));

        assert_eq!(a, 0);
        assert_eq!(b, 1);
        // The bug: this was 0 — the relationship table's first slot.
        assert_eq!(
            since, 2,
            "a relationship attribute must not restart numbering"
        );

        // Every accessor agrees, because there is only one dictionary to disagree about.
        for (name, expected) in [("a", 0usize), ("b", 1), ("since", 2)] {
            let n = attr(name);
            assert_eq!(g.get_node_attribute_id(&n), Some(expected));
            assert_eq!(g.get_relationship_attribute_id(&n), Some(expected));
            assert_eq!(g.get_global_attribute_id(&n), Some(expected));
        }

        // Re-registering under the other entity kind must not mint a second id.
        assert_eq!(g.get_or_create_rel_attr_id(&attr("a")), 0);
        assert_eq!(g.get_or_create_node_attr_id(&attr("since")), 2);
        assert_eq!(g.build_global_attrs().len(), 3);
    }

    /// The RDB's flat list and the live dictionary are the same numbering.
    ///
    /// A full sync seeds a replica from `build_global_attrs()`. If that list disagreed
    /// with the ids the master stamps into effects, the replica would misresolve them —
    /// which is exactly how #2457 manifested.
    #[test]
    fn rdb_attr_list_matches_live_ids() {
        ensure_init();
        let mut g = Graph::new(16, 16, 1, 0, "attr_id_rdb");
        g.get_or_create_node_attr_id(&attr("a"));
        let since = g.get_or_create_rel_attr_id(&attr("since"));
        g.get_or_create_node_attr_id(&attr("b"));

        let list = g.build_global_attrs();

        // The load-bearing one: an id the master stamps into an effect has to index the
        // same name in the list a replica is seeded from. Split numbering broke exactly
        // this — `since` was relationship-local 0, and position 0 of the list is `a`.
        assert_eq!(
            list.get(since as usize).map(|s| s.as_str()),
            Some("since"),
            "the id put on the wire does not index its own name in the RDB list"
        );

        for (id, name) in list.iter().enumerate() {
            assert_eq!(
                g.get_global_attribute_id(name),
                Some(id),
                "RDB position {id} disagrees with the live id for {name}"
            );
        }
    }
}

#[cfg(test)]
mod composite_key_tests {
    use super::*;

    fn key(
        props: &[&str],
        present: &[(&str, Value)],
    ) -> Vec<u8> {
        let props: Vec<Arc<String>> = props.iter().map(|p| Arc::new((*p).to_string())).collect();
        Graph::build_composite_key(&props, |p| {
            present
                .iter()
                .find(|(name, _)| name == &p.as_str())
                .map(|(_, v)| v.clone())
        })
    }

    /// Every constrained property present → a real key that discriminates.
    #[test]
    fn complete_key_is_built_and_discriminates() {
        let a = key(&["a", "b"], &[("a", Value::Int(1)), ("b", Value::Int(2))]);
        assert!(!a.is_empty());
        assert_eq!(
            a,
            key(&["a", "b"], &[("a", Value::Int(1)), ("b", Value::Int(2))])
        );
        assert_ne!(
            a,
            key(&["a", "b"], &[("a", Value::Int(1)), ("b", Value::Int(3))])
        );
    }

    /// A missing or NULL component makes the whole key unknown, so the entity
    /// is vacuously unique — regardless of which component it is.
    #[test]
    fn any_null_component_yields_empty_key() {
        assert!(key(&["a", "b"], &[("a", Value::Int(1))]).is_empty());
        assert!(key(&["a", "b"], &[("b", Value::Int(2))]).is_empty());
        assert!(key(&["a", "b"], &[]).is_empty());
        assert!(key(&["a", "b"], &[("a", Value::Int(1)), ("b", Value::Null)]).is_empty());
        assert!(key(&["a", "b"], &[("a", Value::Null), ("b", Value::Int(2))]).is_empty());
        assert!(
            key(
                &["a", "b", "c"],
                &[("a", Value::Int(1)), ("c", Value::Int(3))]
            )
            .is_empty()
        );
    }

    /// For a single property ALL and ANY coincide, so behaviour is unchanged.
    #[test]
    fn single_property_is_unaffected() {
        assert!(!key(&["a"], &[("a", Value::Int(1))]).is_empty());
        assert!(key(&["a"], &[]).is_empty());
        assert!(key(&["a"], &[("a", Value::Null)]).is_empty());
    }
}

#[cfg(test)]
mod reservation_tests {
    use super::*;
    use crate::graph::graphblas::test_init::ensure_init;

    fn graph() -> Graph {
        ensure_init();
        Graph::new(64, 64, 0, 0, "r")
    }

    /// One query's worth of node reservations, driven the way `CreateOp` drives
    /// them: reserve a batch, record it, reserve the next.
    ///
    /// `outstanding` comes from the recorded set rather than from a counter,
    /// which is the whole point — the test would still pass against a stored
    /// count, so what it is really pinning is that the ids do not collide.
    struct Query {
        /// What commit will create.
        created: RoaringTreemap,
        /// What this batch gave back. With `created` it is exactly what the
        /// allocator must not reissue — `Pending`'s two sets.
        cancelled: RoaringTreemap,
    }

    impl Query {
        /// Opening a query opens the graph's batch, exactly as `Commit` does.
        fn new(g: &mut Graph) -> Self {
            g.open_id_batches().expect("a consistent space");
            Self {
                created: RoaringTreemap::new(),
                cancelled: RoaringTreemap::new(),
            }
        }

        fn reserve(
            &mut self,
            g: &mut Graph,
            n: usize,
        ) -> Vec<u64> {
            let before = &self.created | &self.cancelled;
            // Only the ids the space does not already know about, mirroring
            // `Pending::issued_nodes`. The cancelled ones it recorded itself;
            // handing them back would count one id twice and skip a free slot.
            let ids = g
                .node_id_space()
                .reserve(n, &self.created)
                .expect("reserved");
            for &id in &ids {
                assert!(
                    !before.contains(id),
                    "{id} was handed out twice in one query"
                );
                self.created.insert(id);
            }
            ids
        }

        /// Cancel a reservation, as `DELETE` of a pending-created node does.
        /// The id leaves `created`, so commit will not make it — but the space
        /// keeps it, so this query will not be handed it again.
        fn cancel(
            &mut self,
            g: &mut Graph,
            id: u64,
        ) {
            assert!(self.created.remove(id), "cancelling an id never reserved");
            self.cancelled.insert(id);
            g.cancel_node_id(NodeId(id)).expect("a consistent space");
        }

        fn commit(
            self,
            g: &mut Graph,
        ) {
            g.create_nodes(&self.created)
                .expect("the allocator's own ids must be creatable");
            // The write path's own shapes must now satisfy what a replica is
            // held to, cancelled reservations included. This is what recording
            // a cancellation into the ledger bought, and the precondition for
            // calling `verify` on the write path for real (#2839 step 4).
            g.node_id_space()
                .verify()
                .expect("a committed query leaves a possible id space");
        }
    }

    fn delete(
        g: &mut Graph,
        ids: &[u64],
    ) {
        let bm: RoaringTreemap = ids.iter().copied().collect();
        let mut docs = IndexDocs::default();
        // A batch that created nothing: every id here predates it, which is
        // what makes them deletable.
        g.open_id_batches().expect("a consistent space");
        g.delete_nodes(&bm, &mut docs).expect("deleted");
    }

    /// Between queries the id space is dense: `handed_out` ids have been
    /// issued, and every one of them is either live or in the recycle bin.
    ///
    /// Checked as two independent readings rather than one, because the
    /// boundary is *derived* from the same two numbers it would otherwise be
    /// compared against. Walking the bin gives a count that does not come from
    /// `deleted_nodes.len()`, so a bin holding an id at or above the boundary —
    /// an id nothing ever handed out — is caught rather than cancelling out.
    /// This is the same pairing [`IdSpace::verify`] makes, and what it would
    /// refuse as `IdSpaceError::Inconsistent` if a replica were told this.
    fn assert_dense(
        g: &Graph,
        handed_out: u64,
    ) {
        assert_eq!(
            g.node_id_bound(),
            handed_out,
            "the boundary must count every id ever handed out"
        );
        let free = (0..handed_out)
            .filter(|&id| g.is_node_deleted(NodeId(id)))
            .count() as u64;
        assert_eq!(
            handed_out - free,
            g.node_ids.live(),
            "{free} of the {handed_out} issued ids are free, so {} should be live, not {}",
            handed_out - free,
            g.node_ids.live()
        );
    }

    /// Successive batches in one query must not overlap. The graph keeps no
    /// record of what it handed out, so this is entirely carried by the
    /// `outstanding` the caller passes — pass a stale one and the second batch
    /// repeats the first.
    #[test]
    fn successive_batches_do_not_overlap() {
        let mut g = graph();
        let mut q = Query::new(&mut g);

        let mut all = Vec::new();
        for _ in 0..5 {
            all.extend(q.reserve(&mut g, 1024));
        }

        assert_eq!(all, (0..5120).collect::<Vec<_>>(), "dense and in order");
        q.commit(&mut g);
        assert_dense(&g, 5120);
    }

    /// Freed ids are handed out before fresh ones, lowest first.
    #[test]
    fn reclaims_from_the_bin_before_allocating_fresh() {
        let mut g = graph();
        let mut q = Query::new(&mut g);
        q.reserve(&mut g, 10);
        q.commit(&mut g);
        delete(&mut g, &[2, 5, 7]);

        let mut q = Query::new(&mut g);
        assert_eq!(q.reserve(&mut g, 2), vec![2, 5]);
        assert_eq!(q.reserve(&mut g, 1), vec![7], "then the last freed id");
        assert_eq!(q.reserve(&mut g, 2), vec![10, 11], "then fresh");
        q.commit(&mut g);
        assert_dense(&g, 12);
    }

    /// A single batch that empties the bin and keeps going must not let the two
    /// halves collide. The fresh ids start above every id ever handed out — not
    /// above `node_count`, which the reclaimed half has not reached yet.
    #[test]
    fn one_batch_spanning_the_bin_and_fresh_ids() {
        let mut g = graph();
        let mut q = Query::new(&mut g);
        q.reserve(&mut g, 10);
        q.commit(&mut g);
        delete(&mut g, &[3]);

        // 9 live (0..10 minus 3), one in the bin, so 10 ids handed out.
        let mut q = Query::new(&mut g);
        assert_eq!(
            q.reserve(&mut g, 3),
            vec![3, 10, 11],
            "the freed id, then above the boundary"
        );
        q.commit(&mut g);
        assert_dense(&g, 12);
    }

    /// `CREATE (a)-[:R]->(b) DELETE b` — the shape that makes the boundary
    /// overstate itself mid-query. b's id must reach the recycle bin, or the
    /// space is left with a hole that the next query's boundary counts as live.
    #[test]
    fn a_cancelled_reservation_returns_to_the_bin() {
        let mut g = graph();
        let mut q = Query::new(&mut g);
        let ids = q.reserve(&mut g, 2);
        assert_eq!(ids, vec![0, 1]);
        q.cancel(&mut g, 1);
        q.commit(&mut g);

        assert!(g.is_node_deleted(NodeId(1)), "b's id is free, not lost");
        assert_eq!(g.node_ids.live(), 1);
        assert_dense(&g, 2);

        // A *later* query does hand it back out — by then it is a different
        // effects buffer, where recreating a recycled id is ordinary.
        let mut q = Query::new(&mut g);
        assert_eq!(q.reserve(&mut g, 1), vec![1]);
        q.commit(&mut g);
        assert_dense(&g, 2);
    }

    /// Cancelling and reserving again within one query must not hand the
    /// cancelled id to two different nodes.
    #[test]
    fn reserving_after_a_cancellation_in_the_same_query() {
        let mut g = graph();
        let mut q = Query::new(&mut g);
        q.reserve(&mut g, 3);
        q.cancel(&mut g, 1);

        // Id 1 is back in the bin, but this query has already had it, so it is
        // not offered again — the next two ids are fresh. Handing it back would
        // put the same id in two records of one effects buffer: the cancelled
        // node's own create/delete pair, and the real create that reused it.
        // A replica refuses that buffer as `AlreadyLive`, measured.
        let next = q.reserve(&mut g, 2);
        assert_eq!(next, vec![3, 4], "not 1 again, even though it is free");
        q.commit(&mut g);

        // Still dense: five ids handed out, four live and 1 in the bin.
        assert_dense(&g, 5);
        assert!(g.is_node_deleted(NodeId(1)));
    }

    /// The relationship allocator is the same code over the other pair of
    /// counters, so it gets the same walk: reclaim lowest-first, then fresh.
    #[test]
    fn relationship_ids_reclaim_then_allocate_fresh() {
        let mut g = graph();
        let mut q = Query::new(&mut g);
        q.reserve(&mut g, 4);
        q.commit(&mut g);

        let type_name = Arc::new("R".to_owned());
        let ids = g
            .relationship_id_space()
            .reserve(3, &RoaringTreemap::new())
            .expect("reserved");
        assert_eq!(ids, vec![0, 1, 2]);
        g.create_relationships_bulk(&type_name, &[0, 1, 2], &[1, 2, 3], &ids)
            .expect("the allocator's own ids must be creatable");

        let mut docs = IndexDocs::default();
        let doomed: RoaringTreemap = std::iter::once(1).collect();
        g.open_id_batches().expect("a consistent space");
        g.delete_relationships(&doomed, &mut docs).expect("deleted");

        // One in the bin, two live, so three ids handed out.
        // A fresh batch, so nothing is outstanding: the first one committed.
        g.open_id_batches().expect("a consistent space");
        let ids = g
            .relationship_id_space()
            .reserve(2, &RoaringTreemap::new())
            .expect("reserved");
        assert_eq!(ids, vec![1, 3], "the freed id, then above the boundary");
    }

    /// The three slices and the id set have to describe the same edges.
    ///
    /// Both shapes are refused before anything is mutated, which is the whole
    /// point: the id space is told about a *set* while the tensor, the endpoint
    /// index and the type matrix each walk the raw slice, and nothing downstream
    /// reconciles the two readings. `[0, 0]` used to count one relationship and
    /// build two tensor edges under the one id.
    ///
    /// It matters because `effects/v3/apply.rs` is a caller whose `rel_ids` come
    /// off the wire, decoded from an `IdList` this process did not build.
    #[test]
    fn bulk_relationship_create_refuses_slices_that_disagree() {
        let mut g = graph();
        g.open_id_batches().expect("a consistent space");
        let type_name = Arc::new("R".to_owned());

        let duplicated = g
            .create_relationships_bulk(&type_name, &[0, 0], &[1, 1], &[0, 0])
            .expect_err("an id names one edge");
        assert!(
            duplicated.to_string().contains("only 1 are distinct"),
            "{duplicated}"
        );

        let ragged = g
            .create_relationships_bulk(&type_name, &[0], &[1, 2], &[0, 1])
            .expect_err("two ids cannot share one source");
        assert!(ragged.to_string().contains("1 sources"), "{ragged}");

        // Refused before anything moved, so the space is still untouched and an
        // honest create of the same ids still works.
        g.create_relationships_bulk(&type_name, &[0, 1], &[1, 2], &[0, 1])
            .expect("the well-formed call is unaffected");
        assert_eq!(g.relationship_count(), 2);
    }

    /// A second batch must not re-hand-out the first batch's reclaimed ids.
    /// This is the case the graph's own counter used to carry, and the one that
    /// breaks loudest if `outstanding` is ever passed as a constant.
    #[test]
    fn outstanding_covers_ids_reclaimed_by_an_earlier_batch() {
        let mut g = graph();
        let mut q = Query::new(&mut g);
        q.reserve(&mut g, 8);
        q.commit(&mut g);
        delete(&mut g, &[0, 1, 2, 3, 4, 5]);

        let mut q = Query::new(&mut g);
        assert_eq!(q.reserve(&mut g, 2), vec![0, 1]);
        assert_eq!(q.reserve(&mut g, 2), vec![2, 3], "not 0 and 1 again");
        assert_eq!(q.reserve(&mut g, 2), vec![4, 5]);
        assert_eq!(
            q.reserve(&mut g, 2),
            vec![8, 9],
            "bin exhausted, then fresh"
        );
        q.commit(&mut g);
        assert_dense(&g, 10);
    }
}

#[cfg(test)]
mod adjacency_cascade_tests {
    use super::super::graphblas::test_init::ensure_init;
    use super::*;

    fn build(
        name: &str,
        node_count: usize,
        edges: &[(u64, u64, &str)],
    ) -> Graph {
        ensure_init();
        let mut g = Graph::new(16, 16, 1, 0, name);
        g.open_id_batches().expect("a consistent space");
        let ids: RoaringTreemap = g
            .node_id_space()
            .reserve(node_count, &RoaringTreemap::new())
            .unwrap()
            .into_iter()
            .collect();
        g.create_nodes(&ids).unwrap();
        for &(src, dst, type_name) in edges {
            // One at a time, creating as it goes: the batch excludes what it has
            // already created without being told, so `issued` stays empty here.
            let rel_id = g
                .relationship_id_space()
                .reserve(1, &RoaringTreemap::new())
                .unwrap()[0];
            g.create_relationships_bulk(
                &Arc::new(type_name.to_string()),
                &[src],
                &[dst],
                &[rel_id],
            )
            .unwrap();
        }
        g
    }

    /// The commit-time cascade for `DELETE n`: node removal, then implicit
    /// removal of every edge incident to a deleted node. Mirrors the order in
    /// `Pending::commit`.
    fn delete_nodes_cascade(
        g: &mut Graph,
        nodes: &[u64],
    ) {
        let deleted: RoaringTreemap = nodes.iter().copied().collect();
        let mut node_docs = IndexDocs::default();
        let mut edge_docs = IndexDocs::default();
        g.open_id_batches().expect("a consistent space");
        g.delete_nodes(&deleted, &mut node_docs).unwrap();
        g.delete_implicit_edges(&deleted, &RoaringTreemap::new(), &mut edge_docs)
            .unwrap();
    }

    /// What a traversal without a bound relationship reads: `CondTraverse`
    /// takes the adjacency matrix and emits pairs from it directly, with no
    /// tensor lookup to disagree with.
    fn adjacency_entries(g: &Graph) -> Vec<(u64, u64)> {
        g.build_adjacency_matrix(&[]).iter(0, g.node_cap).collect()
    }

    /// Deleting an edge together with both of its endpoints has to clear the
    /// adjacency entry.
    ///
    /// This is #2771. The entry used to be left behind on the theory that a
    /// pair of deleted nodes is unreachable — but node ids are recycled out of
    /// `deleted_nodes`, so the next two nodes created inherit the bit and
    /// `MATCH (x)-->(y)` invents an edge between them. `MATCH (x)-[r]->(y)` was
    /// unaffected: binding `r` forces a tensor lookup, which finds nothing, so
    /// two plans over the same data disagreed.
    #[test]
    fn deleting_both_endpoints_clears_adjacency() {
        for (name, node_count, edges, delete) in [
            (
                "adj_cascade_simple",
                2,
                &[(0u64, 1u64, "R")][..],
                &[0u64, 1][..],
            ),
            ("adj_cascade_self_loop", 1, &[(0, 0, "R")][..], &[0][..]),
            (
                "adj_cascade_parallel",
                2,
                &[(0, 1, "R"), (0, 1, "R"), (0, 1, "S")][..],
                &[0, 1][..],
            ),
            (
                "adj_cascade_both_directions",
                2,
                &[(0, 1, "R"), (1, 0, "S")][..],
                &[0, 1][..],
            ),
        ] {
            let mut g = build(name, node_count, edges);
            assert!(
                g.adjacency_matrix().nvals() > 0,
                "{name}: nothing to delete"
            );

            delete_nodes_cascade(&mut g, delete);

            assert_eq!(
                g.adjacency_matrix().nvals(),
                0,
                "{name}: adjacency entry survived the deletion of both endpoints"
            );
            assert!(
                adjacency_entries(&g).is_empty(),
                "{name}: a traversal would still see a phantom edge"
            );
        }
    }

    /// The converse: clearing must not overreach. An edge between surviving
    /// nodes keeps its adjacency entry when a neighbour is deleted.
    #[test]
    fn surviving_edges_keep_their_adjacency() {
        // 0 -> 1 -> 2, and a second type between the survivors.
        let mut g = build(
            "adj_cascade_survivor",
            3,
            &[(0, 1, "R"), (1, 2, "R"), (1, 2, "S")],
        );

        delete_nodes_cascade(&mut g, &[0]);

        assert_eq!(adjacency_entries(&g), vec![(1, 2)]);
    }

    /// Deleting one type between a pair that also has an edge of another type
    /// leaves the pair adjacent — the per-tensor check, not the both-endpoints
    /// shortcut, decides this.
    #[test]
    fn pair_stays_adjacent_while_another_type_remains() {
        let mut g = build("adj_cascade_multi_type", 3, &[(0, 1, "R"), (0, 1, "S")]);
        let mut edge_docs = IndexDocs::default();

        // Drop just the R edge (id 0) explicitly; S (id 1) stays.
        g.open_id_batches().expect("a consistent space");
        g.delete_relationships(&RoaringTreemap::from_iter([0u64]), &mut edge_docs)
            .unwrap();
        assert_eq!(adjacency_entries(&g), vec![(0, 1)]);

        // Now delete node 2, which is unrelated: the 0->1 pair is untouched.
        delete_nodes_cascade(&mut g, &[2]);
        assert_eq!(adjacency_entries(&g), vec![(0, 1)]);

        // And deleting both endpoints clears it, S edge included.
        delete_nodes_cascade(&mut g, &[0, 1]);
        assert!(adjacency_entries(&g).is_empty());
    }
}

#[cfg(test)]
mod relationship_liveness_tests {
    use super::*;
    use crate::graph::graphblas::test_init::ensure_init;

    /// Nodes 0..8, all created in one batch, then a fresh batch opened.
    fn graph() -> Graph {
        ensure_init();
        let mut g = Graph::new(64, 64, 0, 0, "liveness");
        g.open_id_batches().expect("a consistent space");
        g.create_nodes(&(0..8).collect()).expect("created");
        g.open_id_batches().expect("a consistent space");
        g
    }

    fn edges(
        g: &mut Graph,
        ty: &str,
        pairs: &[(u64, u64)],
    ) {
        let ids = g
            .relationship_id_space()
            .reserve(pairs.len(), &RoaringTreemap::new())
            .expect("reserved");
        let (src, dst): (Vec<u64>, Vec<u64>) = pairs.iter().copied().unzip();
        g.create_relationships_bulk(&Arc::new(ty.to_owned()), &src, &dst, &ids)
            .expect("created");
    }

    fn first(
        g: &Graph,
        nodes: &[u64],
    ) -> Option<u64> {
        g.first_node_with_relationships(&nodes.iter().copied().collect())
    }

    /// 3 -> 0 (R), 4 -> 4 (S), 2 -> 6 (S); 1, 5 and 7 are isolated.
    fn shaped() -> Graph {
        let mut g = graph();
        edges(&mut g, "R", &[(3, 0)]);
        edges(&mut g, "S", &[(4, 4), (2, 6)]);
        g
    }

    #[test]
    fn no_node_with_relationships() {
        let g = shaped();
        assert_eq!(first(&g, &[1, 5, 7]), None);
        assert_eq!(first(&g, &[]), None);
        // Past the matrix: no row, no column.
        assert_eq!(first(&g, &[1, 1 << 40]), None);
        assert_eq!(first(&graph(), &[0, 1, 2]), None, "no edges at all");
    }

    #[test]
    fn outgoing_only() {
        let g = shaped();
        assert_eq!(first(&g, &[3, 5]), Some(3));
        assert_eq!(first(&g, &[1, 2, 7]), Some(2));
    }

    #[test]
    fn incoming_only() {
        let g = shaped();
        assert_eq!(first(&g, &[0, 5]), Some(0));
        assert_eq!(first(&g, &[1, 6, 7]), Some(6));
    }

    #[test]
    fn self_loop() {
        let g = shaped();
        assert_eq!(first(&g, &[4, 5]), Some(4));
    }

    #[test]
    fn lowest_across_types_and_directions() {
        let g = shaped();
        // 0 has an R edge in, 3 one out: the incoming one is lower.
        assert_eq!(first(&g, &[0, 3]), Some(0));
        // 3 has R out, 6 has S in: the outgoing one is lower.
        assert_eq!(first(&g, &[3, 6]), Some(3));
        // Every kind at once.
        assert_eq!(first(&g, &[7, 6, 5, 4, 3, 2]), Some(2));
        assert_eq!(first(&g, &[0, 1, 2, 3, 4, 5, 6, 7]), Some(0));
    }

    /// The adjacency matrix is exact: a pair whose last edge went is gone, so
    /// the node is free to delete again — and a pair with an edge of another
    /// type left is not.
    #[test]
    fn deleting_the_last_edge_clears_the_node() {
        let mut g = graph();
        edges(&mut g, "R", &[(1, 2)]);
        edges(&mut g, "S", &[(1, 2)]);
        let mut docs = IndexDocs::default();
        g.delete_relationships(&std::iter::once(0).collect(), &mut docs)
            .expect("deleted");
        assert_eq!(first(&g, &[1]), Some(1), "the S edge is still there");
        assert_eq!(first(&g, &[2]), Some(2));
        g.delete_relationships(&std::iter::once(1).collect(), &mut docs)
            .expect("deleted");
        assert_eq!(first(&g, &[1, 2]), None);
    }

    /// `validate` holds every write path to it: an edge this batch created
    /// onto a node that is gone is refused, one deleted again is not.
    #[test]
    fn validate_refuses_an_edge_onto_a_node_that_is_not_live() {
        let mut g = graph();
        edges(&mut g, "R", &[(0, 1), (2, 3)]);
        g.validate().expect("both endpoints live");

        let mut docs = IndexDocs::default();
        // Freed without the edge: what `NodeHasRelationships` stops the
        // effects path from doing, and Cypher never does.
        g.delete_nodes(&std::iter::once(3).collect(), &mut docs)
            .expect("deleted");
        assert_eq!(
            g.validate(),
            Err(NodeOpError::DanglingRelationship { id: 1 })
        );

        let mut edocs = IndexDocs::default();
        g.delete_relationships(&std::iter::once(1).collect(), &mut edocs)
            .expect("deleted");
        g.validate().expect("the edge went with it");
    }

    /// A relationship from before the batch is the batch that created it's
    /// business; only this batch's own are walked.
    #[test]
    fn validate_checks_only_this_batch() {
        let mut g = graph();
        edges(&mut g, "R", &[(0, 1)]);
        g.open_id_batches().expect("a consistent space");
        assert!(g.relationship_id_space().taken().is_empty());
        g.validate().expect("nothing created in this batch");
    }
}

#[cfg(test)]
mod grow_cap_tests {
    use super::*;

    /// #2892. Near the top of `u64` the unchecked step wrapped, and since the
    /// capacity stays a multiple of the chunk it never reached `needed` — the
    /// loop spun forever in release. It now stops at the largest dimension
    /// GraphBLAS accepts.
    #[test]
    fn growth_stops_at_the_largest_graphblas_dimension() {
        let chunk = NODE_CREATION_BUFFER.load(Ordering::Relaxed);
        assert_eq!(grow_cap(chunk, u64::MAX - 1), GrB_INDEX_MAX);
        assert_eq!(grow_cap(chunk, GrB_INDEX_MAX), GrB_INDEX_MAX);
        assert_eq!(grow_cap(GrB_INDEX_MAX - 1, GrB_INDEX_MAX), GrB_INDEX_MAX);
    }

    #[test]
    fn ordinary_growth_is_unchanged() {
        let chunk = NODE_CREATION_BUFFER.load(Ordering::Relaxed);
        assert_eq!(grow_cap(chunk, chunk), chunk);
        assert_eq!(grow_cap(chunk, chunk + 1), 2 * chunk);
        let cap = 100 * chunk;
        assert_eq!(grow_cap(cap, cap + 1), cap + cap / 4);
    }
}

#[cfg(all(test, feature = "index-falkordb"))]
mod falkordb_index_tests;

#[cfg(test)]
mod restore_tests {
    use super::*;
    use crate::graph::graphblas::test_init::ensure_init;

    /// A load must not shrink the matrices it decodes (#3246).
    ///
    /// They keep the size the saving server gave them, its `node_cap`, which
    /// `grow_cap` leaves up to 25% past the highest node id. `restore` used to
    /// reset `node_cap` to that id rounded up to one chunk, so
    /// `rebuild_derived_matrices` shrank every node matrix on load, and a
    /// tensor shrink is where `me` kept the ids of pairs it cut off.
    #[test]
    fn restore_never_shrinks_the_saved_matrices() {
        ensure_init();
        // Two nodes, saved by a server whose node_cap had grown to 40,960:
        // restore rounds two nodes up to one 16,384 chunk.
        const SAVED: u64 = 40_960;
        let mut tensor = Tensor::new(SAVED, SAVED);
        tensor.set_all_from_slices(&[0, 0], &[1, 1], &[0, 1]);
        tensor.flush();
        let mut g = Graph::restore(
            "restore_never_shrinks",
            1,
            2,
            2,
            RoaringTreemap::new(),
            RoaringTreemap::new(),
            VersionedMatrix::<bool>::new(SAVED, SAVED),
            VersionedMatrix::<bool>::new(SAVED, 1),
            VersionedMatrix::<bool>::new(0, 0),
            vec![VersionedMatrix::<bool>::new(SAVED, SAVED)],
            vec![tensor],
            vec![Arc::new("L".to_string())],
            vec![Arc::new("R".to_string())],
            AttrNameMap::default(),
            AttributeStore::new(),
            AttributeStore::new(),
        );
        g.rebuild_derived_matrices();

        assert!(
            g.node_cap >= SAVED,
            "node_cap {} below the saved size",
            g.node_cap
        );
        let t = &g.relationship_matrices[0];
        assert_eq!(
            (t.nrows(), t.ncols()),
            (SAVED, SAVED),
            "the load shrank the tensor"
        );
        assert_eq!(
            g.adjacancy_matrix.nrows(),
            SAVED,
            "the load shrank the adjacency matrix"
        );
        assert_eq!(
            g.labels_matices[0].nrows(),
            SAVED,
            "the load shrank a label matrix"
        );
        assert_eq!(
            g.node_labels_matrix.nrows(),
            SAVED,
            "the load shrank node_labels"
        );
        let mut edges: Vec<_> = t.iter_edges().collect();
        edges.sort_unstable();
        assert_eq!(edges, vec![(0, 1, 0), (0, 1, 1)]);
    }
}
