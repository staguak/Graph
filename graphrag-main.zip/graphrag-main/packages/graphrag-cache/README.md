# GraphRAG Cache

> [!WARNING]
> GraphRAG is a research project that explores the functional use of graphs to form a targeted context for question answering. Since our first release in July 2024 the capabilities of frontier models have changed dramatically, and our portfolio of research projects has diversified to match. This project is largely in maintenance mode, and won't be accepting new PRs or implementing new features. We'll perform bug fixes and dependency updates as appropriate, particularly to address CVEs as they arise.

This package contains a collection of utilities to handle GraphRAG caching implementation.

### Basic

This example shows how to create a JSON cache with file storage using the GraphRAG cache package's configuration system.

[Open the notebook to explore the basic example code](example_notebooks/basic_cache_example.ipynb)

### Custom Cache

This example demonstrates how to create a custom cache implementation by extending the base Cache class and registering it with the GraphRAG cache system. Once registered, the custom cache can be instantiated through the factory pattern using either CacheConfig or directly via cache_factory, allowing for extensible caching solutions tailored to specific needs.

[Open the notebook to explore the basic custom example code](example_notebooks/custom_cache_example.ipynb)

#### Details

By default, the `create_cache` comes with the following cache providers registered that correspond to the entries in the `CacheType` enum.

- `JsonCache`
- `MemoryCache`
- `NoopCache`
- `SQLiteCache`

`SQLiteCache` stores JSON-serializable values in a local SQLite database. It uses
WAL mode and short-lived connections so multiple workers can safely share the
same database. Configure it with:

```yaml
cache:
  type: sqlite
  storage:
    type: file
    base_dir: cache
  database_name: cache.db
```

The database is created within the configured file storage. SQLite requires
local random-access file operations, so blob and Cosmos storage are not
supported. Child caches use isolated namespaces within the same database.

All cache providers expose `await cache.get_many(keys)` for bulk reads. The
result maps each existing, valid key to the same decoded value returned by
`get()`. Missing and malformed entries are omitted, duplicate input keys appear
at most once, and an empty input returns an empty dictionary. The default
implementation remains compatible with custom `Cache` subclasses, while
`MemoryCache`, `NoopCache`, and `SQLiteCache` provide backend-specific
implementations. SQLite bulk reads use one worker dispatch and one connection,
splitting large key sets into bounded SQL batches.

An opt-in warm-cache benchmark compares bulk reads across the memory, JSON, and
SQLite providers without enforcing a machine-dependent performance threshold:

```bash
uv run pytest -s tests/unit/cache/test_cache_benchmark.py \
  --run-cache-benchmark
```

The benchmark reports median latency, entries per second, and time relative to
SQLite for 1,000 entries. Setup time is excluded from the measurements.

The preregistration happens dynamically, e.g., `JsonCache` is only imported and registered if you request a `JsonCache` with `create_cache(CacheType.Json, ...)`. There is no need to manually import and register builtin cache providers when using `create_cache`.

If you want a clean factory with no preregistered cache providers then directly import `cache_factory` and bypass using `create_cache`. The downside is that `cache_factory.create` uses a dict for init args instead of the strongly typed `CacheConfig` used with `create_cache`.

```python
from graphrag_cache.cache_factory import cache_factory
from graphrag_cache.json_cache import JsonCache

# cache_factory has no preregistered providers so you must register any
# providers you plan on using.
# May also register a custom implementation, see above for example.
cache_factory.register("my_cache_impl", JsonCache)

cache = cache_factory.create(
    strategy="my_cache_impl", init_args={"some_setting": "..."}
)

...
```
