# Copyright (c) 2024 Microsoft Corporation.
# Licensed under the MIT License

"""Abstract base class for cache."""

from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Sequence

    from graphrag_storage import Storage


class Cache(ABC):
    """Provide a cache interface for the pipeline."""

    @abstractmethod
    def __init__(self, *, storage: Storage | None, **kwargs: Any) -> None:
        """Create a cache instance."""

    @abstractmethod
    async def get(self, key: str) -> Any:
        """Get the value for the given key.

        Args:
            - key - The key to get the value for.
            - as_bytes - Whether or not to return the value as bytes.

        Returns
        -------
            - output - The value for the given key.
        """

    async def get_many(self, keys: Sequence[str]) -> dict[str, Any]:
        """Return existing cache values keyed by cache key.

        Missing or invalid entries are omitted. Duplicate keys appear at most once.
        """
        unique_keys = list(dict.fromkeys(keys))
        values = await asyncio.gather(*(self.get(key) for key in unique_keys))
        return {
            key: value
            for key, value in zip(unique_keys, values, strict=True)
            if value is not None
        }

    @abstractmethod
    async def set(self, key: str, value: Any, debug_data: dict | None = None) -> None:
        """Set the value for the given key.

        Args:
            - key - The key to set the value for.
            - value - The value to set.
        """

    @abstractmethod
    async def has(self, key: str) -> bool:
        """Return True if the given key exists in the cache.

        Args:
            - key - The key to check for.

        Returns
        -------
            - output - True if the key exists in the cache, False otherwise.
        """

    @abstractmethod
    async def delete(self, key: str) -> None:
        """Delete the given key from the cache.

        Args:
            - key - The key to delete.
        """

    @abstractmethod
    async def clear(self) -> None:
        """Clear the cache."""

    @abstractmethod
    def child(self, name: str) -> Cache:
        """Create a child cache with the given name.

        Args:
            - name - The name to create the sub cache with.
        """
